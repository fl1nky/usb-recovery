package org.telegram.tgnet;
import java.util.ArrayList;
public class Vector {public static final int constructor=0x1cb5c415;
public static <T extends TLObject> void serialize(OutputSerializedData stream, final ArrayList<T> objects) {
        stream.writeInt32(constructor);
        stream.writeInt32(objects.size());
        for (int i = 0; i < objects.size(); ++i) {
            objects.get(i).serializeToStream(stream);
        }
    }
}
