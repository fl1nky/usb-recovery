package org.telegram.tgnet;public class NativeByteBuffer {}
