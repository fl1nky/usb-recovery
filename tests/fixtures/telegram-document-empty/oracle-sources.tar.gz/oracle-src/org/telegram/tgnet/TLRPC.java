package org.telegram.tgnet;
import java.util.ArrayList;
public class TLRPC {
public static class Peer extends TLObject { public long user_id,chat_id,channel_id; }
public static class Photo extends TLObject { public long id; }
public static class MessageMedia extends TLObject {
 public int flags,ttl_seconds;public boolean spoiler,live_photo;public Photo photo;public TLObject document;
 public String captionLegacy;
}
public static class Reply extends TLObject { public int reply_to_msg_id; }
public static class Message extends TLObject {
 public int flags,flags2,id,date,views,forwards,edit_date,ttl_period,quick_reply_shortcut_id,
 from_boosts_applied,report_delivery_until_date,schedule_repeat_period;
 public long via_bot_id,via_business_bot_id,grouped_id,effect,paid_message_stars;
 public String message,post_author,from_rank,summary_from_language;
 public Peer from_id,peer_id,saved_peer_id,guestchat_via_from;
 public TLObject fwd_from,reply_markup,replies,reactions,factcheck,suggested_post,rich_message;
 public Reply reply_to;public MessageMedia media;
 public ArrayList<TLObject> entities=new ArrayList<>(),restriction_reason=new ArrayList<>();
 public int tlBoundary;
 public void writeAttachPath(OutputSerializedData stream) {
   tlBoundary=((SerializedData)stream).length();stream.writeString("../../never-follow-oracle.jpg");
 }
 public boolean edit_hide,from_scheduled,invert_media,legacy,media_unread,mentioned,noforwards,offline,out,paid_suggested_post_stars,paid_suggested_post_ton,pinned,post,silent,video_processing_pending;
}
public static class TL_message extends Message {
public static final int constructor=0x7600b9d3;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            flags = setFlag(flags, FLAG_27, invert_media);
            stream.writeInt32(flags);
            flags2 = setFlag(flags2, FLAG_1, offline);
            flags2 = setFlag(flags2, FLAG_4, video_processing_pending);
            flags2 = setFlag(flags2, FLAG_7, suggested_post != null);
            flags2 = setFlag(flags2, FLAG_8, paid_suggested_post_stars);
            flags2 = setFlag(flags2, FLAG_9, paid_suggested_post_ton);
            flags2 = setFlag(flags2, FLAG_12, from_rank != null);
            flags2 = setFlag(flags2, FLAG_13, rich_message != null);
            flags2 = setFlag(flags2, FLAG_19, guestchat_via_from != null);
            stream.writeInt32(flags2);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_29)) {
                stream.writeInt32(from_boosts_applied);
            }
            if (hasFlag(flags2, FLAG_12)) {
                stream.writeString(from_rank);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_28)) {
                saved_peer_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags2, FLAG_0)) {
                stream.writeInt64(via_business_bot_id);
            }
            if (hasFlag(flags2, FLAG_19)) {
                guestchat_via_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_20)) {
                reactions.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            if (hasFlag(flags, FLAG_30)) {
                stream.writeInt32(quick_reply_shortcut_id);
            }
            if (hasFlag(flags2, FLAG_2)) {
                stream.writeInt64(effect);
            }
            if (hasFlag(flags2, FLAG_3)) {
                factcheck.serializeToStream(stream);
            }
            if (hasFlag(flags2, FLAG_5)) {
                stream.writeInt32(report_delivery_until_date);
            }
            if (hasFlag(flags2, FLAG_6)) {
                stream.writeInt64(paid_message_stars);
            }
            if (hasFlag(flags2, FLAG_7)) {
                suggested_post.serializeToStream(stream);
            }
            if (hasFlag(flags2, FLAG_10)) {
                stream.writeInt32(schedule_repeat_period);
            }
            if (hasFlag(flags2, FLAG_11)) {
                stream.writeString(summary_from_language);
            }
            if (hasFlag(flags2, FLAG_13)) {
                rich_message.serializeToStream(stream);
            }
            writeAttachPath(stream);
        }
}

public static class TL_message_layer226 extends TLRPC.TL_message {
public static final int constructor=0x95ef6f2b;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            flags = setFlag(flags, FLAG_27, invert_media);
            stream.writeInt32(flags);
            flags2 = setFlag(flags2, FLAG_1, offline);
            flags2 = setFlag(flags2, FLAG_4, video_processing_pending);
            flags2 = setFlag(flags2, FLAG_7, suggested_post != null);
            flags2 = setFlag(flags2, FLAG_8, paid_suggested_post_stars);
            flags2 = setFlag(flags2, FLAG_9, paid_suggested_post_ton);
            flags2 = setFlag(flags2, FLAG_12, from_rank != null);
            flags2 = setFlag(flags2, FLAG_19, guestchat_via_from != null);
            stream.writeInt32(flags2);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_29)) {
                stream.writeInt32(from_boosts_applied);
            }
            if (hasFlag(flags2, FLAG_12)) {
                stream.writeString(from_rank);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_28)) {
                saved_peer_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags2, FLAG_0)) {
                stream.writeInt64(via_business_bot_id);
            }
            if (hasFlag(flags2, FLAG_19)) {
                guestchat_via_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_20)) {
                reactions.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            if (hasFlag(flags, FLAG_30)) {
                stream.writeInt32(quick_reply_shortcut_id);
            }
            if (hasFlag(flags2, FLAG_2)) {
                stream.writeInt64(effect);
            }
            if (hasFlag(flags2, FLAG_3)) {
                factcheck.serializeToStream(stream);
            }
            if (hasFlag(flags2, FLAG_5)) {
                stream.writeInt32(report_delivery_until_date);
            }
            if (hasFlag(flags2, FLAG_6)) {
                stream.writeInt64(paid_message_stars);
            }
            if (hasFlag(flags2, FLAG_7)) {
                suggested_post.serializeToStream(stream);
            }
            if (hasFlag(flags2, FLAG_10)) {
                stream.writeInt32(schedule_repeat_period);
            }
            if (hasFlag(flags2, FLAG_11)) {
                stream.writeString(summary_from_language);
            }
            writeAttachPath(stream);
        }
}

public static class TL_message_layer224 extends TLRPC.TL_message {
public static final int constructor=0x3AE56482;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            flags = setFlag(flags, FLAG_27, invert_media);
            stream.writeInt32(flags);
            flags2 = setFlag(flags2, FLAG_1, offline);
            flags2 = setFlag(flags2, FLAG_4, video_processing_pending);
            flags2 = setFlag(flags2, FLAG_7, suggested_post != null);
            flags2 = setFlag(flags2, FLAG_8, paid_suggested_post_stars);
            flags2 = setFlag(flags2, FLAG_9, paid_suggested_post_ton);
            flags2 = setFlag(flags2, FLAG_12, from_rank != null);
            stream.writeInt32(flags2);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_29)) {
                stream.writeInt32(from_boosts_applied);
            }
            if (hasFlag(flags2, FLAG_12)) {
                stream.writeString(from_rank);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_28)) {
                saved_peer_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags2, FLAG_0)) {
                stream.writeInt64(via_business_bot_id);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_20)) {
                reactions.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            if (hasFlag(flags, FLAG_30)) {
                stream.writeInt32(quick_reply_shortcut_id);
            }
            if (hasFlag(flags2, FLAG_2)) {
                stream.writeInt64(effect);
            }
            if (hasFlag(flags2, FLAG_3)) {
                factcheck.serializeToStream(stream);
            }
            if (hasFlag(flags2, FLAG_5)) {
                stream.writeInt32(report_delivery_until_date);
            }
            if (hasFlag(flags2, FLAG_6)) {
                stream.writeInt64(paid_message_stars);
            }
            if (hasFlag(flags2, FLAG_7)) {
                suggested_post.serializeToStream(stream);
            }
            if (hasFlag(flags2, FLAG_10)) {
                stream.writeInt32(schedule_repeat_period);
            }
            if (hasFlag(flags2, FLAG_11)) {
                stream.writeString(summary_from_language);
            }
            writeAttachPath(stream);
        }
}

public static class TL_message_layer222 extends TLRPC.TL_message {
public static final int constructor=0x9cb490e9;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            flags = setFlag(flags, FLAG_27, invert_media);
            stream.writeInt32(flags);
            flags2 = setFlag(flags2, FLAG_1, offline);
            flags2 = setFlag(flags2, FLAG_4, video_processing_pending);
            flags2 = setFlag(flags2, FLAG_7, suggested_post != null);
            flags2 = setFlag(flags2, FLAG_8, paid_suggested_post_stars);
            flags2 = setFlag(flags2, FLAG_9, paid_suggested_post_ton);
            stream.writeInt32(flags2);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_29)) {
                stream.writeInt32(from_boosts_applied);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_28)) {
                saved_peer_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags2, FLAG_0)) {
                stream.writeInt64(via_business_bot_id);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_20)) {
                reactions.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            if (hasFlag(flags, FLAG_30)) {
                stream.writeInt32(quick_reply_shortcut_id);
            }
            if (hasFlag(flags2, FLAG_2)) {
                stream.writeInt64(effect);
            }
            if (hasFlag(flags2, FLAG_3)) {
                factcheck.serializeToStream(stream);
            }
            if (hasFlag(flags2, FLAG_5)) {
                stream.writeInt32(report_delivery_until_date);
            }
            if (hasFlag(flags2, FLAG_6)) {
                stream.writeInt64(paid_message_stars);
            }
            if (hasFlag(flags2, FLAG_7)) {
                suggested_post.serializeToStream(stream);
            }
            if (hasFlag(flags2, FLAG_10)) {
                stream.writeInt32(schedule_repeat_period);
            }
            if (hasFlag(flags2, FLAG_11)) {
                stream.writeString(summary_from_language);
            }
            writeAttachPath(stream);
        }
}

public static class TL_message_layer220 extends TLRPC.TL_message {
public static final int constructor=0xb92f76cf;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            flags = setFlag(flags, FLAG_27, invert_media);
            stream.writeInt32(flags);
            flags2 = setFlag(flags2, FLAG_1, offline);
            flags2 = setFlag(flags2, FLAG_4, video_processing_pending);
            flags2 = setFlag(flags2, FLAG_7, suggested_post != null);
            flags2 = setFlag(flags2, FLAG_8, paid_suggested_post_stars);
            flags2 = setFlag(flags2, FLAG_9, paid_suggested_post_ton);
            stream.writeInt32(flags2);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_29)) {
                stream.writeInt32(from_boosts_applied);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_28)) {
                saved_peer_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags2, FLAG_0)) {
                stream.writeInt64(via_business_bot_id);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_20)) {
                reactions.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            if (hasFlag(flags, FLAG_30)) {
                stream.writeInt32(quick_reply_shortcut_id);
            }
            if (hasFlag(flags2, FLAG_2)) {
                stream.writeInt64(effect);
            }
            if (hasFlag(flags2, FLAG_3)) {
                factcheck.serializeToStream(stream);
            }
            if (hasFlag(flags2, FLAG_5)) {
                stream.writeInt32(report_delivery_until_date);
            }
            if (hasFlag(flags2, FLAG_6)) {
                stream.writeInt64(paid_message_stars);
            }
            if (hasFlag(flags2, FLAG_7)) {
                suggested_post.serializeToStream(stream);
            }
            if (hasFlag(flags2, FLAG_10)) {
                stream.writeInt32(schedule_repeat_period);
            }
            writeAttachPath(stream);
        }
}

public static class TL_message_layer216 extends TLRPC.TL_message {
public static final int constructor=0x9815cec8;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            flags = setFlag(flags, FLAG_27, invert_media);
            stream.writeInt32(flags);
            flags2 = setFlag(flags2, FLAG_1, offline);
            flags2 = setFlag(flags2, FLAG_4, video_processing_pending);
            flags2 = setFlag(flags2, FLAG_7, suggested_post != null);
            flags2 = setFlag(flags2, FLAG_8, paid_suggested_post_stars);
            flags2 = setFlag(flags2, FLAG_9, paid_suggested_post_ton);
            stream.writeInt32(flags2);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_29)) {
                stream.writeInt32(from_boosts_applied);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_28)) {
                saved_peer_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags2, FLAG_0)) {
                stream.writeInt64(via_business_bot_id);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_20)) {
                reactions.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            if (hasFlag(flags, FLAG_30)) {
                stream.writeInt32(quick_reply_shortcut_id);
            }
            if (hasFlag(flags2, FLAG_2)) {
                stream.writeInt64(effect);
            }
            if (hasFlag(flags2, FLAG_3)) {
                factcheck.serializeToStream(stream);
            }
            if (hasFlag(flags2, FLAG_5)) {
                stream.writeInt32(report_delivery_until_date);
            }
            if (hasFlag(flags2, FLAG_6)) {
                stream.writeInt64(paid_message_stars);
            }
            if ((hasFlag(flags2, FLAG_7))) {
                suggested_post.serializeToStream(stream);
            }
            writeAttachPath(stream);
        }
}

public static class TL_message_layer205 extends TLRPC.TL_message {
public static final int constructor=0xeabcdd4d;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            flags = setFlag(flags, FLAG_27, invert_media);
            stream.writeInt32(flags);
            flags2 = setFlag(flags2, FLAG_1, offline);
            flags2 = setFlag(flags2, FLAG_4, video_processing_pending);
            stream.writeInt32(flags2);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_29)) {
                stream.writeInt32(from_boosts_applied);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_28)) {
                saved_peer_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags2, FLAG_0)) {
                stream.writeInt64(via_business_bot_id);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_20)) {
                reactions.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            if (hasFlag(flags, FLAG_30)) {
                stream.writeInt32(quick_reply_shortcut_id);
            }
            if (hasFlag(flags2, FLAG_2)) {
                stream.writeInt64(effect);
            }
            if (hasFlag(flags2, FLAG_3)) {
                factcheck.serializeToStream(stream);
            }
            if (hasFlag(flags2, FLAG_5)) {
                stream.writeInt32(report_delivery_until_date);
            }
            if (hasFlag(flags2, FLAG_6)) {
                stream.writeInt64(paid_message_stars);
            }
            writeAttachPath(stream);
        }
}

public static class TL_message_layer199 extends TLRPC.TL_message {
public static final int constructor=0x96fdbbe9;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            flags = setFlag(flags, FLAG_27, invert_media);
            stream.writeInt32(flags);
            flags2 = setFlag(flags2, FLAG_1, offline);
            flags2 = setFlag(flags2, FLAG_4, video_processing_pending);
            stream.writeInt32(flags2);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_29)) {
                stream.writeInt32(from_boosts_applied);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_28)) {
                saved_peer_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags2, FLAG_0)) {
                stream.writeInt64(via_business_bot_id);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_20)) {
                reactions.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            if (hasFlag(flags, FLAG_30)) {
                stream.writeInt32(quick_reply_shortcut_id);
            }
            if (hasFlag(flags2, FLAG_2)) {
                stream.writeInt64(effect);
            }
            if (hasFlag(flags2, FLAG_3)) {
                factcheck.serializeToStream(stream);
            }
            if (hasFlag(flags2, FLAG_5)) {
                stream.writeInt32(report_delivery_until_date);
            }
            writeAttachPath(stream);
        }
}

public static class TL_message_layer195 extends TLRPC.TL_message {
public static final int constructor=0x94345242;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            flags = setFlag(flags, FLAG_27, invert_media);
            stream.writeInt32(flags);
            flags2 = setFlag(flags2, FLAG_1, offline);
            flags2 = setFlag(flags2, FLAG_4, video_processing_pending);
            stream.writeInt32(flags2);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_29)) {
                stream.writeInt32(from_boosts_applied);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_28)) {
                saved_peer_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags2, FLAG_0)) {
                stream.writeInt64(via_business_bot_id);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_20)) {
                reactions.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            if (hasFlag(flags, FLAG_30)) {
                stream.writeInt32(quick_reply_shortcut_id);
            }
            if (hasFlag(flags2, FLAG_2)) {
                stream.writeInt64(effect);
            }
            if (hasFlag(flags2, FLAG_3)) {
                factcheck.serializeToStream(stream);
            }
            writeAttachPath(stream);
        }
}

public static class TL_message_layer180 extends TLRPC.TL_message {
public static final int constructor=0xbde09c2e;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            flags = setFlag(flags, FLAG_27, invert_media);
            stream.writeInt32(flags);
            flags2 = setFlag(flags2, FLAG_1, offline);
            stream.writeInt32(flags2);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_29)) {
                stream.writeInt32(from_boosts_applied);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_28)) {
                saved_peer_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags2, FLAG_0)) {
                stream.writeInt64(via_business_bot_id);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_20)) {
                reactions.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            if (hasFlag(flags, FLAG_30)) {
                stream.writeInt32(quick_reply_shortcut_id);
            }
            if (hasFlag(flags2, FLAG_2)) {
                stream.writeInt64(effect);
            }
            writeAttachPath(stream);
        }
}

public static class TL_message_layer179 extends TLRPC.TL_message {
public static final int constructor=0x2357bf25;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            flags = setFlag(flags, FLAG_27, invert_media);
            stream.writeInt32(flags);
            flags2 = setFlag(flags2, FLAG_1, offline);
            stream.writeInt32(flags2);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_29)) {
                stream.writeInt32(from_boosts_applied);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_28)) {
                saved_peer_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags2, FLAG_0)) {
                stream.writeInt64(via_business_bot_id);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_20)) {
                reactions.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            if (hasFlag(flags, FLAG_30)) {
                stream.writeInt32(quick_reply_shortcut_id);
            }
            writeAttachPath(stream);
        }
}

public static class TL_message_layer176 extends TLRPC.TL_message {
public static final int constructor=0xa66c7efc;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            flags = setFlag(flags, FLAG_27, invert_media);
            stream.writeInt32(flags);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_29)) {
                stream.writeInt32(from_boosts_applied);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_28)) {
                saved_peer_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_20)) {
                reactions.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            if (hasFlag(flags, FLAG_30)) {
                stream.writeInt32(quick_reply_shortcut_id);
            }
            writeAttachPath(stream);
        }
}

public static class TL_message_layer175 extends TLRPC.TL_message {
public static final int constructor=0x1e4c8a69;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            flags = setFlag(flags, FLAG_27, invert_media);
            stream.writeInt32(flags);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_29)) {
                stream.writeInt32(from_boosts_applied);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_28)) {
                saved_peer_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_20)) {
                reactions.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            writeAttachPath(stream);
        }
}

public static class TL_message_layer173 extends TLRPC.TL_message {
public static final int constructor=0x76bec211;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            flags = setFlag(flags, FLAG_27, invert_media);
            stream.writeInt32(flags);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_28)) {
                saved_peer_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_20)) {
                reactions.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            writeAttachPath(stream);
        }
}

public static class TL_message_layer169 extends TLRPC.TL_message {
public static final int constructor=0x38116ee0;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            flags = setFlag(flags, FLAG_27, invert_media);
            stream.writeInt32(flags);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_20)) {
                reactions.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            writeAttachPath(stream);
        }
}

public static class TL_message_layer135 extends TLRPC.TL_message {
public static final int constructor=0x85d6cbe2;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            stream.writeInt32(flags);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            writeAttachPath(stream);
        }
}

public static class TL_message_layer131 extends TLRPC.TL_message {
public static final int constructor=0xbce383d2;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            stream.writeInt32(flags);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt32((int) via_bot_id);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            writeAttachPath(stream); //custom
        }
}

public static class TL_message_layer123 extends TLRPC.TL_message {
public static final int constructor=0x58ae39c9;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            stream.writeInt32(flags);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt32((int) via_bot_id);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            writeAttachPath(stream);
        }
}

public static class TL_message_layer118 extends TLRPC.TL_message {
public static final int constructor=0xf52e6b7f;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            stream.writeInt32(flags);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                stream.writeInt32((int) from_id.user_id);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt32((int) via_bot_id);
            }
            if (hasFlag(flags, FLAG_3)) {
                stream.writeInt32(reply_to.reply_to_msg_id);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            writeAttachPath(stream);
        }
}

public static class TL_messageMediaPhoto extends MessageMedia {
public static final int constructor=0xe216eb63;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_3, spoiler);
            flags = setFlag(flags, FLAG_4, live_photo);
            stream.writeInt32(flags);
            if (hasFlag(flags, FLAG_0)) {
                photo.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                stream.writeInt32(ttl_seconds);
            }
            if (hasFlag(flags, FLAG_4)) {
                document.serializeToStream(stream);
            }
        }
}

public static class TL_messageMediaPhoto_layer223 extends MessageMedia {
public static final int constructor=0x695150d7;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_3, spoiler);
            stream.writeInt32(flags);
            if (hasFlag(flags, FLAG_0)) {
                photo.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                stream.writeInt32(ttl_seconds);
            }
        }
}

public static class TL_messageMediaPhoto_layer74 extends MessageMedia {
public static final int constructor=0xb5223b0f;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt32(flags);
            if (hasFlag(flags, FLAG_0)) {
                photo.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_1)) {
                stream.writeString(captionLegacy);
            }
            if (hasFlag(flags, FLAG_2)) {
                stream.writeInt32(ttl_seconds);
            }
        }
}

public static class TL_messageMediaPhoto_layer68 extends MessageMedia {
public static final int constructor=0x3d8ce53d;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            photo.serializeToStream(stream);
            stream.writeString(captionLegacy);
        }
}

public static class TL_messageMediaPhoto_old extends MessageMedia {
public static final int constructor=0xc8c45a2a;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            photo.serializeToStream(stream);
        }
}

public static class TL_peerUser extends Peer {
public static final int constructor=0x59511722;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt64(user_id);
        }
}

public static class TL_peerChat extends Peer {
public static final int constructor=0x36c6019a;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt64(chat_id);
        }
}

public static class TL_peerChannel extends Peer {
public static final int constructor=0xa2a5371e;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt64(channel_id);
        }
}

public static class TL_peerUser_layer131 extends Peer {
public static final int constructor=0x9db1bc6d;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt32((int) user_id);
        }
}

public static class TL_peerChat_layer131 extends Peer {
public static final int constructor=0xbad0e5bb;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt32((int) chat_id);
        }
}

public static class TL_peerChannel_layer131 extends Peer {
public static final int constructor=0xbddde532;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt32((int) channel_id);
        }
}

public static class TL_photoEmpty extends Photo {
public static final int constructor=0x2331b22d;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt64(id);
        }
}

public static class Document extends TLObject {public long id;}
public static class TL_documentEmpty extends Document {
public static final int constructor=0x36f8c871;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt64(id);
        }
}
public static class TL_messageMediaDocument_layer74 extends MessageMedia {
public static final int constructor=0x7c4414d3;
public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt32(flags);
            if (hasFlag(flags, FLAG_0)) {
                document.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_1)) {
                stream.writeString(captionLegacy);
            }
            if (hasFlag(flags, FLAG_2)) {
                stream.writeInt32(ttl_seconds);
            }
        }
}

}
