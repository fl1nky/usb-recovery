package org.telegram.messenger;public class BuildVars {public static final boolean LOGS_ENABLED=true;}
