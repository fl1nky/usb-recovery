import java.nio.file.*;
import org.telegram.tgnet.*;

/** Own cases; all exercised serializeToStream methods and writer are upstream. */
public class DocumentEmptyOracle {
 static Path target;
 static final String OUTER="Owned document message recipe \uD83E\uDD67\nsecond \u7b2c\u4e8c\u884c";
 static final String CAPTION="Owned document caption recipe \uD83E\uDD67\ncaption \u7b2c\u4e8c\u884c";
 static final int[] LAYERS={232,226,224,222,220,216,205,199,195,180,179,176,175,173,169,135,131,123,118};
 static void emit(String name,int layer,int flags,long docid,int mode,int direction,int date,int mid,int ttl,boolean photo)throws Exception {
  String cls=layer==232?"TL_message":"TL_message_layer"+layer;
  TLRPC.Message m=(TLRPC.Message)Class.forName("org.telegram.tgnet.TLRPC$"+cls).getDeclaredConstructor().newInstance();
  m.id=mid;m.date=date;m.flags=256|512;
  m.from_id=layer<=131?new TLRPC.TL_peerUser_layer131():new TLRPC.TL_peerUser();m.from_id.user_id=77;
  m.peer_id=layer<=131?new TLRPC.TL_peerUser_layer131():new TLRPC.TL_peerUser();m.peer_id.user_id=909;
  long uid=77;
  if(direction==1){m.from_id.user_id=909;m.peer_id.user_id=77;m.out=true;}
  if(direction==2){m.peer_id=layer<=131?new TLRPC.TL_peerChat_layer131():new TLRPC.TL_peerChat();m.peer_id.chat_id=88;uid=-88;}
  if(direction==3){m.peer_id=layer<=131?new TLRPC.TL_peerChannel_layer131():new TLRPC.TL_peerChannel();m.peer_id.channel_id=99;uid=-99;}
  if(direction==4){m.from_id=null;m.peer_id.user_id=77;m.flags=512;}
  m.message=(mode==1||mode==4)?"":OUTER;
  TLRPC.MessageMedia media;
  if(photo){TLRPC.TL_messageMediaPhoto_layer74 p=new TLRPC.TL_messageMediaPhoto_layer74();TLRPC.TL_photoEmpty e=new TLRPC.TL_photoEmpty();e.id=docid;p.photo=e;media=p;}
  else{TLRPC.TL_messageMediaDocument_layer74 d=new TLRPC.TL_messageMediaDocument_layer74();TLRPC.TL_documentEmpty e=new TLRPC.TL_documentEmpty();e.id=docid;d.document=e;media=d;}
  media.flags=flags;media.ttl_seconds=ttl;
  media.captionLegacy=(mode==2||mode==4)?"":mode==3?OUTER:CAPTION;m.media=media;
  SerializedData out=new SerializedData();m.serializeToStream(out);byte[] raw=out.toByteArray();
  if(m.tlBoundary<=0||m.tlBoundary>=raw.length)throw new IllegalStateException("Missing boundary");
  Files.write(target.resolve(name+".bin"),raw);
  System.out.println(name+"\t"+layer+"\t"+flags+"\t"+docid+"\t"+mode+"\t"+direction+"\t"+date+"\t"+mid+"\t"+ttl+"\t"+uid+"\t"+m.tlBoundary+"\t"+photo+"\t"+String.format("0x%08x",m.getClass().getField("constructor").getInt(null)));
 }
 public static void main(String[] args)throws Exception {
  target=Path.of(args[0]);Files.createDirectories(target);
  for(int layer:LAYERS)for(int flags=0;flags<8;flags++)emit("layer"+layer+"-flags"+flags,layer,flags,987654321L,0,0,1790000000,41,60,false);
  long[] ids={0,-1,Long.MIN_VALUE,Long.MAX_VALUE};
  for(int i=0;i<ids.length;i++)emit("id"+i,118,7,ids[i],0,0,1790000000,41,0,false);
  for(int mode=1;mode<5;mode++)emit("mode"+mode,118,3,987654321L,mode,0,1790000000,41,0,false);
  for(int dir=1;dir<5;dir++)emit("direction"+dir,118,3,987654321L,0,dir,1790000000,41,0,false);
  emit("date-zero",118,3,987654321L,0,0,0,41,0,false);
  emit("local-negative-mid",118,3,987654321L,0,1,1790000000,-41,0,false);
  emit("photo-control",118,3,987654321L,0,0,1790000000,41,0,true);
 }
}
