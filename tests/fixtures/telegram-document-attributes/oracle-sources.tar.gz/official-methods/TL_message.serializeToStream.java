public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            flags = setFlag(flags, FLAG_27, invert_media);
            stream.writeInt32(flags);
            flags2 = setFlag(flags2, FLAG_1, offline);
            flags2 = setFlag(flags2, FLAG_4, video_processing_pending);
            flags2 = setFlag(flags2, FLAG_7, suggested_post != null);
            flags2 = setFlag(flags2, FLAG_8, paid_suggested_post_stars);
            flags2 = setFlag(flags2, FLAG_9, paid_suggested_post_ton);
            flags2 = setFlag(flags2, FLAG_12, from_rank != null);
            flags2 = setFlag(flags2, FLAG_13, rich_message != null);
            flags2 = setFlag(flags2, FLAG_19, guestchat_via_from != null);
            stream.writeInt32(flags2);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_29)) {
                stream.writeInt32(from_boosts_applied);
            }
            if (hasFlag(flags2, FLAG_12)) {
                stream.writeString(from_rank);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_28)) {
                saved_peer_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags2, FLAG_0)) {
                stream.writeInt64(via_business_bot_id);
            }
            if (hasFlag(flags2, FLAG_19)) {
                guestchat_via_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_20)) {
                reactions.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            if (hasFlag(flags, FLAG_30)) {
                stream.writeInt32(quick_reply_shortcut_id);
            }
            if (hasFlag(flags2, FLAG_2)) {
                stream.writeInt64(effect);
            }
            if (hasFlag(flags2, FLAG_3)) {
                factcheck.serializeToStream(stream);
            }
            if (hasFlag(flags2, FLAG_5)) {
                stream.writeInt32(report_delivery_until_date);
            }
            if (hasFlag(flags2, FLAG_6)) {
                stream.writeInt64(paid_message_stars);
            }
            if (hasFlag(flags2, FLAG_7)) {
                suggested_post.serializeToStream(stream);
            }
            if (hasFlag(flags2, FLAG_10)) {
                stream.writeInt32(schedule_repeat_period);
            }
            if (hasFlag(flags2, FLAG_11)) {
                stream.writeString(summary_from_language);
            }
            if (hasFlag(flags2, FLAG_13)) {
                rich_message.serializeToStream(stream);
            }
            writeAttachPath(stream);
        }
