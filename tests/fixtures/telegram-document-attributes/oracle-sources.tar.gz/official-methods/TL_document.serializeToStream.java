public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt32(flags);
            stream.writeInt64(id);
            stream.writeInt64(access_hash);
            stream.writeByteArray(file_reference);
            stream.writeInt32(date);
            stream.writeString(mime_type);
            stream.writeInt64(size);
            if (hasFlag(flags, FLAG_0)) {
                Vector.serialize(stream, thumbs);
            }
            if (hasFlag(flags, FLAG_1)) {
                Vector.serialize(stream, video_thumbs);
            }
            stream.writeInt32(dc_id);
            Vector.serialize(stream, attributes);
        }
