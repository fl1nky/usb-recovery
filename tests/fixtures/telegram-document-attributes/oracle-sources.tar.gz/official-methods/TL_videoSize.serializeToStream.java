public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt32(flags);
            stream.writeString(type);
            stream.writeInt32(w);
            stream.writeInt32(h);
            stream.writeInt32(size);
            if (hasFlag(flags, FLAG_0)) {
                stream.writeDouble(video_start_ts);
            }
        }
