public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_3, nopremium);
            flags = setFlag(flags, FLAG_4, spoiler);
            flags = setFlag(flags, FLAG_6, video);
            flags = setFlag(flags, FLAG_7, round);
            flags = setFlag(flags, FLAG_8, voice);
            flags = setFlag(flags, FLAG_11, live_photo);
            flags = setFlag(flags, FLAG_12, webpage != null);
            stream.writeInt32(flags);
            if (hasFlag(flags, FLAG_0)) {
                document.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_5)) {
                Vector.serialize(stream, alt_documents);
            }
            if (hasFlag(flags, FLAG_9)) {
                video_cover.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(video_timestamp);
            }
            if (hasFlag(flags, FLAG_2)) {
                stream.writeInt32(ttl_seconds);
            }
        }
