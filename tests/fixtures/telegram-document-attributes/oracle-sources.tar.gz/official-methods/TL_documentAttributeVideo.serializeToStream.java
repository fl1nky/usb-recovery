public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_0, round_message);
            flags = setFlag(flags, FLAG_1, supports_streaming);
            flags = setFlag(flags, FLAG_3, nosound);
            stream.writeInt32(flags);
            stream.writeDouble(duration);
            stream.writeInt32(w);
            stream.writeInt32(h);
            if (hasFlag(flags, FLAG_2)) {
                stream.writeInt32(preload_prefix_size);
            }
            if (hasFlag(flags, FLAG_4)) {
                stream.writeDouble(video_start_ts);
            }
            if (hasFlag(flags, FLAG_5)) {
                stream.writeString(video_codec);
            }
        }
