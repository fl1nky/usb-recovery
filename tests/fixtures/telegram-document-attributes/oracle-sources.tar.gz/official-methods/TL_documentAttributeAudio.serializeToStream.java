public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_10, voice);
            stream.writeInt32(flags);
            stream.writeInt32((int) duration);
            if (hasFlag(flags, FLAG_0)) {
                stream.writeString(title);
            }
            if (hasFlag(flags, FLAG_1)) {
                stream.writeString(performer);
            }
            if (hasFlag(flags, FLAG_2)) {
                stream.writeByteArray(waveform);
            }
        }
