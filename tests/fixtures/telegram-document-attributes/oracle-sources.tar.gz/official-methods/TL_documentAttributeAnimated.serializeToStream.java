public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
        }
