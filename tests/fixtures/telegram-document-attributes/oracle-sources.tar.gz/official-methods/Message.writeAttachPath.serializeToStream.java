protected void writeAttachPath(OutputSerializedData stream) {
            if (ApplicationLoader.isAndroidTestEnvironment()) {
                return;
            }

            if (this instanceof TL_message_secret || this instanceof TL_message_secret_layer72) {
                String path = attachPath != null ? attachPath : "";
                if (send_state == 1 && params != null && params.size() > 0) {
                    for (HashMap.Entry<String, String> entry : params.entrySet()) {
                        path = entry.getKey() + "|=|" + entry.getValue() + "||" + path;
                    }
                    path = "||" + path;
                }
                stream.writeString(path);
            } else {
                String path = !TextUtils.isEmpty(attachPath) ? attachPath : " ";
                if (legacy) {
                    if (params == null) {
                        params = new HashMap<>();
                    }
                    layer = LAYER;
                    params.put("legacy_layer", "" + LAYER);
                }
                boolean isPollWithAttachedMedia = false;
                if (pollMediaAttachPaths != null && pollMediaAttachPaths.size() > 0 && media instanceof TL_messageMediaPoll) {
                    if (params == null) {
                        params = new HashMap<>();
                    }
                    for (int a = 0, N = pollMediaAttachPaths.size(); a < N; a++) {
                        final int pollIndex = pollMediaAttachPaths.keyAt(a);
                        final String pollAttachPath = pollMediaAttachPaths.valueAt(a);
                        params.put("poll_attach_path_at_" + pollIndex, pollAttachPath);
                    }
                    isPollWithAttachedMedia = true;
                }
                if ((id < 0 || send_state == 3 || legacy || isPollWithAttachedMedia) && params != null && params.size() > 0) {
                    for (HashMap.Entry<String, String> entry : params.entrySet()) {
                        path = entry.getKey() + "|=|" + entry.getValue() + "||" + path;
                    }
                    path = "||" + path;
                }
                if (isPollWithAttachedMedia) {
                    path = "poll_with_media=" + path;
                }
                stream.writeString(path);
                if ((flags & MESSAGE_FLAG_FWD) != 0 && id < 0) {
                    stream.writeInt32(fwd_msg_id);
                }
            }
        }
