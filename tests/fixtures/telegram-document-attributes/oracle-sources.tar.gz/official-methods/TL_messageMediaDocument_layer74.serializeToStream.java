public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt32(flags);
            if (hasFlag(flags, FLAG_0)) {
                document.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_1)) {
                stream.writeString(captionLegacy);
            }
            if (hasFlag(flags, FLAG_2)) {
                stream.writeInt32(ttl_seconds);
            }
        }
