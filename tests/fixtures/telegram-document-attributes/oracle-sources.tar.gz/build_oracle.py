"""Create new native Java inputs only; no recovery/parser/helper execution."""
from pathlib import Path
from datetime import datetime, timezone
import base64
import hashlib
import json
import os
import re
import shutil
import sqlite3
import struct
import subprocess
import time
import zlib

HERE = Path(__file__).resolve().parent
MAIN = HERE.parents[2]
OLD = MAIN / '.build/telegram-document-descriptor-oracle-20261103/v01'
ASSESS = MAIN / '.build/telegram-next-format-assessment-20261103/v01-current-document'
JDK = Path('C:/Program Files/Eclipse Adoptium/jdk-25.0.3.9-hotspot')
COMMIT = '4de548e79fed27f1a66fbdff84223321838fe925'

def sha(raw): return hashlib.sha256(raw).hexdigest()
def dump(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2)+'\n')
def inv(folder): return {p.relative_to(folder).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(folder.rglob('*')) if p.is_file()}
def method(source):
    signature='public void serializeToStream(OutputSerializedData stream)'
    at=source.index(signature);start=source.index('{',at);depth=1;end=start+1
    while depth:
        depth += (source[end]=='{')-(source[end]=='}');end+=1
    return source[at:end]
def class_span(source, name):
    match=re.search(r'public static class '+re.escape(name)+r'\s+extends [^{]+\{',source)
    assert match, name
    start=match.start();at=match.end();depth=1
    while depth:
        depth+=(source[at]=='{')-(source[at]=='}');at+=1
    return source[start:at]
def run(args, label, cwd=HERE):
    start=time.monotonic()
    p=subprocess.run([str(a) for a in args],cwd=cwd,capture_output=True,timeout=90,
                     creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    (HERE/(label+'.stdout')).write_bytes(p.stdout);(HERE/(label+'.stderr')).write_bytes(p.stderr)
    row=dict(label=label,argv=[str(a) for a in args],exit_code=p.returncode,seconds=round(time.monotonic()-start,4),stdout_sha256=sha(p.stdout),stderr_sha256=sha(p.stderr))
    assert p.returncode==0,(label,p.stderr.decode('utf-8','replace')[:4000])
    return row
def png_chunk(kind,data): return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)

def main():
    assert HERE.is_relative_to(MAIN/'.build/telegram-document-attributes-oracle-20261103')
    for path in (HERE,*HERE.parents): assert not path.is_symlink()
    assert not (HERE/'java-src').exists(), 'Preserve prior attempts; no overwrite'
    upstream_evidence=json.loads((ASSESS/'source-evidence.json').read_text('utf-8-sig'))['official_sources']
    copied=[]
    for row in upstream_evidence:
        source=ASSESS/row['local'];raw=source.read_bytes()
        assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
        target=HERE/row['local'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
        assert target.read_bytes()==source.read_bytes()
        copied.append(row)
    upstream=(HERE/'upstream/TMessagesProj/src/main/java/org/telegram/tgnet/TLRPC.java').read_text('utf-8-sig')
    sources=HERE/'java-src'
    shutil.copytree(OLD/'java-src',sources,ignore=shutil.ignore_patterns('DescriptorOracle.java','TLRPC.java'))
    old_manifest=json.loads((OLD/'source-manifest.json').read_text('utf-8-sig'))
    for row in old_manifest['unchanged_java']:
        assert sha((sources/row['path']).read_bytes())==row['sha256']
    template=(OLD/'TLRPC.template.java').read_text('utf-8-sig')
    originals={}
    for name in ('TL_message','TL_messageMediaDocument','TL_messageMediaDocument_layer74','TL_document','TL_documentEmpty','TL_documentAttributeFilename','TL_peerUser'):
        raw=(OLD/'official-methods'/(name+'.java')).read_text('utf-8-sig').strip()
        assert raw in upstream, name
        originals[name]=raw
    original_attach=(OLD/'official-methods/Message.writeAttachPath.java').read_text('utf-8-sig').strip()
    assert original_attach in upstream
    originals['Message.writeAttachPath']=original_attach
    for name,value in originals.items(): template=template.replace('@'+name+'@',value)
    template=template.replace('public static class DocumentAttribute extends TLObject {public String file_name;}',
        'public static class DocumentAttribute extends TLObject {public String file_name,title,performer,video_codec;public double duration,video_start_ts;public int flags,w,h,preload_prefix_size;public boolean round_message,supports_streaming,nosound,voice;public byte[] waveform;}')
    additions=[]
    definitions={
        'TL_documentAttributeVideo':'DocumentAttribute','TL_documentAttributeAudio':'DocumentAttribute',
        'TL_documentAttributeAnimated':'DocumentAttribute','TL_documentAttributeImageSize':'DocumentAttribute',
        'TL_photoSizeEmpty':'PhotoSize','TL_photoSize':'PhotoSize','TL_photoCachedSize':'PhotoSize',
        'TL_videoSize':'VideoSize',
    }
    method_dir=HERE/'official-methods';method_dir.mkdir()
    spans=[]
    for name,base in definitions.items():
        span=class_span(upstream,name)
        constructor=re.search(r'public static final int constructor\s*=\s*(0x[a-fA-F0-9]+);',span).group(0)
        serializer=method(span)
        assert serializer in upstream
        (method_dir/(name+'.serializeToStream.java')).write_text(serializer+'\n',encoding='utf-8',newline='\n')
        additions.append('public static class '+name+' extends '+base+' {'+constructor+serializer+'}')
        spans.append(dict(name=name,constructor=constructor,serializer_sha256=sha(serializer.encode()),exact_upstream_text=True))
    additions.append('public static class PhotoSize extends TLObject {public String type;public int w,h,size;public byte[] bytes;}')
    additions.append('public static class VideoSize extends TLObject {public String type;public int flags,w,h,size;public double video_start_ts;}')
    assert template.endswith('}\n')
    template=template[:-2]+'\n'+'\n'.join(additions)+'\n}\n'
    assert not re.search(r'@[A-Za-z_]',template)
    (sources/'org/telegram/tgnet/TLRPC.java').write_text(template,encoding='utf-8',newline='\n')
    shutil.copyfile(HERE/'AttributeOracle.java',sources/'AttributeOracle.java')
    for name,value in originals.items():
        (method_dir/(name+'.serializeToStream.java')).write_text(value+'\n',encoding='utf-8',newline='\n')
        spans.append(dict(name=name,serializer_sha256=sha(value.encode()),exact_upstream_text=True))
    dump(HERE/'source-manifest.json',dict(schema=1,telegram_commit=COMMIT,official_sources=copied,unchanged_java=old_manifest['unchanged_java'],
        exact_serializers=spans,own_scaffolding='Field declarations and unused-platform stubs only; unsupported readers are not called',
        boundary='Official Message.writeAttachPath testEnvironment gate; original serializer prefix must match native full BLOB',
        current_reader='OUTSIDE_CURRENT_READER_NOT_ACCEPTED, except one filename-only profile control; product execution NOT_RUN'))
    image=b'\x89PNG\r\n\x1a\n'+png_chunk(b'IHDR',struct.pack('>IIBBBBB',2,1,8,2,0,0,0))+png_chunk(b'IDAT',zlib.compress(b'\0\xff\0\0\0\0\xff',9))+png_chunk(b'IEND',b'')
    (HERE/'thumbnail.png').write_bytes(image)
    classes=HERE/'classes';classes.mkdir()
    for name,expected in [('java.exe','d5f1b9e03e298ebfb04d2326ecc1e2af3e6817f9b4d7f9f151fe856d56975650'),('javac.exe','74f283ef1e26b3dfccfb56673d74a8a720d2c142e80881aa0084ce2e0379004e')]:
        assert sha((JDK/'bin'/name).read_bytes())==expected
    runs=[run([JDK/'bin/java.exe','-version'],'java-version'),run([JDK/'bin/javac.exe','-version'],'javac-version')]
    runs.append(run([JDK/'bin/javac.exe','-encoding','UTF-8','-d',classes]+sorted(sources.rglob('*.java')),'javac'))
    for number in (1,2):
        runs.append(run([JDK/'bin/java.exe','-Dfile.encoding=UTF-8','-cp',classes,'AttributeOracle',HERE/f'native-run-{number:02d}',HERE/'thumbnail.png'],f'java-run-{number:02d}'))
    assert inv(HERE/'native-run-01')==inv(HERE/'native-run-02')
    assert (HERE/'java-run-01.stdout').read_bytes()==(HERE/'java-run-02.stdout').read_bytes()
    dump(HERE/'native-run-receipt.json',dict(schema=1,status='NATIVE_JAVA_INPUTS_READY_NOT_RECOVERY_ACCEPTANCE',created_utc=datetime.now(timezone.utc).isoformat(),
        runs=runs,native_runs=2,identical_native_files=len(inv(HERE/'native-run-01')),java_source_files=len(list(sources.rglob('*.java'))),
        product_helper_parser_network_device=False,scope='Exact pinned official Java serializers plus own typed input values; no server/app/device claim'))
    print('Native Java attribute corpus completed; no recovery execution')

if __name__=='__main__': main()
