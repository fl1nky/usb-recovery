"""Freeze only the new independent input corpus; never executes recovery."""
from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import shutil
import tarfile
import zipfile

HERE=Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()
def dump(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def row(path):
    data=path.read_bytes();return dict(path=path.relative_to(HERE).as_posix(),bytes=len(data),sha256=sha(data))
def main():
    assert not (HERE/'manifest.json').exists() and not (HERE/'frozen-01').exists()
    verification=json.loads((HERE/'verification.json').read_text('utf-8'))
    assert (verification['native_cases'],verification['controls'],verification['sqlite_sources'])==(31,171,202)
    native_files={p.relative_to(HERE/'native-run-01').as_posix():row(p) for p in sorted((HERE/'native-run-01').rglob('*')) if p.is_file()}
    dump(HERE/'native-artifacts.json',dict(schema=1,files=[dict(path=name,bytes=value['bytes'],sha256=value['sha256']) for name,value in native_files.items()]))
    tool_paths=[Path('C:/Program Files/Eclipse Adoptium/jdk-25.0.3.9-hotspot/bin')/name for name in ('java.exe','javac.exe')]
    dump(HERE/'toolchain.json',dict(java=[dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path.read_bytes())) for path in tool_paths],
        policy='Observed existing Windows JDK25; no installer or runtime was distributed/executed beyond own javac/java writer'))
    readme='''# Telegram document attributes: independent inputs only

Status: **OUTSIDE_CURRENT_READER / NOT_ACCEPTED**. No recovery reader, helper, application, phone, server or paid program was run.

31 native Java serializations cover one filename-only profile control, 14 attribute profiles, 7 media-flag profiles and 9 thumbnail-vector profiles. There are 30 text slots and one intentionally empty message; filename/title/performer are never expected message text. Video uses the current double-duration constructor; audio, animation and image-size attributes are separate. One thumbnail is deliberately opaque/damaged: valid TL framing does not establish valid image content or complete attachment recovery.

The exact serializers and original `SerializedData`/`Vector` come from Android commit `4de548e79fed27f1a66fbdff84223321838fe925`. Full pinned primary sources, GPL license, extracted methods and compiled Java source are in `oracle-sources.tar.gz`. The Java output was produced twice; all 256 artifacts and metadata streams matched. SQLite independently stored the native BLOBs twice; all 202 files matched.

171 controls separately mark truncation, unknown constructors/flags and contradictory SQL dialog identity. They are explicit mutations, not valid native serialization claims. Their desired strict future-profile result is zero attributed native text; untyped fragment counts are unspecified. Current-reader outcomes remain NOT_RUN.

`oracle.json.gz` contains native bytes, expected producer fields, exact SQL keys and observed component ranges. `native-sqlite-cases.zip` contains current DB inputs. All files are own synthetic data; no real user exports are included. This corpus is separate from the frozen 20-image comparison and does not change its denominator.

For self-contained native replay, extract the source archive, compile every file under `java-src` with the recorded JDK25 `javac -encoding UTF-8 -d <fresh-classes>`, then run `AttributeOracle <fresh-output-directory> <absolute-thumbnail.png>` with that classes directory. The generated `java-src` tree is complete; it does not require the previous oracle. The original scaffolding-construction script records its local predecessor for provenance; use the complete generated tree for replay.

Future work: independently review these sources and expected profile policy, measure the current reader on the same inputs, implement a bounded parser extension in a new worktree, then run new source/portable/negative/provenance gates. Input production is not recovery acceptance.
'''
    (HERE/'README.md').write_text(readme,encoding='utf-8',newline='\n')
    selected=[]
    for folder in ('java-src','upstream','official-methods','native-run-01'):
        selected += [p for p in sorted((HERE/folder).rglob('*')) if p.is_file()]
    names=['AttributeOracle.java','build_oracle.py','package_oracle.py','finalize_oracle.py','source-manifest.json','messages-v2-schema.sql','thumbnail.png','LICENSE','README.md','native-artifacts.json','toolchain.json','native-run-receipt.json','verification.json','java-run-01.stdout','java-run-01.stderr','java-run-02.stdout','java-run-02.stderr']
    selected += [HERE/name for name in names]
    selected=sorted(set(selected))
    dump(HERE/'source-files.json',dict(schema=1,scope='Complete source/native-writer evidence inventory, no recovery implementation',files=[row(p) for p in selected]))
    selected.append(HERE/'source-files.json')
    out=io.BytesIO()
    with tarfile.open(fileobj=out,mode='w',format=tarfile.PAX_FORMAT) as archive:
        for path in sorted(selected):
            data=path.read_bytes();info=tarfile.TarInfo(path.relative_to(HERE).as_posix());info.size=len(data);info.mode=0o644;info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
            archive.addfile(info,io.BytesIO(data))
    with (HERE/'oracle-sources.tar.gz').open('xb') as file:
        with gzip.GzipFile(fileobj=file,mode='wb',filename='',mtime=0,compresslevel=9) as stream:stream.write(out.getvalue())
    canonical=['oracle.json.gz','native-sqlite-cases.zip','oracle-sources.tar.gz','LICENSE']
    manifest=dict(schema=1,status='INPUT_ONLY_OUTSIDE_CURRENT_READER_NOT_ACCEPTED',telegram_commit='4de548e79fed27f1a66fbdff84223321838fe925',
        native_cases=31,existing_profile_controls=1,outside_current_reader_profiles=30,expected_text_slots=30,mutation_controls=171,native_sqlite_sources=202,
        native_java_runs=2,native_sqlite_runs=2,independent_checks=verification['checks'],
        uncompressed_json_bytes=verification['raw_oracle_bytes'],uncompressed_json_sha256=verification['raw_oracle_sha256'],
        files=[row(HERE/name) for name in canonical],scope='Own native Java/SQLite input production only; no reader/helper/app/device/server/paid result')
    dump(HERE/'manifest.json',manifest)
    with gzip.open(HERE/'oracle.json.gz','rb') as stream:assert sha(stream.read())==manifest['uncompressed_json_sha256']
    with zipfile.ZipFile(HERE/'native-sqlite-cases.zip') as archive:assert archive.testzip() is None and len(archive.namelist())==202
    freeze=HERE/'frozen-01';freeze.mkdir()
    frozen=[]
    for path in sorted(set(selected+[HERE/name for name in canonical]+[HERE/'manifest.json'])):
        rel=path.relative_to(HERE).as_posix();target=freeze/'files'/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target)
        value=row(path);assert target.read_bytes()==path.read_bytes();frozen.append(value)
    dump(freeze/'manifest.json',dict(schema=1,files=frozen,scope='Physical immutable handoff bytes for independent input corpus'))
    receipt=dict(status='INPUT_PRODUCTION_CLOSED_NOT_RECOVERY_ACCEPTANCE',created_utc=datetime.now(timezone.utc).isoformat(),
        manifest_sha256=sha((HERE/'manifest.json').read_bytes()),freeze_manifest_sha256=sha((freeze/'manifest.json').read_bytes()),
        native_cases=31,mutation_controls=171,sqlite_sources=202,independent_checks=verification['checks'],native_artifacts=256,
        native_java_runs=2,native_sqlite_runs=2,product_helper_parser_device_network=False,
        benchmark20_corpus_modified=False,current_release_source_modified=False,source_closed=True,
        native_reader_baseline='NOT_RUN',native_reader_extension='NOT_IMPLEMENTED',portable_acceptance='NOT_RUN')
    dump(HERE/'handoff-receipt.json',receipt)
    print(json.dumps(receipt))
if __name__=='__main__':main()
