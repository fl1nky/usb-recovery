package me.vkryl.core;public class BitwiseUtils {public static int setFlag(int f,int b,boolean v){return v?f|b:f&~b;}public static boolean hasFlag(int f,int b){return(f&b)!=0;}}
