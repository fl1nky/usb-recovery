package org.telegram.tgnet;public class TLParseException {public static void doThrowOrLog(InputSerializedData s,String n,int c,boolean e){throw new AssertionError("No official reader invoked: "+n);}}
