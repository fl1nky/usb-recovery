package org.telegram.messenger; public class FileLog {public static void e(Object error){throw new AssertionError("Official SerializedData error: "+error);}}
