package org.telegram.messenger; public class ApplicationLoader {public static boolean testEnvironment=false;public static boolean isAndroidTestEnvironment(){return testEnvironment;}}
