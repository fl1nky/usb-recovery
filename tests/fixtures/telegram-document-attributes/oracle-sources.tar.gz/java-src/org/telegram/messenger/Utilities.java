package org.telegram.messenger; public class Utilities {public interface Callback<T>{void run(T v);} public interface CallbackReturn<A,B>{B run(A v);}}
