"""Package native Java bytes and explicit controls; never imports recovery code."""
from pathlib import Path
from datetime import datetime, timezone
import base64
import gzip
import hashlib
import io
import json
import re
import sqlite3
import struct
import tarfile
import zipfile
import zlib

HERE=Path(__file__).resolve().parent
MAIN=HERE.parents[2]
ASSESS=MAIN/'.build/telegram-next-format-assessment-20261103/v01-current-document'
COMMIT='4de548e79fed27f1a66fbdff84223321838fe925'
checks=[]
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def check(value,why):
    if not value: raise AssertionError(why)
    checks.append(why)
def dump(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as out:out.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def inv(folder):return {p.relative_to(folder).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(folder.rglob('*')) if p.is_file()}
def tlbytes(raw,at):
    first=raw[at];check(first<=254,'TL byte-string prefix')
    size,header=(int.from_bytes(raw[at+1:at+4],'little'),4) if first==254 else (first,1)
    end=at+header+size;padding=-(header+size)%4
    check(end+padding<=len(raw) and raw[end:end+padding]==b'\0'*padding,'TL byte-string exact bounds/padding')
    return raw[at+header:end],end+padding,at+header
def one_offset(parent,child,label):
    check(parent.count(child)==1,'Unique native serialized component '+label)
    return parent.index(child)
def schema_bytes():
    raw=(ASSESS/'messages-v2-schema.sql').read_bytes()
    check(raw.decode('utf-8').strip().startswith('CREATE TABLE messages_v2('),'Pinned independent SQL schema shape')
    target=HERE/'messages-v2-schema.sql';target.write_bytes(raw)
    return raw
def make_db(path,case,schema):
    path.parent.mkdir(parents=True,exist_ok=False)
    with sqlite3.connect(path) as con:
        con.execute('PRAGMA page_size=4096');con.execute('PRAGMA secure_delete=OFF');con.execute(schema)
        sql=case['exact_sql'];data=base64.b64decode(case['blob_base64'])
        con.execute('INSERT INTO messages_v2(mid,uid,read_state,send_state,date,data,out,ttl,media) VALUES(?,?,?,?,?,?,?,?,?)',
                    (sql['mid'],sql['uid'],0,0,sql['date'],data,int(case['out']),0,0))
        con.commit()
        check(con.execute('PRAGMA quick_check').fetchall()==[('ok',)],'Native SQLite quick_check '+case['name'])
        check(con.execute('SELECT mid,uid,date,data,out,typeof(data) FROM messages_v2').fetchall()==
              [(sql['mid'],sql['uid'],sql['date'],data,int(case['out']),'blob')],'Native SQLite exact tuple '+case['name'])
    return dict(bytes=path.stat().st_size,sha256=sha(path.read_bytes()))

def main():
    check(not (HERE/'corpus').exists(),'Refuse corpus overwrite')
    source_manifest=json.loads((HERE/'source-manifest.json').read_text('utf-8'))
    for row in source_manifest['official_sources']:
        raw=(HERE/row['local']).read_bytes();check(len(raw)==row['bytes'] and sha(raw)==row['sha256'],'Pinned full upstream source '+row['path'])
    official=(HERE/'upstream/TMessagesProj/src/main/java/org/telegram/tgnet/TLRPC.java').read_bytes()
    compiled=(HERE/'java-src/org/telegram/tgnet/TLRPC.java').read_bytes()
    for row in source_manifest['exact_serializers']:
        path=HERE/'official-methods'/(row['name']+'.serializeToStream.java')
        span=path.read_bytes().rstrip(b'\n')
        check(sha(span)==row['serializer_sha256'] and span in official and span in compiled,'Exact primary serializer embedded '+row['name'])
    check(inv(HERE/'native-run-01')==inv(HERE/'native-run-02'),'Two actual Java runs all files identical')
    check((HERE/'java-run-01.stdout').read_bytes()==(HERE/'java-run-02.stdout').read_bytes(),'Two actual Java metadata streams identical')
    original_inventory=inv(HERE/'native-run-01')
    rows=[json.loads(line) for line in (HERE/'java-run-01.stdout').read_text('utf-8').splitlines()]
    check(len(rows)==31 and len({r['name'] for r in rows})==31,'Exactly31 native profile cases')
    schema_raw=schema_bytes();schema=schema_raw.decode('utf-8')
    vector_ctor=struct.unpack('<I',(HERE/'native-run-01/baseline-filename.attribute-vector').read_bytes()[:4])[0]
    check(vector_ctor==0x1cb5c415,'Official Vector constructor')
    positives=[];controls=[]
    for row in rows:
        name=row['name'];folder=HERE/'native-run-01'
        blob=(folder/(name+'.blob')).read_bytes();body=(folder/(name+'.body')).read_bytes()
        doc=(folder/(name+'.document')).read_bytes();media=(folder/(name+'.media')).read_bytes();av=(folder/(name+'.attribute-vector')).read_bytes()
        check(len(body)==row['body_bytes'] and len(blob)==row['blob_bytes'] and sha(body)==row['body_sha256'] and sha(blob)==row['blob_sha256'],'Native byte/hash boundaries '+name)
        check(blob.startswith(body) and len(blob)>len(body),'Separate Android tail '+name)
        check(struct.unpack_from('<IIII',body)==(0x7600b9d3,770 if row['out'] else 768,0,row['id']),'Exact native message header '+name)
        check(struct.unpack_from('<IqIqI',body,16)==(0x59511722,77,0x59511722,909,row['date']),'Exact native peers/date '+name)
        check(row['sql_uid']==(909 if row['out'] else 77),'Independent SQL dialog direction '+name)
        for event in row['string_writes']:
            value,end,data_at=tlbytes(body,event['offset'])
            check(value==base64.b64decode(event['utf8_base64']) and end-event['offset']==event['encoded_bytes'],'Observed official string write '+name)
        first=row['string_writes'][0]
        check(first['offset']==44 and base64.b64decode(first['utf8_base64']).decode('utf-8')==row['text'],'Native expected text slot '+name)
        media_at=one_offset(body,media,name+' media');doc_in_media=one_offset(media,doc,name+' document');doc_at=media_at+doc_in_media
        check(struct.unpack_from('<II',media)==(0x52d8ccd9,row['media_flags']),'Observed media flags '+name)
        check(struct.unpack_from('<IIqq',doc)==(0x8fd4c4d8,row['document_flags'],987654321,0x1020304050607080),'Observed document fields '+name)
        ref,at,_=tlbytes(doc,24);check(ref==bytes((17,35,53)),'Native file reference '+name)
        check(struct.unpack_from('<I',doc,at)[0]==1789990000,'Native document date '+name);at+=4
        mime,at,_=tlbytes(doc,at);mime=mime.decode('utf-8')
        expected_mime='audio/ogg' if any(a['class']=='TL_documentAttributeAudio' for a in row['attributes']) else 'image/png' if any(a['class']=='TL_documentAttributeImageSize' for a in row['attributes']) else 'video/mp4'
        check(mime==expected_mime,'Native input MIME '+name)
        check(struct.unpack_from('<q',doc,at)[0]==4294967419,'Native int64 size '+name);at+=8
        thumb_ranges=[]
        for bit,suffix,count in [(1,'thumb-vector',row['thumbs']),(2,'video-thumb-vector',row['video_thumbs'])]:
            if row['document_flags']&bit:
                vector=(folder/(name+'.'+suffix)).read_bytes()
                check(struct.unpack_from('<II',vector)==(vector_ctor,count),'Native thumbnail vector header '+name+' '+suffix)
                check(doc[at:at+len(vector)]==vector,'Native thumbnail vector placement '+name+' '+suffix)
                pieces=[(folder/(name+'.'+('thumb-' if bit==1 else 'video-thumb-')+str(i))).read_bytes() for i in range(count)]
                check(vector[8:]==b''.join(pieces),'Native thumbnail vector components '+name+' '+suffix)
                at+=len(vector)
        check(struct.unpack_from('<I',doc,at)[0]==2,'Native DC identifier '+name);at+=4
        check(doc[at:]==av and struct.unpack_from('<II',av)==(vector_ctor,len(row['attributes'])),'Native attribute vector placement/count '+name)
        attributes=[];attribute_at=doc_at+at+8
        for i,a in enumerate(row['attributes']):
            raw=(folder/(name+'.attribute-'+str(i))).read_bytes()
            check(struct.unpack_from('<I',raw)[0]==int(a['constructor'],16),'Native attribute constructor '+name+' '+str(i))
            check(body[attribute_at:attribute_at+len(raw)]==raw,'Native exact attribute range '+name+' '+str(i))
            attributes.append(dict(index=i,offset=attribute_at,bytes=len(raw),sha256=sha(raw),**a));attribute_at+=len(raw)
        check(attribute_at==doc_at+len(doc),'All attribute bytes consumed '+name)
        tail,end,_=tlbytes(blob,len(body));check(tail.decode('utf-8')=='../../never-follow/attributes-'+name+'.bin' and end==len(blob),'Exact Android attachment tail '+name)
        positive=dict(name=name,family=row['family'],profile_status=row['current_reader_profile'],product_execution='NOT_RUN',
            expected=dict(id=row['id'],date=row['date'],from_peer=dict(kind='user',id=77),peer=dict(kind='user',id=909),out=row['out'],text=row['text']),
            exact_sql=dict(mid=row['id'],uid=row['sql_uid'],date=row['date']),out=row['out'],expected_text_slots=row['expected_text_slots'],
            bytes=len(blob),tl_bytes=len(body),blob_sha256=sha(blob),tl_body_sha256=sha(body),blob_base64=base64.b64encode(blob).decode('ascii'),
            document_id=row['document_id'],declared_document_size=row['declared_size'],document_flags=row['document_flags'],media_flags=row['media_flags'],
            attributes=attributes,thumbs=row['thumbs'],video_thumbs=row['video_thumbs'],observed_mime=mime,
            native_offsets=dict(media=media_at,media_flags=media_at+4,document=doc_at,document_flags=doc_at+4,message_text=44),
            thumbnail_policy='Known own PNG or explicitly opaque/damaged thumbnail bytes; message text is separate; no full document attachment bytes are present')
        positives.append(positive)
        def mutation(suffix,data,reason,*,sql=None):
            controls.append(dict(name=name+'--'+suffix,parent=name,reason=reason,expected_native_text_slots=0,
                desired_bounded_profile_outcome='reject_native_attribution; untyped fragment output is not constrained',
                product_execution='NOT_RUN',provenance='Explicit mutation/scope change of exact native Java input, not a valid native serialization claim',
                bytes=len(data),blob_sha256=sha(data),blob_base64=base64.b64encode(data).decode('ascii'),tl_bytes=min(len(body),len(data)),
                native_parent_blob_sha256=sha(blob),exact_sql=positive['exact_sql'] if sql is None else sql,out=row['out']))
        mutation('truncated-body',blob[:len(body)-1],'Malformed TL body truncated before the independently observed native boundary')
        raw=bytearray(blob);struct.pack_into('<I',raw,attributes[0]['offset'],0xdeadbeef)
        mutation('unknown-attribute',bytes(raw),'Unknown attribute constructor in bounded pinned profile')
        raw=bytearray(blob);struct.pack_into('<I',raw,doc_at+4,row['document_flags']|0x80000000)
        mutation('unknown-document-flag',bytes(raw),'Uninterpreted high document flag outside pinned serializer fields')
        raw=bytearray(blob);struct.pack_into('<I',raw,media_at+4,row['media_flags']|0x40000000)
        mutation('unknown-media-flag',bytes(raw),'Uninterpreted high media flag outside pinned serializer fields')
        mutation('sql-dialog-mismatch',blob,'Valid native body paired with a contradictory SQL dialog; bare body parsing remains valid',sql=dict(positive['exact_sql'],uid=positive['exact_sql']['uid']+1))
        flagged=next((a for a in attributes if a['class'] in ('TL_documentAttributeVideo','TL_documentAttributeAudio')),None)
        if flagged:
            raw=bytearray(blob);at=flagged['offset']+4;flags=struct.unpack_from('<I',raw,at)[0];struct.pack_into('<I',raw,at,flags|0x80000000)
            mutation('unknown-attribute-flag',bytes(raw),'Uninterpreted high attribute flag outside pinned serializer fields')
    check(sum(p['expected_text_slots'] for p in positives)==30,'Thirty native text slots plus one intentionally empty-text case')
    corpus=HERE/'corpus';corpus.mkdir()
    sqlite_rows=[]
    for case in positives+controls:
        info=make_db(corpus/case['name']/'cache4.db',case,schema)
        sqlite_rows.append(dict(case=case['name'],path=case['name']+'/cache4.db',**info,native_blob_sha256=case['blob_sha256']))
    # A fresh second SQLite production verifies file bytes, not only SELECT output.
    replay=HERE/'sqlite-replay';replay.mkdir()
    for case in positives+controls:make_db(replay/case['name']/'cache4.db',case,schema)
    check(inv(corpus)==inv(replay),'All independent SQLite files deterministic')
    zip_path=HERE/'native-sqlite-cases.zip'
    with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for row in sqlite_rows:
            info=zipfile.ZipInfo(row['path'],(2026,11,3,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100444<<16
            archive.writestr(info,(corpus/row['path']).read_bytes())
    with zipfile.ZipFile(zip_path) as archive:
        check(archive.testzip() is None,'All SQLite ZIP CRCs valid')
        check(set(archive.namelist())=={r['path'] for r in sqlite_rows},'Exact SQLite ZIP closure')
        for row in sqlite_rows:check(sha(archive.read(row['path']))==row['sha256'],'ZIP member SHA '+row['case'])
    oracle=dict(schema=1,telegram_commit=COMMIT,status='INPUT_ONLY_OUTSIDE_CURRENT_READER_NOT_ACCEPTED',
        scope='Native Java serializers and native SQLite storage only; no reader/helper/application/device/server/recovery result',
        sql_schema=schema,sql_schema_sha256=sha(schema_raw),positive_cases=positives,mutation_controls=controls,sqlite_sources=sqlite_rows,
        baseline_profile_controls=1,outside_current_reader_profiles=30,expected_text_slots=30,
        control_policy='Native slots are desired strict future-profile expectations; current product was not executed and fragment counts are unknown')
    raw=(json.dumps(oracle,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n').encode('utf-8')
    (HERE/'oracle.json').write_bytes(raw)
    with (HERE/'oracle.json.gz').open('xb') as file:
        with gzip.GzipFile(fileobj=file,mode='wb',filename='',mtime=0,compresslevel=9) as stream:stream.write(raw)
    shutil_license=(HERE/'upstream/LICENSE').read_bytes();(HERE/'LICENSE').write_bytes(shutil_license)
    check(inv(HERE/'native-run-01')==original_inventory,'Native Java artifacts remained immutable during packaging')
    dump(HERE/'verification.json',dict(status='INPUT_PRODUCTION_PASSED_NOT_RECOVERY_ACCEPTANCE',checks=len(checks),check_names=checks,
        native_cases=len(positives),controls=len(controls),sqlite_sources=len(sqlite_rows),native_java_runs=2,native_sqlite_runs=2,
        native_output_files=len(original_inventory),sqlite_version=sqlite3.sqlite_version,raw_oracle_bytes=len(raw),raw_oracle_sha256=sha(raw),
        source_manifest_sha256=sha((HERE/'source-manifest.json').read_bytes()),product_helper_parser_device_network=False))
    print(json.dumps(dict(status='INPUT_CORPUS_READY',cases=len(positives),controls=len(controls),sqlite_sources=len(sqlite_rows),checks=len(checks),oracle_sha256=sha(raw))))

if __name__=='__main__':main()
