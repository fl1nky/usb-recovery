import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.io.PrintStream;
import java.security.MessageDigest;
import java.util.*;
import org.telegram.tgnet.*;
import org.telegram.messenger.ApplicationLoader;

// Own input writer. Every TL serializer and SerializedData come from pinned upstream.
public final class AttributeOracle {
    static Path output;
    static byte[] png;
    static int count;
    static final String FILENAME = "ATTRIBUTE_FILENAME_пирожки.mp4";
    static final String TITLE = "ATTRIBUTE_TITLE_NOT_MESSAGE_第二行";
    static final String PERFORMER = "ATTRIBUTE_PERFORMER_NOT_MESSAGE_бабушка";
    static final class TraceData extends SerializedData {
        final ArrayList<Object> strings = new ArrayList<>();
        public void writeString(String value) {
            int before = length();
            super.writeString(value);
            strings.add(map("offset", before, "encoded_bytes", length()-before,
                            "utf8_base64", b64(value.getBytes(StandardCharsets.UTF_8))));
        }
    }
    static Map<String,Object> map(Object... pairs) {
        Map<String,Object> result = new LinkedHashMap<>();
        for (int n=0;n<pairs.length;n+=2) result.put((String)pairs[n], pairs[n+1]);
        return result;
    }
    static String b64(byte[] data) { return Base64.getEncoder().encodeToString(data); }
    static String sha(byte[] data) throws Exception {return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));}
    static String quote(String text) {
        StringBuilder out = new StringBuilder("\"");
        for (int n=0;n<text.length();n++) {
            char c=text.charAt(n);
            if(c=='"'||c=='\\') out.append('\\').append(c);
            else if(c<32) out.append(String.format(Locale.ROOT,"\\u%04x",(int)c));
            else out.append(c);
        }
        return out.append('"').toString();
    }
    static String json(Object value) {
        if(value==null) return "null";
        if(value instanceof String) return quote((String)value);
        if(value instanceof Boolean||value instanceof Number) return value.toString();
        if(value instanceof Map<?,?>) {
            ArrayList<String> parts=new ArrayList<>();
            for(Map.Entry<?,?> row:((Map<?,?>)value).entrySet()) parts.add(quote((String)row.getKey())+":"+json(row.getValue()));
            return "{"+String.join(",",parts)+"}";
        }
        if(value instanceof Iterable<?>) {
            ArrayList<String> parts=new ArrayList<>();
            for(Object item:(Iterable<?>)value) parts.add(json(item));
            return "["+String.join(",",parts)+"]";
        }
        throw new AssertionError("Unexpected metadata type");
    }
    static void save(String name,byte[] data)throws Exception {
        Files.write(output.resolve(name),data,StandardOpenOption.CREATE_NEW);
    }
    static byte[] serialized(TLObject object) {
        SerializedData data=new SerializedData();object.serializeToStream(data);return data.toByteArray();
    }
    static byte[] vector(ArrayList<TLObject> values) {
        SerializedData data=new SerializedData();org.telegram.tgnet.Vector.serialize(data,values);return data.toByteArray();
    }
    static TLRPC.TL_peerUser peer(long id) {TLRPC.TL_peerUser p=new TLRPC.TL_peerUser();p.user_id=id;return p;}
    static TLRPC.TL_documentAttributeFilename filename() {TLRPC.TL_documentAttributeFilename a=new TLRPC.TL_documentAttributeFilename();a.file_name=FILENAME;return a;}
    static TLRPC.TL_documentAttributeVideo video(int flags,boolean round,boolean streaming,boolean silent) {
        TLRPC.TL_documentAttributeVideo a=new TLRPC.TL_documentAttributeVideo();a.flags=flags;a.duration=12.5;a.w=1920;a.h=1080;
        a.round_message=round;a.supports_streaming=streaming;a.nosound=silent;
        a.preload_prefix_size=4096;a.video_start_ts=2.25;a.video_codec="avc1";return a;
    }
    static TLRPC.TL_documentAttributeAudio audio(int flags,boolean voice) {
        TLRPC.TL_documentAttributeAudio a=new TLRPC.TL_documentAttributeAudio();a.flags=flags;a.voice=voice;a.duration=42;
        a.title=TITLE;a.performer=PERFORMER;a.waveform=new byte[13];for(int i=0;i<a.waveform.length;i++)a.waveform[i]=(byte)(17*i);return a;
    }
    static TLRPC.TL_documentAttributeImageSize image() {TLRPC.TL_documentAttributeImageSize a=new TLRPC.TL_documentAttributeImageSize();a.w=640;a.h=480;return a;}
    static TLRPC.TL_photoSize photo() {TLRPC.TL_photoSize p=new TLRPC.TL_photoSize();p.type="m";p.w=320;p.h=180;p.size=1234;return p;}
    static TLRPC.TL_photoSizeEmpty emptyPhoto() {TLRPC.TL_photoSizeEmpty p=new TLRPC.TL_photoSizeEmpty();p.type="s";return p;}
    static TLRPC.TL_photoCachedSize cached(boolean valid) {
        TLRPC.TL_photoCachedSize p=new TLRPC.TL_photoCachedSize();p.type="s";p.w=2;p.h=1;
        p.bytes=valid?png:"OPAQUE_THUMB_NOT_MESSAGE".getBytes(StandardCharsets.UTF_8);return p;
    }
    static TLRPC.TL_videoSize videoThumb(boolean timestamp) {
        TLRPC.TL_videoSize p=new TLRPC.TL_videoSize();p.flags=timestamp?1:0;p.type="v";p.w=320;p.h=180;p.size=4321;p.video_start_ts=1.25;return p;
    }
    static ArrayList<TLObject> list(TLObject... objects) {return new ArrayList<>(Arrays.asList(objects));}
    static Map<String,Object> attributeMetadata(TLObject object)throws Exception {
        TLRPC.DocumentAttribute a=(TLRPC.DocumentAttribute)object;
        Map<String,Object> result=map("class",object.getClass().getSimpleName(),"constructor",String.format(Locale.ROOT,"0x%08x",object.getClass().getField("constructor").getInt(null)));
        if(object instanceof TLRPC.TL_documentAttributeFilename)result.put("filename",a.file_name);
        if(object instanceof TLRPC.TL_documentAttributeVideo){
            result.putAll(map("flags",a.flags,"duration",a.duration,"width",a.w,"height",a.h,"round",a.round_message,"streaming",a.supports_streaming,"nosound",a.nosound));
            if((a.flags&4)!=0)result.put("preload",a.preload_prefix_size);
            if((a.flags&16)!=0)result.put("start",a.video_start_ts);
            if((a.flags&32)!=0)result.put("codec",a.video_codec);
        }
        if(object instanceof TLRPC.TL_documentAttributeAudio){
            result.putAll(map("flags",a.flags,"duration",(int)a.duration,"voice",a.voice));
            if((a.flags&1)!=0)result.put("title",a.title);
            if((a.flags&2)!=0)result.put("performer",a.performer);
            if((a.flags&4)!=0)result.put("waveform_base64",b64(a.waveform));
        }
        if(object instanceof TLRPC.TL_documentAttributeImageSize)result.putAll(map("width",a.w,"height",a.h));
        return result;
    }
    static void emit(String name,String family,ArrayList<TLObject> attrs,int docFlags,ArrayList<TLObject> thumbs,ArrayList<TLObject> videoThumbs,int mediaFlags,boolean video,boolean round,boolean voice,boolean spoiler,boolean nopremium,boolean emptyText,boolean outgoing)throws Exception {
        if(!name.matches("[a-z0-9-]+"))throw new AssertionError("Unsafe own case name");
        int id=2000+count,date=1790000000+count;
        TLRPC.TL_document document=new TLRPC.TL_document();document.id=987654321L;document.flags=docFlags;
        document.access_hash=0x1020304050607080L;document.file_reference=new byte[]{17,35,53};document.date=1789990000;
        boolean audioKind=attrs.stream().anyMatch(a->a instanceof TLRPC.TL_documentAttributeAudio);
        boolean imageKind=attrs.stream().anyMatch(a->a instanceof TLRPC.TL_documentAttributeImageSize);
        document.mime_type=audioKind?"audio/ogg":imageKind?"image/png":"video/mp4";
        for(TLObject a:attrs)if(a instanceof TLRPC.TL_documentAttributeFilename)((TLRPC.DocumentAttribute)a).file_name=FILENAME.replace(".mp4",audioKind?".ogg":imageKind?".png":".mp4");
        document.size=4294967419L;document.dc_id=2;document.thumbs=thumbs;document.video_thumbs=videoThumbs;
        for(TLObject a:attrs)document.attributes.add((TLRPC.DocumentAttribute)a);
        TLRPC.TL_messageMediaDocument media=new TLRPC.TL_messageMediaDocument();media.flags=mediaFlags;media.document=document;
        media.video=video;media.round=round;media.voice=voice;media.spoiler=spoiler;media.nopremium=nopremium;
        media.video_timestamp=2;media.ttl_seconds=30;
        TLRPC.TL_message message=new TLRPC.TL_message();message.flags=(1<<8)|(1<<9);message.id=id;message.date=date;
        message.from_id=peer(77);message.peer_id=peer(909);message.out=outgoing;
        message.message=emptyText?"":"Owned "+name+" recipe 🥧\n第二行";message.media=media;
        message.attachPath="../../never-follow/attributes-"+name+".bin";
        ApplicationLoader.testEnvironment=true;byte[] body=serialized(message);
        TraceData trace=new TraceData();message.serializeToStream(trace);
        if(!Arrays.equals(body,trace.toByteArray()))throw new AssertionError("Instrumentation changed wire bytes");
        ApplicationLoader.testEnvironment=false;byte[] blob=serialized(message);
        if(blob.length<=body.length||!Arrays.equals(body,Arrays.copyOf(blob,body.length)))throw new AssertionError("Native body boundary mismatch");
        save(name+".body",body);save(name+".blob",blob);save(name+".document",serialized(document));save(name+".media",serialized(media));
        save(name+".attribute-vector",vector(attrs));
        if((docFlags&1)!=0)save(name+".thumb-vector",vector(thumbs));
        if((docFlags&2)!=0)save(name+".video-thumb-vector",vector(videoThumbs));
        ArrayList<Object> attributes=new ArrayList<>();
        for(int i=0;i<attrs.size();i++){save(name+".attribute-"+i,serialized(attrs.get(i)));attributes.add(attributeMetadata(attrs.get(i)));}
        for(int i=0;i<thumbs.size();i++)save(name+".thumb-"+i,serialized(thumbs.get(i)));
        for(int i=0;i<videoThumbs.size();i++)save(name+".video-thumb-"+i,serialized(videoThumbs.get(i)));
        Map<String,Object> row=map("name",name,"family",family,"current_reader_profile",name.equals("baseline-filename")?"PROFILE_CONTROL_NOT_RUN":"OUTSIDE_CURRENT_READER_NOT_ACCEPTED",
            "id",id,"date",date,"sender",77,"peer",909,"out",outgoing,"sql_uid",outgoing?909:77,"text",message.message,
            "expected_text_slots",emptyText?0:1,"document_id","987654321","declared_size","4294967419","document_flags",document.flags,
            "media_flags",media.flags,"attributes",attributes,"thumbs",thumbs.size(),"video_thumbs",videoThumbs.size(),"string_writes",trace.strings,
            "body_bytes",body.length,"blob_bytes",blob.length,"body_sha256",sha(body),"blob_sha256",sha(blob),"thumbnail_png_sha256",sha(png));
        byte[] metadata=(json(row)+"\n").getBytes(StandardCharsets.UTF_8);save(name+".json",metadata);
        System.out.println(json(row));count++;
    }
    static void attr(String name,String family,TLObject attribute)throws Exception {emit(name,family,list(filename(),attribute),0,list(),list(),1,false,false,false,false,false,false,false);}
    static void media(String name,TLObject attribute,int flags,boolean video,boolean round,boolean voice,boolean spoiler,boolean premium)throws Exception {emit(name,"media-flags",attribute==null?list(filename()):list(filename(),attribute),0,list(),list(),flags,video,round,voice,spoiler,premium,false,false);}
    static void thumb(String name,int flags,ArrayList<TLObject> photos,ArrayList<TLObject> videos)throws Exception {emit(name,"thumb-vectors",list(filename()),flags,photos,videos,1,false,false,false,false,false,false,false);}
    public static void main(String[] args)throws Exception {
        if(args.length!=2)throw new AssertionError("Own output and PNG paths required");
        System.setOut(new PrintStream(System.out,true,StandardCharsets.UTF_8));
        output=Paths.get(args[0]);Files.createDirectory(output);png=Files.readAllBytes(Paths.get(args[1]));
        emit("baseline-filename","baseline",list(filename()),0,list(),list(),1,false,false,false,false,false,false,false);
        attr("video-basic","video",video(0,false,false,false));
        attr("video-streaming","video",video(0,false,true,false));
        attr("video-all-optional","video",video(4|16|32,false,true,false));
        attr("video-round-silent","video",video(0,true,true,true));
        attr("audio-basic","audio",audio(0,false));
        attr("audio-title-performer","audio",audio(1|2,false));
        attr("audio-voice-waveform","audio",audio(4,true));
        attr("audio-all-metadata","audio",audio(1|2|4,false));
        attr("animated","animated",new TLRPC.TL_documentAttributeAnimated());
        attr("image-size","image",image());
        emit("video-before-filename","video",list(video(0,false,true,false),filename()),0,list(),list(),1,false,false,false,false,false,false,true);
        emit("audio-before-filename","audio",list(audio(1|2,false),filename()),0,list(),list(),1,false,false,false,false,false,false,false);
        emit("image-before-filename","image",list(image(),filename()),0,list(),list(),1,false,false,false,false,false,false,false);
        emit("empty-text-audio-metadata","audio",list(filename(),audio(1|2,false)),0,list(),list(),1,false,false,false,false,false,true,false);
        media("media-video",video(0,false,true,false),1,true,false,false,false,false);
        media("media-spoiler-video",video(0,false,true,false),1,true,false,false,true,false);
        media("media-nopremium",null,1,false,false,false,false,true);
        media("media-voice",audio(4,true),1,false,false,true,false,false);
        media("media-round-video",video(0,true,true,false),1,true,true,false,false,false);
        media("media-ttl",null,1|4,false,false,false,false,false);
        media("media-video-timestamp",video(0,false,true,false),1|1024,true,false,false,false,false);
        thumb("doc-empty-thumbs-vector",1,list(),list());
        thumb("doc-empty-photo-thumb",1,list(emptyPhoto()),list());
        thumb("doc-photo-size",1,list(photo()),list());
        thumb("doc-cached-png",1,list(cached(true)),list());
        thumb("doc-cached-opaque",1,list(cached(false)),list());
        thumb("doc-two-photo-thumbs",1,list(photo(),cached(true)),list());
        thumb("doc-video-thumb",2,list(),list(videoThumb(false)));
        thumb("doc-video-thumb-start-ts",2,list(),list(videoThumb(true)));
        thumb("doc-both-thumb-vectors",3,list(photo()),list(videoThumb(true)));
        if(count!=31)throw new AssertionError("Incomplete own native case set: "+count);
    }
}
