import java.nio.file.*;
import org.telegram.tgnet.*;
public class OfficialWireOracle {
 public static void main(String[] args)throws Exception {
 Path target=Path.of(args[0]);Files.createDirectories(target);
 int directions=args.length>1?Integer.parseInt(args[1]):1;
 String[] messages={"TL_message","TL_message_layer226","TL_message_layer224","TL_message_layer222","TL_message_layer220","TL_message_layer216","TL_message_layer205","TL_message_layer199","TL_message_layer195","TL_message_layer180","TL_message_layer179","TL_message_layer176","TL_message_layer175","TL_message_layer173","TL_message_layer169","TL_message_layer135","TL_message_layer131","TL_message_layer123","TL_message_layer118"};String[] mediaNames={"TL_messageMediaPhoto","TL_messageMediaPhoto_layer223","TL_messageMediaPhoto_layer74","TL_messageMediaPhoto_layer68","TL_messageMediaPhoto_old"};int[] layers={232,226,224,222,220,216,205,199,195,180,179,176,175,173,169,135,131,123,118};
 for(int n=0;n<messages.length;n++)for(String mediaName:mediaNames){
  boolean hasCaption=mediaName.equals("TL_messageMediaPhoto_layer74")||mediaName.equals("TL_messageMediaPhoto_layer68");
  for(int mode=0;mode<(hasCaption?3:1);mode++){
   for(int direction=0;direction<directions;direction++){
   TLRPC.Message message=(TLRPC.Message)Class.forName("org.telegram.tgnet.TLRPC$"+messages[n]).getDeclaredConstructor().newInstance();
   TLRPC.MessageMedia media=(TLRPC.MessageMedia)Class.forName("org.telegram.tgnet.TLRPC$"+mediaName).getDeclaredConstructor().newInstance();
   TLRPC.Photo photo=new TLRPC.TL_photoEmpty();photo.id=987654321L;media.photo=photo;media.flags=1;
   media.captionLegacy="Legacy recipe \uD83E\uDD67\ncaption \u7b2c\u4e8c\u884c";
   if(mediaName.equals("TL_messageMediaPhoto_layer74"))media.flags|=2;
   message.id=41;message.date=1790000000;message.media=media;
   message.message=mode==1?"":"Outer recipe \uD83E\uDD67\nsecond \u7b2c\u4e8c\u884c";
   message.from_id=layers[n]<=131?new TLRPC.TL_peerUser_layer131():new TLRPC.TL_peerUser();message.from_id.user_id=77;
   message.peer_id=layers[n]<=131?new TLRPC.TL_peerUser_layer131():new TLRPC.TL_peerUser();message.peer_id.user_id=909;
   message.flags=256|512;
   long uid=77;
   if(direction==1){message.from_id.user_id=909;message.peer_id.user_id=77;message.out=true;}
   if(direction==2){message.peer_id=layers[n]<=131?new TLRPC.TL_peerChat_layer131():new TLRPC.TL_peerChat();message.peer_id.chat_id=88;uid=-88;}
   if(direction==3){message.peer_id=layers[n]<=131?new TLRPC.TL_peerChannel_layer131():new TLRPC.TL_peerChannel();message.peer_id.channel_id=99;uid=-99;}
   if(direction==4){message.from_id=null;message.peer_id.user_id=77;message.flags=512;}
   if(mode==2){message.flags|=1024|32768;message.views=8;message.forwards=3;message.edit_date=1790000060;}
   SerializedData output=new SerializedData();message.serializeToStream(output);
   byte[] blob=output.toByteArray();if(message.tlBoundary<=0||message.tlBoundary>=blob.length)throw new IllegalStateException("Boundary not captured");
   String name=layers[n]+"-"+mediaName+"-mode"+mode+(directions>1?"-dir"+direction:"");Files.write(target.resolve(name+".bin"),blob);
   System.out.println(name+"\t"+layers[n]+"\t"+String.format("0x%08x",message.getClass().getField("constructor").getInt(null))+"\t"+String.format("0x%08x",media.getClass().getField("constructor").getInt(null))+"\t"+message.tlBoundary+"\t"+mode+(directions>1?"\t"+direction+"\t"+uid:""));
   }
  }
 }
 }
}
