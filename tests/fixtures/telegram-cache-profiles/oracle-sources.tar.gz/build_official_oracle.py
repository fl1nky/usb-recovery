"""Private audit oracle: exact upstream serializer bodies and upstream writer."""
from pathlib import Path
import hashlib
import json
import re
import shutil

ROOT = Path(__file__).resolve().parent
UP = ROOT / 'upstream/TMessagesProj/src/main/java/org/telegram/tgnet'
JAVA = ROOT / 'oracle-src'
TG = JAVA / 'org/telegram/tgnet'
TG.mkdir(parents=True, exist_ok=True)
source = {name: (UP / name).read_text(encoding='utf8') for name in ('TLRPC.java', 'tl/legacy/TL_legacy_message.java', 'Vector.java')}

def end_brace(text, at):
    depth, state = 0, None
    i = at
    while i < len(text):
        c = text[i]
        if state in ('"', "'"):
            if c == '\\':
                i += 2
                continue
            if c == state:
                state = None
        elif state == 'line':
            if c == '\n':
                state = None
        elif state == 'block':
            if text[i:i+2] == '*/':
                state = None
                i += 2
                continue
        elif text[i:i+2] in ('//', '/*'):
            state = 'line' if text[i:i+2] == '//' else 'block'
            i += 2
            continue
        elif c in ('"', "'"):
            state = c
        elif c == '{':
            depth += 1
        elif c == '}':
            depth -= 1
            if not depth:
                return i + 1
        i += 1
    raise ValueError('Unclosed official Java block')

extractions = []
def one_class(file, name, base):
    text = source[file]
    match = re.search(r'public static class ' + re.escape(name) + r'\b[^\{]*\{', text)
    if match is None:
        raise ValueError(name)
    end = end_brace(text, match.end()-1)
    body = text[match.end():end-1]
    constructor = re.search(r'public static final int constructor\s*=\s*(0x[a-fA-F0-9]+);', body)
    method_match = re.search(r'public void serializeToStream\(OutputSerializedData stream\)\s*\{', body)
    if not constructor or not method_match:
        raise ValueError(name + ' serialization unavailable')
    method_end = end_brace(body, method_match.end()-1)
    method = body[method_match.start():method_end]
    start_absolute = match.end() + method_match.start()
    record = dict(class_name=name, source=file, constructor=constructor.group(1),
        start_line=text[:start_absolute].count('\n')+1,
        end_line=text[:match.end()+method_end].count('\n')+1,
        method_sha256=hashlib.sha256(method.encode()).hexdigest(), exact_method=True)
    extractions.append(record)
    return f'public static class {name} extends {base} {{\npublic static final int constructor={constructor.group(1)};\n{method}\n}}\n'

layers = [232,226,224,222,220,216,205,199,195,180,179,176,175,173,169,135,131,123,118]
classes = []
message_code = []
for layer in layers:
    name = 'TL_message' if layer == 232 else f'TL_message_layer{layer}'
    code = one_class('TLRPC.java' if layer == 232 else 'tl/legacy/TL_legacy_message.java', name, 'Message' if layer == 232 else 'TLRPC.TL_message')
    classes.append(name)
    message_code.append(code)
media_names = ['TL_messageMediaPhoto','TL_messageMediaPhoto_layer223','TL_messageMediaPhoto_layer74','TL_messageMediaPhoto_layer68','TL_messageMediaPhoto_old']
media_code = [one_class('TLRPC.java', name, 'MessageMedia') for name in media_names]
peer_names = ['TL_peerUser','TL_peerChat','TL_peerChannel','TL_peerUser_layer131','TL_peerChat_layer131','TL_peerChannel_layer131']
peer_code = [one_class('TLRPC.java', name, 'Peer') for name in peer_names]
photo_code = one_class('TLRPC.java', 'TL_photoEmpty', 'Photo')
boolean_fields = sorted(set(re.findall(r'setFlag\(flags2?,\s*FLAG_\d+,\s*(\w+)\)', '\n'.join(message_code))))
base = '''package org.telegram.tgnet;
import java.util.ArrayList;
public class TLRPC {
public static class Peer extends TLObject { public long user_id,chat_id,channel_id; }
public static class Photo extends TLObject { public long id; }
public static class MessageMedia extends TLObject {
 public int flags,ttl_seconds;public boolean spoiler,live_photo;public Photo photo;public TLObject document;
 public String captionLegacy;
}
public static class Reply extends TLObject { public int reply_to_msg_id; }
public static class Message extends TLObject {
 public int flags,flags2,id,date,views,forwards,edit_date,ttl_period,quick_reply_shortcut_id,
 from_boosts_applied,report_delivery_until_date,schedule_repeat_period;
 public long via_bot_id,via_business_bot_id,grouped_id,effect,paid_message_stars;
 public String message,post_author,from_rank,summary_from_language;
 public Peer from_id,peer_id,saved_peer_id,guestchat_via_from;
 public TLObject fwd_from,reply_markup,replies,reactions,factcheck,suggested_post,rich_message;
 public Reply reply_to;public MessageMedia media;
 public ArrayList<TLObject> entities=new ArrayList<>(),restriction_reason=new ArrayList<>();
 public int tlBoundary;
 public void writeAttachPath(OutputSerializedData stream) {
   tlBoundary=((SerializedData)stream).length();stream.writeString("../../never-follow-oracle.jpg");
 }
 BOOLEAN_FIELDS
}
'''.replace('BOOLEAN_FIELDS', 'public boolean ' + ','.join(boolean_fields) + ';')
(TG / 'TLRPC.java').write_text(base + '\n'.join(message_code + media_code + peer_code + [photo_code]) + '\n}\n', encoding='utf8')
flags = '\n'.join(f'public static final int FLAG_{i}=1<<{i};' for i in range(32))
(TG / 'TLObject.java').write_text('''package org.telegram.tgnet;
public class TLObject {
FLAGS
public static boolean hasFlag(int value,int flag){return (value&flag)!=0;}
public static int setFlag(int value,int flag,boolean enabled){return enabled?value|flag:value&~flag;}
public void serializeToStream(OutputSerializedData stream){throw new UnsupportedOperationException("No fake nested serializer");}
}
'''.replace('FLAGS', flags), encoding='utf8')
vector_text = source['Vector.java']
vm = re.search(r'public static <T extends TLObject> void serialize\(OutputSerializedData stream, final ArrayList<T> objects\)\s*\{', vector_text)
vector_method = vector_text[vm.start():end_brace(vector_text, vm.end()-1)]
(TG / 'Vector.java').write_text('package org.telegram.tgnet;\nimport java.util.ArrayList;\npublic class Vector {public static final int constructor=0x1cb5c415;\n' + vector_method + '\n}\n', encoding='utf8')
extractions.append(dict(class_name='Vector', source='Vector.java', exact_method=True, method_sha256=hashlib.sha256(vector_method.encode()).hexdigest()))
for name in ('SerializedData.java','AbstractSerializedData.java','InputSerializedData.java','OutputSerializedData.java','TLDataSourceType.java'):
    shutil.copyfile(UP / name, TG / name)
(TG / 'NativeByteBuffer.java').write_text('package org.telegram.tgnet;public class NativeByteBuffer {}\n', encoding='utf8')
messenger = JAVA / 'org/telegram/messenger'
messenger.mkdir(parents=True, exist_ok=True)
(messenger / 'BuildVars.java').write_text('package org.telegram.messenger;public class BuildVars {public static final boolean LOGS_ENABLED=true;}\n', encoding='utf8')
(messenger / 'FileLog.java').write_text('package org.telegram.messenger;public class FileLog {public static void e(Object error){throw new IllegalStateException(String.valueOf(error));}}\n', encoding='utf8')

runner = '''import java.nio.file.*;
import org.telegram.tgnet.*;
public class OfficialWireOracle {
 public static void main(String[] args)throws Exception {
 Path target=Path.of(args[0]);Files.createDirectories(target);
 int directions=args.length>1?Integer.parseInt(args[1]):1;
 String[] messages={MESSAGES};String[] mediaNames={MEDIAS};int[] layers={LAYERS};
 for(int n=0;n<messages.length;n++)for(String mediaName:mediaNames){
  boolean hasCaption=mediaName.equals("TL_messageMediaPhoto_layer74")||mediaName.equals("TL_messageMediaPhoto_layer68");
  for(int mode=0;mode<(hasCaption?3:1);mode++){
   for(int direction=0;direction<directions;direction++){
   TLRPC.Message message=(TLRPC.Message)Class.forName("org.telegram.tgnet.TLRPC$"+messages[n]).getDeclaredConstructor().newInstance();
   TLRPC.MessageMedia media=(TLRPC.MessageMedia)Class.forName("org.telegram.tgnet.TLRPC$"+mediaName).getDeclaredConstructor().newInstance();
   TLRPC.Photo photo=new TLRPC.TL_photoEmpty();photo.id=987654321L;media.photo=photo;media.flags=1;
   media.captionLegacy="Legacy recipe \\uD83E\\uDD67\\ncaption \\u7b2c\\u4e8c\\u884c";
   if(mediaName.equals("TL_messageMediaPhoto_layer74"))media.flags|=2;
   message.id=41;message.date=1790000000;message.media=media;
   message.message=mode==1?"":"Outer recipe \\uD83E\\uDD67\\nsecond \\u7b2c\\u4e8c\\u884c";
   message.from_id=layers[n]<=131?new TLRPC.TL_peerUser_layer131():new TLRPC.TL_peerUser();message.from_id.user_id=77;
   message.peer_id=layers[n]<=131?new TLRPC.TL_peerUser_layer131():new TLRPC.TL_peerUser();message.peer_id.user_id=909;
   message.flags=256|512;
   long uid=77;
   if(direction==1){message.from_id.user_id=909;message.peer_id.user_id=77;message.out=true;}
   if(direction==2){message.peer_id=layers[n]<=131?new TLRPC.TL_peerChat_layer131():new TLRPC.TL_peerChat();message.peer_id.chat_id=88;uid=-88;}
   if(direction==3){message.peer_id=layers[n]<=131?new TLRPC.TL_peerChannel_layer131():new TLRPC.TL_peerChannel();message.peer_id.channel_id=99;uid=-99;}
   if(direction==4){message.from_id=null;message.peer_id.user_id=77;message.flags=512;}
   if(mode==2){message.flags|=1024|32768;message.views=8;message.forwards=3;message.edit_date=1790000060;}
   SerializedData output=new SerializedData();message.serializeToStream(output);
   byte[] blob=output.toByteArray();if(message.tlBoundary<=0||message.tlBoundary>=blob.length)throw new IllegalStateException("Boundary not captured");
   String name=layers[n]+"-"+mediaName+"-mode"+mode+(directions>1?"-dir"+direction:"");Files.write(target.resolve(name+".bin"),blob);
   System.out.println(name+"\\t"+layers[n]+"\\t"+String.format("0x%08x",message.getClass().getField("constructor").getInt(null))+"\\t"+String.format("0x%08x",media.getClass().getField("constructor").getInt(null))+"\\t"+message.tlBoundary+"\\t"+mode+(directions>1?"\\t"+direction+"\\t"+uid:""));
   }
  }
 }
 }
}
'''.replace('MESSAGES', ','.join(json.dumps(x) for x in classes)).replace('MEDIAS', ','.join(json.dumps(x) for x in media_names)).replace('LAYERS', ','.join(map(str,layers)))
(JAVA / 'OfficialWireOracle.java').write_text(runner, encoding='utf8')
(ROOT / 'oracle-extractions.json').write_text(json.dumps(dict(upstream_commit='4de548e79fed27f1a66fbdff84223321838fe925',
    message_profiles=19, photo_media=5, extracted_methods=extractions,
    stubs=['Message field container only','TLObject flag constants/bit helpers; unknown nested serialize throws',
           'writeAttachPath records TL boundary and writes one opaque literal using official SerializedData',
           'NativeByteBuffer type only; never used','BuildVars/FileLog fail-fast logger'],
    independent_of_recovery_python=True), indent=2) + '\n', encoding='utf8')
print(json.dumps(dict(classes=len(extractions), message_profiles=19, photo_media=5, source_files=len(list(JAVA.rglob('*.java'))))))
