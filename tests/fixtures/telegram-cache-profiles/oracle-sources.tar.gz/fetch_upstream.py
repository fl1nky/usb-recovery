from pathlib import Path
import concurrent.futures
import hashlib
import json
import urllib.request

ROOT = Path(__file__).resolve().parent
COMMIT = '4de548e79fed27f1a66fbdff84223321838fe925'
BASE = 'https://raw.githubusercontent.com/DrKLO/Telegram/' + COMMIT + '/'
FILES = ['TMessagesProj/src/main/java/org/telegram/tgnet/' + name for name in (
    'TLRPC.java', 'tl/legacy/TL_legacy_message.java', 'SerializedData.java',
    'AbstractSerializedData.java', 'TLObject.java', 'Vector.java',
    'InputSerializedData.java', 'OutputSerializedData.java', 'TLDataSourceType.java')]
FILES += ['TMessagesProj/src/main/java/org/telegram/messenger/' + name for name in (
    'MessagesStorage.java', 'MediaDataController.java', 'DatabaseMigrationHelper.java')]
FILES += ['LICENSE']

def one(relative):
    target = ROOT / 'upstream' / relative
    url = BASE + relative
    with urllib.request.urlopen(url, timeout=45) as response:
        data = response.read(8 * 1024 * 1024 + 1)
    if len(data) > 8 * 1024 * 1024:
        raise ValueError('Bounded upstream download exceeded')
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and target.read_bytes() != data:
        raise ValueError('Preserve existing different upstream copy')
    target.write_bytes(data)
    return dict(path=relative, url=url, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    items = list(pool.map(one, FILES))
(ROOT / 'upstream-manifest.json').write_text(json.dumps(dict(commit=COMMIT, files=items), indent=2) + '\n', encoding='utf8')
print(json.dumps(dict(files=len(items), bytes=sum(x['bytes'] for x in items))))
