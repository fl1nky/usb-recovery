"""Independent native oracle; no recovery imports, no handwritten golden TL."""
from pathlib import Path
import base64, gzip, hashlib, io, json, shutil, struct, subprocess, tarfile, time

HERE = Path(__file__).resolve().parent
MAIN = HERE.parents[2]
ASSESS = MAIN / '.build/telegram-next-format-assessment-20261103/v01-current-document'
WT = MAIN / '.build/worktrees/telegram-document-descriptor-20261103'
BUNDLE = WT / 'tests/fixtures/telegram-document-descriptor'
COMMIT = '4de548e79fed27f1a66fbdff84223321838fe925'
JDK = Path('C:/Program Files/Eclipse Adoptium/jdk-25.0.3.9-hotspot')

def sha(raw): return hashlib.sha256(raw).hexdigest()
def jsonfile(path, value): path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf8', newline='\n')
def method(source, signature):
    at=source.index(signature); start=source.index('{',at); depth=1; end=start+1
    while depth:
        depth+=(source[end]=='{')-(source[end]=='}');end+=1
    return source[at:end]

def run(args,name):
    t=time.monotonic();p=subprocess.run([str(a) for a in args],cwd=HERE,capture_output=True,timeout=90)
    (HERE/(name+'.stdout')).write_bytes(p.stdout);(HERE/(name+'.stderr')).write_bytes(p.stderr)
    row=dict(name=name,argv=[str(a) for a in args],exit_code=p.returncode,seconds=round(time.monotonic()-t,4),stdout_sha256=sha(p.stdout),stderr_sha256=sha(p.stderr))
    if p.returncode: raise RuntimeError(name+': '+p.stderr.decode('utf8','replace')[:4000])
    return row

def prepare():
    if BUNDLE.exists():raise ValueError('Existing bundle: no overwrite')
    BUNDLE.mkdir(parents=True)
    sources=HERE/'java-src';sources.mkdir();tg=sources/'org/telegram/tgnet';tg.mkdir(parents=True)
    evidence=json.loads((ASSESS/'source-evidence.json').read_text(encoding='utf8'))
    for item in evidence['official_sources']:
        raw=(ASSESS/item['local']).read_bytes()
        assert len(raw)==item['bytes'] and sha(raw)==item['sha256'],item['path']
    upstream=ASSESS/'upstream/TMessagesProj/src/main/java/org/telegram/tgnet'
    official=[]
    for name in ('SerializedData','AbstractSerializedData','InputSerializedData','OutputSerializedData','TLObject','Vector','TLDataSourceType'):
        raw=(upstream/(name+'.java')).read_bytes();(tg/(name+'.java')).write_bytes(raw)
        official.append(dict(path='org/telegram/tgnet/'+name+'.java',bytes=len(raw),sha256=sha(raw),unchanged=True))
    stubs={
      'org/telegram/messenger/BuildVars.java':'package org.telegram.messenger; public class BuildVars {public static final boolean LOGS_ENABLED=true;}',
      'org/telegram/messenger/FileLog.java':'package org.telegram.messenger; public class FileLog {public static void e(Object error){throw new AssertionError("Official SerializedData error: "+error);}}',
      'org/telegram/messenger/Utilities.java':'package org.telegram.messenger; public class Utilities {public interface Callback<T>{void run(T v);} public interface CallbackReturn<A,B>{B run(A v);}}',
      'org/telegram/messenger/ApplicationLoader.java':'package org.telegram.messenger; public class ApplicationLoader {public static boolean testEnvironment=false;public static boolean isAndroidTestEnvironment(){return testEnvironment;}}',
      'android/text/TextUtils.java':'package android.text; public class TextUtils {public static boolean isEmpty(CharSequence s){return s==null||s.length()==0;}}',
      'android/util/SparseArray.java':'package android.util; public class SparseArray<T>{public int size(){return 0;}public int keyAt(int i){throw new AssertionError("Unused poll scaffold");}public T valueAt(int i){throw new AssertionError("Unused poll scaffold");}}',
      'me/vkryl/core/BitwiseUtils.java':'package me.vkryl.core;public class BitwiseUtils {public static int setFlag(int f,int b,boolean v){return v?f|b:f&~b;}public static boolean hasFlag(int f,int b){return(f&b)!=0;}}',
      'org/telegram/tgnet/NativeByteBuffer.java':'package org.telegram.tgnet;public class NativeByteBuffer extends SerializedData {public NativeByteBuffer(boolean c){super(c);}public void rewind(){throw new AssertionError("Unused native buffer size path");}}',
      'org/telegram/tgnet/TLParseException.java':'package org.telegram.tgnet;public class TLParseException {public static void doThrowOrLog(InputSerializedData s,String n,int c,boolean e){throw new AssertionError("No official reader invoked: "+n);}}',
    }
    for name,text in stubs.items():
        p=sources/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text+'\n',encoding='utf8',newline='\n')
    spans={}
    for name in ('TL_message','TL_messageMediaDocument','TL_messageMediaDocument_layer74','TL_document','TL_documentEmpty','TL_documentAttributeFilename','TL_peerUser'):
        spans[name]=(ASSESS/f'official-methods/{name}.serializeToStream.java').read_bytes().decode('utf8').strip()
    spans['Message.writeAttachPath']=method((upstream/'TLRPC.java').read_bytes().decode('utf8'),'protected void writeAttachPath(OutputSerializedData stream)')
    container=(HERE/'TLRPC.template.java').read_text(encoding='utf8')
    for name,value in spans.items():container=container.replace('@'+name+'@',value)
    (tg/'TLRPC.java').write_bytes(container.encode('utf8'))
    (sources/'DescriptorOracle.java').write_bytes((HERE/'DescriptorOracle.java').read_bytes())
    methods=HERE/'official-methods';methods.mkdir()
    for name,value in spans.items():(methods/(name+'.java')).write_bytes((value+'\n').encode('utf8'))
    jsonfile(HERE/'source-manifest.json',dict(schema=1,commit=COMMIT,upstream_sources=evidence['official_sources'],unchanged_java=official,
      serializer_spans=[dict(name=n,sha256=sha(s.encode('utf8')),exact_text_embedded=True) for n,s in spans.items()],scaffolding=list(stubs),
      scaffold_policy='Unsupported serialization/readers/native-buffer-size paths throw; full official SerializedData and Vector unchanged',
      body_boundary='Official writeAttachPath Android testEnvironment gate measures body; separate false native serialization must have exact same prefix'))

if __name__=='__main__':
    prepare();classes=HERE/'classes';classes.mkdir()
    runs=[run([JDK/'bin/java.exe','-version'],'java-version'),run([JDK/'bin/javac.exe','-version'],'javac-version')]
    runs.append(run([JDK/'bin/javac.exe','-encoding','UTF-8','-d',classes]+sorted((HERE/'java-src').rglob('*.java')),'javac'))
    runs.append(run([JDK/'bin/java.exe','-cp',classes,'DescriptorOracle'],'java-run'))
    jsonfile(HERE/'native-run-receipt.json',dict(schema=0,status='PASS',scope='Actual independent Java serialization only; not product recovery',commit=COMMIT,runs=runs,
      tools=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in (JDK/'bin/java.exe',JDK/'bin/javac.exe')],no_parser_helper_app_network_device=True))
    print('Native Java oracle completed')
