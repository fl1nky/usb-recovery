import java.nio.file.*;
import java.util.*;
import java.nio.charset.StandardCharsets;
import org.telegram.tgnet.*;
import org.telegram.messenger.ApplicationLoader;
public class DescriptorOracle {
 static final String TEXT="Owned current document recipe 🥧\nsecond 第二行";
 static final String FILE="../../never-follow/owned_recipe.txt";
 static int count=0;
 static TLRPC.TL_peerUser peer(long id){TLRPC.TL_peerUser p=new TLRPC.TL_peerUser();p.user_id=id;return p;}
 static String b64(String s){return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8));}
 static byte[] serialized(TLObject object){SerializedData s=new SerializedData();object.serializeToStream(s);return s.toByteArray();}
 static void emit(String name,long docid,long size,boolean filename,boolean empty,boolean legacy,String text,String caption,int refs,boolean out)throws Exception{
  TLRPC.Document document;
  if(empty){document=new TLRPC.TL_documentEmpty();document.id=docid;}
  else{
   TLRPC.TL_document d=new TLRPC.TL_document();d.id=docid;d.flags=0;d.access_hash=0x1020304050607080L;
   d.file_reference=new byte[refs];for(int i=0;i<refs;i++)d.file_reference[i]=(byte)((i*29+17)&255);
   d.date=1789990000;d.mime_type="text/plain";d.size=size;d.dc_id=2;
   if(filename){TLRPC.TL_documentAttributeFilename a=new TLRPC.TL_documentAttributeFilename();a.file_name=FILE;d.attributes.add(a);}
   document=d;
  }
  TLRPC.MessageMedia media=legacy?new TLRPC.TL_messageMediaDocument_layer74():new TLRPC.TL_messageMediaDocument();
  media.flags=legacy?3:1;media.document=document;media.captionLegacy=caption;
  TLRPC.TL_message message=new TLRPC.TL_message();message.flags=(1<<8)|(1<<9);message.id=41;message.date=1790000000;
  message.from_id=peer(77);message.peer_id=peer(909);message.message=text;message.media=media;message.out=out;
  message.attachPath="../../never-follow/oracle-document.bin";
  ApplicationLoader.testEnvironment=true;byte[] body=serialized(message);
  ApplicationLoader.testEnvironment=false;byte[] full=serialized(message);
  if(full.length<=body.length||!Arrays.equals(body,Arrays.copyOf(full,body.length)))throw new AssertionError("Native tail boundary disagreement");
  Path folder=Paths.get("native-output");Files.createDirectories(folder);
  Files.write(folder.resolve(name+".blob"),full);Files.write(folder.resolve(name+".body"),body);
  Files.write(folder.resolve(name+".document"),serialized(document));Files.write(folder.resolve(name+".media"),serialized(media));
  System.out.println(String.join("\t",name,Long.toString(docid),Long.toString(size),Boolean.toString(filename),Boolean.toString(empty),Boolean.toString(legacy),Integer.toString(refs),Boolean.toString(out),Integer.toString(body.length),b64(text),caption==null?"-":b64(caption)));
  count++;
 }
 public static void main(String[] args)throws Exception{
  emit("descriptor-empty-attributes",987654321L,12345,false,false,false,TEXT,null,3,false);
  emit("descriptor-filename",987654321L,12345,true,false,false,TEXT,null,3,false);
  emit("descriptor-size64",987654321L,4294967419L,true,false,false,TEXT,null,3,false);
  emit("descriptor-size-zero",987654321L,0,true,false,false,TEXT,null,3,false);
  emit("descriptor-size-int64-max",987654321L,Long.MAX_VALUE,true,false,false,TEXT,null,3,false);
  emit("descriptor-id-zero",0,12345,true,false,false,TEXT,null,3,false);
  emit("descriptor-id-negative",-1,12345,true,false,false,TEXT,null,3,false);
  emit("descriptor-id-int64-min",Long.MIN_VALUE,12345,true,false,false,TEXT,null,3,false);
  emit("descriptor-id-int64-max",Long.MAX_VALUE,12345,true,false,false,TEXT,null,3,false);
  emit("descriptor-file-reference-empty",987654321L,12345,true,false,false,TEXT,null,0,false);
  emit("descriptor-file-reference-254",987654321L,12345,true,false,false,TEXT,null,254,false);
  emit("descriptor-outgoing",987654321L,12345,true,false,false,TEXT,null,3,true);
  emit("descriptor-empty-text",987654321L,12345,true,false,false,"",null,3,false);
  emit("descriptor-padding-one",987654321L,12345,true,false,false,"A",null,3,false);
  emit("descriptor-padding-two",987654321L,12345,true,false,false,"AB",null,3,false);
  emit("descriptor-padding-three",987654321L,12345,true,false,false,"ABC",null,3,false);
  emit("current-empty-id-positive",987654321L,0,false,true,false,TEXT,null,0,false);
  emit("current-empty-id-zero",0,0,false,true,false,TEXT,null,0,false);
  emit("current-empty-id-negative",-1,0,false,true,false,TEXT,null,0,false);
  emit("legacy-empty-two-text-slots",987654321L,0,false,true,true,TEXT,"Owned separate legacy caption 🥧",0,false);
  emit("legacy-empty-caption-only",-1,0,false,true,true,"","Owned separate legacy caption 🥧",0,false);
  if(count!=21)throw new AssertionError("Incomplete native case set");
 }
}
