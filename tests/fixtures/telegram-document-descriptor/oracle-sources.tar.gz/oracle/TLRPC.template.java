package org.telegram.tgnet;
import java.util.ArrayList;
import java.util.HashMap;
import android.text.TextUtils;
import android.util.SparseArray;
import org.telegram.messenger.ApplicationLoader;
public class TLRPC {
 public static final int LAYER=232,MESSAGE_FLAG_FWD=4;
 public static class Unsupported extends TLObject {public void serializeToStream(OutputSerializedData s){throw new AssertionError("Unsupported serializer executed");}}
 public static class Peer extends TLObject {public long user_id;}
 public static class TL_peerUser extends Peer {public static final int constructor=0x59511722; @TL_peerUser@ }
 public static class DocumentAttribute extends TLObject {public String file_name;}
 public static class TL_documentAttributeFilename extends DocumentAttribute {public static final int constructor=0x15590068; @TL_documentAttributeFilename@ }
 public static class Document extends TLObject {public int flags,date,dc_id;public long id,access_hash,size;public byte[] file_reference;public String mime_type;public ArrayList<TLObject> thumbs=new ArrayList<>(),video_thumbs=new ArrayList<>();public ArrayList<DocumentAttribute> attributes=new ArrayList<>();}
 public static class TL_document extends Document {public static final int constructor=0x8fd4c4d8; @TL_document@ }
 public static class TL_documentEmpty extends Document {public static final int constructor=0x36f8c871; @TL_documentEmpty@ }
 public static class MessageMedia extends TLObject {public int flags,video_timestamp,ttl_seconds;public boolean nopremium,spoiler,video,round,voice,live_photo;public TLObject webpage,video_cover;public Document document;public String captionLegacy;public ArrayList<Document> alt_documents=new ArrayList<>();}
 public static class TL_messageMediaDocument extends MessageMedia {public static final int constructor=0x52d8ccd9; @TL_messageMediaDocument@ }
 public static class TL_messageMediaDocument_layer74 extends MessageMedia {public static final int constructor=0x7c4414d3; @TL_messageMediaDocument_layer74@ }
 public static class TL_messageMediaPoll extends MessageMedia {}
 public static class Message extends TLObject {
  public int flags,flags2,id,date,from_boosts_applied,views,forwards,edit_date,ttl_period,quick_reply_shortcut_id,report_delivery_until_date,schedule_repeat_period;
  public long via_bot_id,via_business_bot_id,grouped_id,effect,paid_message_stars;
  public boolean out,mentioned,media_unread,silent,post,from_scheduled,legacy,edit_hide,pinned,noforwards,invert_media,offline,video_processing_pending,paid_suggested_post_stars,paid_suggested_post_ton;
  public String from_rank,message,post_author,summary_from_language,attachPath;
  public TLObject from_id,peer_id,saved_peer_id,fwd_from,guestchat_via_from,reply_to,reply_markup,replies,reactions,factcheck,suggested_post,rich_message;
  public ArrayList<TLObject> entities=new ArrayList<>(),restriction_reason=new ArrayList<>();
  public MessageMedia media;public int send_state,layer,fwd_msg_id;public HashMap<String,String> params;public SparseArray<String> pollMediaAttachPaths;
  @Message.writeAttachPath@
 }
 public static class TL_message_secret extends Message {}
 public static class TL_message_secret_layer72 extends Message {}
 public static class TL_message extends Message {public static final int constructor=0x7600b9d3; @TL_message@ }
}
