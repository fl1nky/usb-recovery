"""Package observed Java output and explicit adversarial mutations, no parser."""
from build_native_oracle import *

def inspect(blob,boundary):
    offsets={};pos=0
    def u32(name):
        nonlocal pos
        offsets[name]=pos;value=struct.unpack_from('<I',blob,pos)[0];pos+=4;return value
    def i64(name):
        nonlocal pos
        offsets[name]=pos;value=struct.unpack_from('<q',blob,pos)[0];pos+=8;return value
    def tlbytes(name):
        nonlocal pos
        offsets[name]=pos;first=blob[pos]
        assert first<=254
        size,header=(int.from_bytes(blob[pos+1:pos+4],'little'),4) if first==254 else (first,1)
        raw=blob[pos+header:pos+header+size];assert len(raw)==size
        padding=-(header+size)%4
        offsets.update({name+'_data':pos+header,name+'_length':size,name+'_padding':pos+header+size,name+'_padding_bytes':padding})
        assert blob[pos+header+size:pos+header+size+padding]==b'\0'*padding
        pos+=header+size+padding;return raw
    assert u32('message_constructor')==0x7600b9d3
    assert u32('message_flags') in (768,770)
    assert u32('message_flags2')==0 and u32('message_id')==41
    assert u32('sender_constructor')==0x59511722 and i64('sender_id')==77
    assert u32('peer_constructor')==0x59511722 and i64('peer_id')==909
    assert u32('message_date')==1790000000
    tlbytes('message_text').decode('utf8','strict')
    media=u32('media_constructor');assert media in (0x52d8ccd9,0x7c4414d3)
    assert u32('media_flags')==(1 if media==0x52d8ccd9 else 3)
    ctor=u32('document_constructor')
    if ctor==0x8fd4c4d8:
        assert u32('document_flags')==0
        i64('document_id');i64('access_hash');tlbytes('file_reference');u32('document_date')
        tlbytes('mime_type').decode('utf8','strict');i64('document_size');u32('dc_id')
        assert u32('attributes_constructor')==0x1cb5c415
        count=u32('attributes_count');assert count in (0,1)
        if count:
            assert u32('attribute_constructor')==0x15590068
            tlbytes('filename').decode('utf8','strict')
    else:
        assert ctor==0x36f8c871;i64('document_id')
    if media==0x7c4414d3:tlbytes('legacy_caption').decode('utf8','strict')
    assert pos==boundary,(pos,boundary)
    assert tlbytes('attach_path')==b'../../never-follow/oracle-document.bin'
    assert pos==len(blob)
    return offsets

def produce():
    rows=[]
    for line in (HERE/'java-run.stdout').read_text(encoding='utf8').splitlines():
        name,docid,size,filename,empty,legacy,refs,out,boundary,text64,caption64=line.split('\t')
        blob=(HERE/'native-output'/(name+'.blob')).read_bytes();body=(HERE/'native-output'/(name+'.body')).read_bytes()
        assert len(body)==int(boundary) and blob.startswith(body)
        text=base64.b64decode(text64).decode('utf8');caption=None if caption64=='-' else base64.b64decode(caption64).decode('utf8')
        row=dict(name=name,layer=232,constructor='0x7600b9d3',media_constructor='0x7c4414d3' if legacy=='true' else '0x52d8ccd9',
          media_flags=3 if legacy=='true' else 1,document_id=docid,document_kind='empty' if empty=='true' else 'descriptor',
          declared_document_size=None if empty=='true' else int(size),filename_present=filename=='true',file_reference_bytes=int(refs),
          expected=dict(id=41,text=text,date=1790000000,from_peer=dict(kind='user',id=77),peer=dict(kind='user',id=909),out=out=='true',layer=232,constructor='0x7600b9d3'),
          expected_legacy_caption=caption,exact_sql=dict(mid=41,uid=909 if out=='true' else 77,date=1790000000),bytes=len(blob),tl_bytes=len(body),
          blob_sha256=sha(blob),tl_body_sha256=sha(body),blob_base64=base64.b64encode(blob).decode('ascii'),native_offsets=inspect(blob,len(body)),
          expected_outcome='no_native_text' if not text and not caption else 'native_text')
        rows.append(row)
    assert len(rows)==21
    schema=(ASSESS/'messages-v2-schema.sql').read_bytes().decode('utf8')
    controls=[];source=next(r for r in rows if r['name']=='descriptor-filename')
    raw=base64.b64decode(source['blob_base64']);offsets=source['native_offsets']
    def mutate(name,reason,data,*,parent=source,sql=None,outcome='parser_reject',boundary=None):
        # For a malformed body the observed prefix boundary is capped at actual
        # bytes. It is never advertised as a successfully parsed native body.
        n=min(parent['tl_bytes'],len(data)) if boundary is None else boundary
        controls.append(dict(name=name,parent=parent['name'],reason=reason,expected_outcome=outcome,expected_native_parts=0,
          blob_base64=base64.b64encode(data).decode('ascii'),bytes=len(data),blob_sha256=sha(data),tl_bytes=n,tl_body_sha256=sha(data[:n]),
          exact_sql=dict(parent['exact_sql']) if sql is None else sql,native_parent_blob_sha256=parent['blob_sha256'],
          provenance='Explicit mutation of exact native Java bytes; malformed/unsupported control, not claimed valid official serialization'))
    def replace32(key,value):
        b=bytearray(raw);struct.pack_into('<I',b,offsets[key],value);return bytes(b)
    for bit in (0,1,7,31):mutate(f'reject-document-flags-bit{bit}','Unsupported document flags; no unknown-field skipping',replace32('document_flags',1<<bit))
    for bit in (2,3,4,5,6,7,8,9,10,11,12,31):mutate(f'reject-media-flags-bit{bit}','Beyond first-scope exact media flags=1',replace32('media_flags',1|(1<<bit)))
    mutate('reject-media-missing-document','Current direct media without present document is unsupported first scope',replace32('media_flags',0))
    for key,label in (('document_constructor','document'),('attribute_constructor','attribute'),('attributes_constructor','attribute-vector-tag')):
        mutate('reject-unknown-'+label,'No constructor skipping',replace32(key,0x11223344))
    mutate('reject-attribute-count-minus-one','Negative vector count',replace32('attributes_count',0xffffffff))
    mutate('reject-attribute-count-two-truncated','Count claims absent second attribute',replace32('attributes_count',2))
    attr=raw[offsets['attribute_constructor']:source['tl_bytes']]
    b=bytearray(raw[:source['tl_bytes']]+attr+raw[source['tl_bytes']:]);struct.pack_into('<I',b,offsets['attributes_count'],2)
    mutate('reject-duplicate-filename-attribute','Two complete filename records exceed narrow scope',bytes(b),boundary=source['tl_bytes']+len(attr))
    for key in ('message_text','mime_type','filename'):
        b=bytearray(raw);b[offsets[key+'_data']]=0xff
        mutate('reject-invalid-utf8-'+key.replace('_','-'),'Malformed UTF8',bytes(b))
    for key in ('message_text','mime_type','filename','attach_path'):
        if offsets[key+'_padding_bytes']:
            b=bytearray(raw);b[offsets[key+'_padding']]=0x7f
            mutate('reject-padding-'+key.replace('_','-'),'Nonzero TL padding',bytes(b))
    # Reference length 0 has three padding bytes; native reference3 has none.
    padsource=next(r for r in rows if r['name']=='descriptor-file-reference-empty')
    b=bytearray(base64.b64decode(padsource['blob_base64']));b[padsource['native_offsets']['file_reference_padding']]=0x7f
    mutate('reject-padding-file-reference','Nonzero byte-array padding',bytes(b),parent=padsource)
    for cut in (offsets['document_id']+7,offsets['file_reference_data']+1,offsets['document_size']+7,offsets['attributes_count']+3,source['tl_bytes']-1):
        mutate('reject-truncated-at-'+str(cut),'Truncated body at native field boundary',raw[:cut])
    mutate('reject-extra-tail','Unknown bytes after native attachPath',raw+b'owned-unrecognized-tail')
    mutate('reject-extra-before-attach-path','Unknown body bytes before valid native tail',raw[:source['tl_bytes']]+b'\x11\x22\x33\x44'+raw[source['tl_bytes']:],boundary=source['tl_bytes']+4)
    mutate('reject-outer-constructor','New media must not widen other outer profiles',replace32('message_constructor',0x9815cec8),outcome='scope_reject')
    legacy=next(r for r in rows if r['name']=='legacy-empty-two-text-slots');b=bytearray(base64.b64decode(legacy['blob_base64']))
    struct.pack_into('<I',b,legacy['native_offsets']['document_constructor'],0x8fd4c4d8)
    mutate('reject-legacy-empty-tag-only-full-document','Tag replacement alone cannot manufacture complete Document',bytes(b),parent=legacy)
    for key,value in (('mid',42),('date',1790000001),('uid',1111),('uid',77<<32)):
        sql=dict(source['exact_sql']);sql[key]=value
        mutate('reject-sql-'+key+'-'+str(value),'SQL/body identity or dialog scope mismatch',raw,sql=sql,outcome='scope_reject')
    payload=dict(schema=1,commit=COMMIT,sql_schema=schema,positive_cases=rows,mutation_controls=controls,
      oracle_provenance='Actually executed pinned official Java serializer methods + unchanged SerializedData/Vector; no recovery code imported',
      scope='Descriptor references only. Filename/MIME/access_hash/file_reference/size are consumed framing, never invented text or retrieved file bytes.')
    rawpayload=(json.dumps(payload,ensure_ascii=False,separators=(',',':'))+'\n').encode('utf8')
    assert len(rawpayload)<=2*1024*1024
    (HERE/'oracle.json').write_bytes(rawpayload)
    (BUNDLE/'oracle.json.gz').write_bytes(gzip.compress(rawpayload,mtime=0))
    archive=io.BytesIO()
    with tarfile.open(fileobj=archive,mode='w',format=tarfile.PAX_FORMAT) as tf:
        entries={}
        for path in (ASSESS/'upstream').rglob('*'):
            if path.is_file():entries['upstream/'+path.relative_to(ASSESS/'upstream').as_posix()]=path.read_bytes()
        for folder,prefix in ((HERE/'java-src','oracle/java-src/'),(HERE/'official-methods','oracle/official-methods/')):
            for path in folder.rglob('*'):
                if path.is_file():entries[prefix+path.relative_to(folder).as_posix()]=path.read_bytes()
        for name in ('build_native_oracle.py','package_oracle.py','TLRPC.template.java','DescriptorOracle.java','source-manifest.json','native-run-receipt.json','java-run.stdout','java-run.stderr','javac.stdout','javac.stderr','java-version.stdout','java-version.stderr','javac-version.stdout','javac-version.stderr'):
            entries['oracle/'+name]=(HERE/name).read_bytes()
        for name,data in sorted(entries.items()):
            info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(data))
    (BUNDLE/'oracle-sources.tar.gz').write_bytes(gzip.compress(archive.getvalue(),mtime=0))
    shutil.copyfile(ASSESS/'upstream/LICENSE',BUNDLE/'LICENSE')
    manifest=dict(schema=1,telegram_commit=COMMIT,cases=len(rows),positive_cases=len(rows),mutation_controls=len(controls),
      uncompressed_json_bytes=len(rawpayload),uncompressed_json_sha256=sha(rawpayload),native_sql_schema_sha256=sha(schema.encode('utf8')),
      java_source_manifest_sha256=sha((HERE/'source-manifest.json').read_bytes()),
      files=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(BUNDLE.iterdir()) if p.name in {'oracle.json.gz','oracle-sources.tar.gz','LICENSE'}],
      native_oracle_executed=True,recovery_parser_imported=False,product_recovery_run=False,current_descriptor_cases=16,current_empty_controls=3,legacy_empty_controls=2)
    jsonfile(BUNDLE/'manifest.json',manifest)
    jsonfile(HERE/'oracle-summary.json',dict(cases=len(rows),mutation_controls=len(controls),manifest_sha256=sha((BUNDLE/'manifest.json').read_bytes()),
      case_pins=[{k:r[k] for k in ('name','blob_sha256','tl_body_sha256','bytes','tl_bytes','document_id','document_kind')} for r in rows]))
    print(json.dumps(dict(positive_cases=len(rows),mutation_controls=len(controls),manifest_sha256=sha((BUNDLE/'manifest.json').read_bytes())),indent=2))

if __name__=='__main__':produce()
