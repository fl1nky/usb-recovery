package org.telegram.tgnet;
import java.util.ArrayList;
import java.util.HashMap;
import android.text.TextUtils;
import android.util.SparseArray;
import org.telegram.messenger.ApplicationLoader;
public class TLRPC {
 public static final int LAYER=232,MESSAGE_FLAG_FWD=4;
 public static class Unsupported extends TLObject {public void serializeToStream(OutputSerializedData s){throw new AssertionError("Unsupported serializer executed");}}
 public static class Peer extends TLObject {public long user_id;}
 public static class TL_peerUser extends Peer {public static final int constructor=0x59511722; public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt64(user_id);
        } }
 public static class DocumentAttribute extends TLObject {public String file_name,title,performer,video_codec;public double duration,video_start_ts;public int flags,w,h,preload_prefix_size;public boolean round_message,supports_streaming,nosound,voice;public byte[] waveform;}
 public static class TL_documentAttributeFilename extends DocumentAttribute {public static final int constructor=0x15590068; public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeString(file_name);
        } }
 public static class Document extends TLObject {public int flags,date,dc_id;public long id,access_hash,size;public byte[] file_reference;public String mime_type;public ArrayList<TLObject> thumbs=new ArrayList<>(),video_thumbs=new ArrayList<>();public ArrayList<DocumentAttribute> attributes=new ArrayList<>();}
 public static class TL_document extends Document {public static final int constructor=0x8fd4c4d8; public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt32(flags);
            stream.writeInt64(id);
            stream.writeInt64(access_hash);
            stream.writeByteArray(file_reference);
            stream.writeInt32(date);
            stream.writeString(mime_type);
            stream.writeInt64(size);
            if (hasFlag(flags, FLAG_0)) {
                Vector.serialize(stream, thumbs);
            }
            if (hasFlag(flags, FLAG_1)) {
                Vector.serialize(stream, video_thumbs);
            }
            stream.writeInt32(dc_id);
            Vector.serialize(stream, attributes);
        } }
 public static class TL_documentEmpty extends Document {public static final int constructor=0x36f8c871; public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt64(id);
        } }
 public static class MessageMedia extends TLObject {public int flags,video_timestamp,ttl_seconds;public boolean nopremium,spoiler,video,round,voice,live_photo;public TLObject webpage,video_cover;public Document document;public String captionLegacy;public ArrayList<Document> alt_documents=new ArrayList<>();}
 public static class TL_messageMediaDocument extends MessageMedia {public static final int constructor=0x52d8ccd9; public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_3, nopremium);
            flags = setFlag(flags, FLAG_4, spoiler);
            flags = setFlag(flags, FLAG_6, video);
            flags = setFlag(flags, FLAG_7, round);
            flags = setFlag(flags, FLAG_8, voice);
            flags = setFlag(flags, FLAG_11, live_photo);
            flags = setFlag(flags, FLAG_12, webpage != null);
            stream.writeInt32(flags);
            if (hasFlag(flags, FLAG_0)) {
                document.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_5)) {
                Vector.serialize(stream, alt_documents);
            }
            if (hasFlag(flags, FLAG_9)) {
                video_cover.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(video_timestamp);
            }
            if (hasFlag(flags, FLAG_2)) {
                stream.writeInt32(ttl_seconds);
            }
        } }
 public static class TL_messageMediaDocument_layer74 extends MessageMedia {public static final int constructor=0x7c4414d3; public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt32(flags);
            if (hasFlag(flags, FLAG_0)) {
                document.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_1)) {
                stream.writeString(captionLegacy);
            }
            if (hasFlag(flags, FLAG_2)) {
                stream.writeInt32(ttl_seconds);
            }
        } }
 public static class TL_messageMediaPoll extends MessageMedia {}
 public static class Message extends TLObject {
  public int flags,flags2,id,date,from_boosts_applied,views,forwards,edit_date,ttl_period,quick_reply_shortcut_id,report_delivery_until_date,schedule_repeat_period;
  public long via_bot_id,via_business_bot_id,grouped_id,effect,paid_message_stars;
  public boolean out,mentioned,media_unread,silent,post,from_scheduled,legacy,edit_hide,pinned,noforwards,invert_media,offline,video_processing_pending,paid_suggested_post_stars,paid_suggested_post_ton;
  public String from_rank,message,post_author,summary_from_language,attachPath;
  public TLObject from_id,peer_id,saved_peer_id,fwd_from,guestchat_via_from,reply_to,reply_markup,replies,reactions,factcheck,suggested_post,rich_message;
  public ArrayList<TLObject> entities=new ArrayList<>(),restriction_reason=new ArrayList<>();
  public MessageMedia media;public int send_state,layer,fwd_msg_id;public HashMap<String,String> params;public SparseArray<String> pollMediaAttachPaths;
  protected void writeAttachPath(OutputSerializedData stream) {
            if (ApplicationLoader.isAndroidTestEnvironment()) {
                return;
            }

            if (this instanceof TL_message_secret || this instanceof TL_message_secret_layer72) {
                String path = attachPath != null ? attachPath : "";
                if (send_state == 1 && params != null && params.size() > 0) {
                    for (HashMap.Entry<String, String> entry : params.entrySet()) {
                        path = entry.getKey() + "|=|" + entry.getValue() + "||" + path;
                    }
                    path = "||" + path;
                }
                stream.writeString(path);
            } else {
                String path = !TextUtils.isEmpty(attachPath) ? attachPath : " ";
                if (legacy) {
                    if (params == null) {
                        params = new HashMap<>();
                    }
                    layer = LAYER;
                    params.put("legacy_layer", "" + LAYER);
                }
                boolean isPollWithAttachedMedia = false;
                if (pollMediaAttachPaths != null && pollMediaAttachPaths.size() > 0 && media instanceof TL_messageMediaPoll) {
                    if (params == null) {
                        params = new HashMap<>();
                    }
                    for (int a = 0, N = pollMediaAttachPaths.size(); a < N; a++) {
                        final int pollIndex = pollMediaAttachPaths.keyAt(a);
                        final String pollAttachPath = pollMediaAttachPaths.valueAt(a);
                        params.put("poll_attach_path_at_" + pollIndex, pollAttachPath);
                    }
                    isPollWithAttachedMedia = true;
                }
                if ((id < 0 || send_state == 3 || legacy || isPollWithAttachedMedia) && params != null && params.size() > 0) {
                    for (HashMap.Entry<String, String> entry : params.entrySet()) {
                        path = entry.getKey() + "|=|" + entry.getValue() + "||" + path;
                    }
                    path = "||" + path;
                }
                if (isPollWithAttachedMedia) {
                    path = "poll_with_media=" + path;
                }
                stream.writeString(path);
                if ((flags & MESSAGE_FLAG_FWD) != 0 && id < 0) {
                    stream.writeInt32(fwd_msg_id);
                }
            }
        }
 }
 public static class TL_message_secret extends Message {}
 public static class TL_message_secret_layer72 extends Message {}
 public static class TL_message extends Message {public static final int constructor=0x7600b9d3; public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_1, out);
            flags = setFlag(flags, FLAG_4, mentioned);
            flags = setFlag(flags, FLAG_5, media_unread);
            flags = setFlag(flags, FLAG_13, silent);
            flags = setFlag(flags, FLAG_14, post);
            flags = setFlag(flags, FLAG_18, from_scheduled);
            flags = setFlag(flags, FLAG_19, legacy);
            flags = setFlag(flags, FLAG_21, edit_hide);
            flags = setFlag(flags, FLAG_24, pinned);
            flags = setFlag(flags, FLAG_26, noforwards);
            flags = setFlag(flags, FLAG_27, invert_media);
            stream.writeInt32(flags);
            flags2 = setFlag(flags2, FLAG_1, offline);
            flags2 = setFlag(flags2, FLAG_4, video_processing_pending);
            flags2 = setFlag(flags2, FLAG_7, suggested_post != null);
            flags2 = setFlag(flags2, FLAG_8, paid_suggested_post_stars);
            flags2 = setFlag(flags2, FLAG_9, paid_suggested_post_ton);
            flags2 = setFlag(flags2, FLAG_12, from_rank != null);
            flags2 = setFlag(flags2, FLAG_13, rich_message != null);
            flags2 = setFlag(flags2, FLAG_19, guestchat_via_from != null);
            stream.writeInt32(flags2);
            stream.writeInt32(id);
            if (hasFlag(flags, FLAG_8)) {
                from_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_29)) {
                stream.writeInt32(from_boosts_applied);
            }
            if (hasFlag(flags2, FLAG_12)) {
                stream.writeString(from_rank);
            }
            peer_id.serializeToStream(stream);
            if (hasFlag(flags, FLAG_28)) {
                saved_peer_id.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_2)) {
                fwd_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                stream.writeInt64(via_bot_id);
            }
            if (hasFlag(flags2, FLAG_0)) {
                stream.writeInt64(via_business_bot_id);
            }
            if (hasFlag(flags2, FLAG_19)) {
                guestchat_via_from.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_3)) {
                reply_to.serializeToStream(stream);
            }
            stream.writeInt32(date);
            stream.writeString(message);
            if (hasFlag(flags, FLAG_9)) {
                media.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_6)) {
                reply_markup.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_7)) {
                Vector.serialize(stream, entities);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(views);
            }
            if (hasFlag(flags, FLAG_10)) {
                stream.writeInt32(forwards);
            }
            if (hasFlag(flags, FLAG_23)) {
                replies.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_15)) {
                stream.writeInt32(edit_date);
            }
            if (hasFlag(flags, FLAG_16)) {
                stream.writeString(post_author);
            }
            if (hasFlag(flags, FLAG_17)) {
                stream.writeInt64(grouped_id);
            }
            if (hasFlag(flags, FLAG_20)) {
                reactions.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_22)) {
                Vector.serialize(stream, restriction_reason);
            }
            if (hasFlag(flags, FLAG_25)) {
                stream.writeInt32(ttl_period);
            }
            if (hasFlag(flags, FLAG_30)) {
                stream.writeInt32(quick_reply_shortcut_id);
            }
            if (hasFlag(flags2, FLAG_2)) {
                stream.writeInt64(effect);
            }
            if (hasFlag(flags2, FLAG_3)) {
                factcheck.serializeToStream(stream);
            }
            if (hasFlag(flags2, FLAG_5)) {
                stream.writeInt32(report_delivery_until_date);
            }
            if (hasFlag(flags2, FLAG_6)) {
                stream.writeInt64(paid_message_stars);
            }
            if (hasFlag(flags2, FLAG_7)) {
                suggested_post.serializeToStream(stream);
            }
            if (hasFlag(flags2, FLAG_10)) {
                stream.writeInt32(schedule_repeat_period);
            }
            if (hasFlag(flags2, FLAG_11)) {
                stream.writeString(summary_from_language);
            }
            if (hasFlag(flags2, FLAG_13)) {
                rich_message.serializeToStream(stream);
            }
            writeAttachPath(stream);
        } }

public static class TL_documentAttributeVideo extends DocumentAttribute {public static final int constructor = 0x43c57c48;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_0, round_message);
            flags = setFlag(flags, FLAG_1, supports_streaming);
            flags = setFlag(flags, FLAG_3, nosound);
            stream.writeInt32(flags);
            stream.writeDouble(duration);
            stream.writeInt32(w);
            stream.writeInt32(h);
            if (hasFlag(flags, FLAG_2)) {
                stream.writeInt32(preload_prefix_size);
            }
            if (hasFlag(flags, FLAG_4)) {
                stream.writeDouble(video_start_ts);
            }
            if (hasFlag(flags, FLAG_5)) {
                stream.writeString(video_codec);
            }
        }}
public static class TL_documentAttributeAudio extends DocumentAttribute {public static final int constructor = 0x9852f9c6;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_10, voice);
            stream.writeInt32(flags);
            stream.writeInt32((int) duration);
            if (hasFlag(flags, FLAG_0)) {
                stream.writeString(title);
            }
            if (hasFlag(flags, FLAG_1)) {
                stream.writeString(performer);
            }
            if (hasFlag(flags, FLAG_2)) {
                stream.writeByteArray(waveform);
            }
        }}
public static class TL_documentAttributeAnimated extends DocumentAttribute {public static final int constructor = 0x11b58939;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
        }}
public static class TL_documentAttributeImageSize extends DocumentAttribute {public static final int constructor = 0x6c37c15c;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt32(w);
            stream.writeInt32(h);
        }}
public static class TL_photoSizeEmpty extends PhotoSize {public static final int constructor = 0xe17e23c;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeString(type);
        }}
public static class TL_photoSize extends PhotoSize {public static final int constructor = 0x75c78e60;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeString(type);
            stream.writeInt32(w);
            stream.writeInt32(h);
            stream.writeInt32(size);
        }}
public static class TL_photoCachedSize extends PhotoSize {public static final int constructor = 0x21e1ad6;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeString(type);
            stream.writeInt32(w);
            stream.writeInt32(h);
            stream.writeByteArray(bytes);
        }}
public static class TL_videoSize extends VideoSize {public static final int constructor = 0xde33b094;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt32(flags);
            stream.writeString(type);
            stream.writeInt32(w);
            stream.writeInt32(h);
            stream.writeInt32(size);
            if (hasFlag(flags, FLAG_0)) {
                stream.writeDouble(video_start_ts);
            }
        }}
public static class PhotoSize extends TLObject {public String type;public int w,h,size;public byte[] bytes;}
public static class VideoSize extends TLObject {public String type;public int flags,w,h,size;public double video_start_ts;}

public static final int FLAG_0=1<<0,FLAG_1=1<<1,FLAG_2=1<<2,FLAG_3=1<<3,FLAG_4=1<<4,FLAG_5=1<<5,FLAG_6=1<<6,FLAG_7=1<<7,FLAG_8=1<<8,FLAG_9=1<<9,FLAG_10=1<<10,FLAG_11=1<<11,FLAG_12=1<<12,FLAG_13=1<<13,FLAG_14=1<<14,FLAG_15=1<<15,FLAG_16=1<<16,FLAG_17=1<<17,FLAG_18=1<<18,FLAG_19=1<<19,FLAG_20=1<<20,FLAG_21=1<<21,FLAG_22=1<<22,FLAG_23=1<<23,FLAG_24=1<<24,FLAG_25=1<<25,FLAG_26=1<<26,FLAG_27=1<<27,FLAG_28=1<<28,FLAG_29=1<<29,FLAG_30=1<<30,FLAG_31=1<<31;
public static class Photo extends TLObject { public long id; }
public static class WebPage extends TLObject { public int flags,hash,date,embed_width,embed_height,duration;public long id; public boolean has_large_media,video_cover_photo; public Photo photo;public TLObject document,cached_page; public ArrayList<TLObject> attributes=new ArrayList<>();public String url,display_url,type,site_name,title,description,embed_url,embed_type,author; }
public static class TL_photoEmpty extends Photo { public static final int constructor=0x2331b22d;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt64(id);
        }}
public static class TL_messageMediaWebPage extends MessageMedia { public static final int constructor=0xddf10c3b;public WebPage webpage; public boolean force_large_media,force_small_media,manual,safe;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_0, force_large_media);
            flags = setFlag(flags, FLAG_1, force_small_media);
            flags = setFlag(flags, FLAG_3, manual);
            flags = setFlag(flags, FLAG_4, safe);
            stream.writeInt32(flags);
            webpage.serializeToStream(stream);
        }}
public static class TL_messageMediaWebPage_layer165 extends TL_messageMediaWebPage { public static final int constructor=0xa32dd600;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            webpage.serializeToStream(stream);
        }}
public static class TL_webPage extends WebPage { public static final int constructor=0xe89c45b2;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            flags = setFlag(flags, FLAG_13, has_large_media);
            flags = setFlag(flags, FLAG_14, video_cover_photo);
            stream.writeInt32(flags);
            stream.writeInt64(id);
            stream.writeString(url);
            stream.writeString(display_url);
            stream.writeInt32(hash);
            if (hasFlag(flags, FLAG_0)) {
                stream.writeString(type);
            }
            if (hasFlag(flags, FLAG_1)) {
                stream.writeString(site_name);
            }
            if (hasFlag(flags, FLAG_2)) {
                stream.writeString(title);
            }
            if (hasFlag(flags, FLAG_3)) {
                stream.writeString(description);
            }
            if (hasFlag(flags, FLAG_4)) {
                photo.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_5)) {
                stream.writeString(embed_url);
            }
            if (hasFlag(flags, FLAG_5)) {
                stream.writeString(embed_type);
            }
            if (hasFlag(flags, FLAG_6)) {
                stream.writeInt32(embed_width);
            }
            if (hasFlag(flags, FLAG_6)) {
                stream.writeInt32(embed_height);
            }
            if (hasFlag(flags, FLAG_7)) {
                stream.writeInt32(duration);
            }
            if (hasFlag(flags, FLAG_8)) {
                stream.writeString(author);
            }
            if (hasFlag(flags, FLAG_9)) {
                document.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_10)) {
                cached_page.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_12)) {
                Vector.serialize(stream, attributes);
            }
        }}
public static class TL_webPage_layer107 extends TL_webPage { public static final int constructor=0xfa64e172;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt32(flags);
            stream.writeInt64(id);
            stream.writeString(url);
            stream.writeString(display_url);
            stream.writeInt32(hash);
            if (hasFlag(flags, FLAG_0)) {
                stream.writeString(type);
            }
            if (hasFlag(flags, FLAG_1)) {
                stream.writeString(site_name);
            }
            if (hasFlag(flags, FLAG_2)) {
                stream.writeString(title);
            }
            if (hasFlag(flags, FLAG_3)) {
                stream.writeString(description);
            }
            if (hasFlag(flags, FLAG_4)) {
                photo.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_5)) {
                stream.writeString(embed_url);
            }
            if (hasFlag(flags, FLAG_5)) {
                stream.writeString(embed_type);
            }
            if (hasFlag(flags, FLAG_6)) {
                stream.writeInt32(embed_width);
            }
            if (hasFlag(flags, FLAG_6)) {
                stream.writeInt32(embed_height);
            }
            if (hasFlag(flags, FLAG_7)) {
                stream.writeInt32(duration);
            }
            if (hasFlag(flags, FLAG_8)) {
                stream.writeString(author);
            }
            if (hasFlag(flags, FLAG_9)) {
                document.serializeToStream(stream);
            }
            if (hasFlag(flags, FLAG_11)) {
                Vector.serialize(stream, new ArrayList<>());
            }
            if (hasFlag(flags, FLAG_10)) {
                cached_page.serializeToStream(stream);
            }
        }}
public static class TL_webPageEmpty extends WebPage { public static final int constructor=0x211a1788;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt32(flags);
            stream.writeInt64(id);
            if (hasFlag(flags, FLAG_0)) {
                stream.writeString(url);
            }
        }}
public static class TL_webPageEmpty_layer165 extends TL_webPageEmpty { public static final int constructor=0xeb1477e8;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt64(id);
        }}
public static class TL_webPagePending extends WebPage { public static final int constructor=0xb0d13e47;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt32(flags);
            stream.writeInt64(id);
            if (hasFlag(flags, FLAG_0)) {
                stream.writeString(url);
            }
            stream.writeInt32(date);
        }}
public static class TL_webPagePending_layer165 extends TL_webPagePending { public static final int constructor=0xc586da1c;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeInt64(id);
            stream.writeInt32(date);
        }}
public static class TL_webPageUrlPending extends WebPage { public static final int constructor=0xd41a5167;public void serializeToStream(OutputSerializedData stream) {
            stream.writeInt32(constructor);
            stream.writeString(url);
        }}
}
