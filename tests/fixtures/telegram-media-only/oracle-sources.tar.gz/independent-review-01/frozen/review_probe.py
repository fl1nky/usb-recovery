"""Independent read-only artifact review. Does not import the producer or recovery."""
from pathlib import Path
import base64
import hashlib
import json
import sqlite3
import struct
import tarfile
import zlib

HERE = Path(__file__).resolve().parent
CASE = HERE.parent
MAIN = CASE.parents[2]
OLD = MAIN/'.build/telegram-document-attributes-oracle-20261103/v01'
NEW = MAIN/'.build/worktrees/telegram-document-attributes-20261103'
checks = 0
def h(raw): return hashlib.sha256(raw).hexdigest()
def need(value, reason):
    global checks
    checks += 1
    if not value: raise AssertionError(reason)
def load(path): return json.loads(path.read_text('utf-8-sig'))
def inventory(folder): return {p.relative_to(folder).as_posix():dict(bytes=p.stat().st_size,sha256=h(p.read_bytes())) for p in sorted(folder.rglob('*')) if p.is_file()}
def snapshot():
    names = ['MediaOnlyOracle.java','build_oracle.py','source-provenance.json','predecessor-source-files.json','predecessor-source-manifest.json','native-run-receipt.json','oracle.json','oracle.json.gz','native-sqlite-cases.zip','verification.json','metadata-refinement-receipt.json','refine_control_metadata.py','protected-input-pins-before.json','messages-v2-schema.sql','thumbnail.png','LICENSE']
    result = {name:h((CASE/name).read_bytes()) for name in names}
    for name in ('java-src','classes','upstream','official-methods','native-run-01','native-run-02','sqlite-run-01','sqlite-run-02','metadata-before-01'):
        result.update({name+'/'+key:row['sha256'] for key,row in inventory(CASE/name).items()})
    return result

class R:
    def __init__(self, raw): self.raw,self.pos = raw,0
    def take(self,n):
        need(0 <= n <= len(self.raw)-self.pos,'field within native body')
        value=self.raw[self.pos:self.pos+n];self.pos+=n;return value
    def u(self): return struct.unpack('<I',self.take(4))[0]
    def i(self): return struct.unpack('<i',self.take(4))[0]
    def q(self): return struct.unpack('<q',self.take(8))[0]
    def d(self): return struct.unpack('<d',self.take(8))[0]
    def data(self):
        size=self.take(1)[0];head=1
        if size==254:size=int.from_bytes(self.take(3),'little');head=4
        need(size<=1024*1024 and size!=255,'bounded native TL data')
        at=self.pos;raw=self.take(size);need(not any(self.take((-(head+size))%4)),'zero native padding');return raw,at
    def text(self):
        raw,at=self.data();return raw.decode('utf-8','strict'),at

def check_png(raw):
    need(len(raw)==70 and raw[:8]==b'\x89PNG\r\n\x1a\n','exact small PNG framing')
    at=8;types=[];payload=b''
    while at<len(raw):
        size=int.from_bytes(raw[at:at+4],'big');kind=raw[at+4:at+8];part=raw[at+8:at+8+size]
        need(at+size+12<=len(raw),'PNG chunk bound')
        need((zlib.crc32(kind+part)&0xffffffff)==int.from_bytes(raw[at+8+size:at+12+size],'big'),'independent PNG CRC')
        if kind==b'IHDR':need(struct.unpack('>IIBBBBB',part)==(2,1,8,2,0,0,0),'native PNG dimensions')
        if kind==b'IDAT':payload+=part
        types.append(kind);at+=size+12
    need(types==[b'IHDR',b'IDAT',b'IEND'] and zlib.decompress(payload)==b'\0\xff\0\0\0\0\xff','known exact red/blue pixels')

def parse_native(case):
    name=case['name'];body=(CASE/'native-run-01'/(name+'.body')).read_bytes();blob=(CASE/'native-run-01'/(name+'.blob')).read_bytes()
    need(blob==base64.b64decode(case['blob_base64'],validate=True) and h(blob)==case['blob_sha256'],'exact complete native BLOB')
    need(len(body)==case['tl_bytes'] and h(body)==case['tl_body_sha256'] and blob[:len(body)]==body,'exact native body boundary')
    r=R(body)
    need((r.u(),r.u(),r.u(),r.i(),r.u(),r.q(),r.u(),r.q(),r.i())==(0x7600B9D3,0x300,0,case['message_id'],0x59511722,77,0x59511722,909,case['date']),'independent full native message header')
    text_at=r.pos;text,text_data=r.text();need(text==case['text']==case['expected']['text'],'exact observed message text')
    need(text==('' if case['empty_text'] else 'Paired '+case['family']+' caption 🥧\n第二行'),'empty/paired independent typed values')
    need(base64.b64encode(text.encode()).decode()==case['text_utf8_base64'] and len(text.encode())==case['text_utf8_bytes'],'exact empty UTF8 bytes')
    media=r.pos;need(r.u()==0x52D8CCD9,'native current media constructor');flags=r.u()
    need(flags==case['media_flags']==({'video':65,'audio':257}.get(case['family'],1)),'observed media booleans')
    document=r.pos;ctor=r.u();thumbs=[]
    if case['family']=='document-empty':need(ctor==0x36F8C871 and r.q()==0 and case['document_id']=='0','explicit Empty zero reference')
    else:
        need(ctor==0x8FD4C4D8 and r.u()==case['document_flags'],'exact descriptor constructor/flags')
        need(r.q()==int(case['document_id']) and r.q()==0x1020304050607080,'opaque exact id/hash fields')
        need(r.data()[0]==bytes([17,35,53]) and r.i()==1789990000,'reference/date metadata framing')
        need(r.text()[0]==('audio/ogg' if case['family']=='audio' else 'video/mp4') and r.q()==4294967419,'MIME/declared int64 size metadata')
        if case['document_flags']&1:
            need((r.u(),r.i(),r.u())==(0x1CB5C415,1,0x021E1AD6),'cached-size vector framing')
            need(r.text()[0]=='s' and (r.i(),r.i())==(2,1),'cached-size independent dimensions')
            content,offset=r.data();thumbs.append(dict(blob_offset=offset,bytes=len(content),sha256=h(content),known_valid_png=case['family']=='cached-png'))
            need(content==(CASE/'native-run-01'/(name+'.thumbnail')).read_bytes(),'inline bytes equal independently emitted thumbnail')
            if case['family']=='cached-png':check_png(content)
            else:need(content==b'OPAQUE_INLINE_THUMB_NOT_IMAGE' and not content.startswith(b'\x89PNG'),'opaque content is not a decoded image claim')
        need(r.i()==2 and r.u()==0x1CB5C415,'descriptor dc/vector fields')
        count=r.i();need(count==len(case['attributes']),'native attribute count')
        for n in range(count):
            start=r.pos;kind=r.u()
            if kind==0x15590068:need(r.text()[0]=='METADATA_FILENAME_NOT_MESSAGE_пирожки_'+case['family']+('.ogg' if case['family']=='audio' else '.mp4'),'filename kept outside text')
            elif kind==0x43C57C48:need((r.u(),r.d(),r.i(),r.i())==(2,12.5,1920,1080),'native Video double width/order')
            elif kind==0x9852F9C6:
                need((r.u(),r.i())==(0x407,42),'native Audio int width/order')
                need(r.text()[0]=='METADATA_TITLE_NOT_MESSAGE_第二行' and r.text()[0]=='METADATA_PERFORMER_NOT_MESSAGE_бабушка' and r.data()[0]==bytes([1,3,5,7,9]),'audio metadata not text/audio content')
            else:need(kind==0x11B58939,'Animated exact no-field kind')
            part=body[start:r.pos];need(h(part)==case['attributes'][n]['sha256'] and len(part)==case['attributes'][n]['bytes'],'native whole attribute component')
            need(part==(CASE/'native-run-01'/(name+'.attribute-'+str(n))).read_bytes(),'native attribute file equals body component')
    need(r.pos==len(body),'no unknown/skipped body fields')
    tail=R(blob[len(body):]);need(tail.text()[0]==case['attach_path'] and tail.pos==len(tail.raw),'native complete Android tail framing')
    need((CASE/'native-run-01'/(name+'.media')).read_bytes()==body[media:] and (CASE/'native-run-01'/(name+'.document')).read_bytes()==body[document:],'independent complete native media/document pieces')
    need(case['native_offsets']==dict(message_text=text_at,message_text_data=text_data,media=media,media_flags=media+4,document=document,inline_thumbnails=thumbs),'all measured ranges independently replayed')
    need(case['expected_text_slots']==int(bool(text)) and case['native_message_observed'] is True and case['future_product_retention_policy'] is None and case['expected_native_record_policy'] is None,'text-slot facts separate from future retention policy')
    need(case['original_attachment_bytes_present'] is False and case['device_server_authentication_claim'] is False,'no original/device authentication claim')
    need(case['has_cached_inline_bytes']==case['family'].startswith('cached-') and case['known_valid_png_thumbnail']==(case['family']=='cached-png'),'local thumbnail availability separated from reference')
    return blob,body,dict(media=media,document=document)

def main():
    need(HERE.parent==CASE and not (HERE/'receipt.json').exists(),'fresh owned review output')
    before=snapshot()
    old_manifest=(OLD/'manifest.json').read_bytes();need(h(old_manifest)=='73e02a818c974582952ee3b07c3b0c8db37d8d2abb105644bb4a893714711fee','closed predecessor canonical manifest')
    old=load(OLD/'manifest.json')
    for row in old['files']:
        raw=(OLD/row['path']).read_bytes();need(len(raw)==row['bytes'] and h(raw)==row['sha256'],'closed predecessor canonical payload bytes')
    with tarfile.open(OLD/'oracle-sources.tar.gz','r:gz') as archive:
        pinned={item.name:archive.extractfile(item).read() for item in archive.getmembers() if item.isfile()}
    provenance=load(CASE/'source-provenance.json')
    for row in provenance['upstream_and_predecessor_files']:
        raw=(CASE/row['local']).read_bytes();need(raw==pinned[row['path']] and len(raw)==row['bytes'] and h(raw)==row['sha256'],'every reused full source byte equals pinned archive')
    pred=load(CASE/'predecessor-source-manifest.json')
    need(pred['telegram_commit']=='4de548e79fed27f1a66fbdff84223321838fe925' and len(pred['official_sources'])==10,'exact primary-source commit/count')
    for row in pred['official_sources']:
        raw=(CASE/row['local']).read_bytes();need(len(raw)==row['bytes'] and h(raw)==row['sha256'],'all ten full primary sources')
    upstream=(CASE/'upstream/TMessagesProj/src/main/java/org/telegram/tgnet/TLRPC.java').read_text('utf-8-sig')
    generated=(CASE/'java-src/org/telegram/tgnet/TLRPC.java').read_text('utf-8-sig')
    for row in pred['exact_serializers']:
        method=(CASE/'official-methods'/(row['name']+'.serializeToStream.java')).read_text('utf-8-sig').strip()
        need(h(method.encode())==row['serializer_sha256'] and method in upstream and method in generated,'exact full upstream writer reused: '+row['name'])
    copied_java={name for name in pinned if name.startswith('java-src/') and name!='java-src/AttributeOracle.java'}
    actual_java={p.relative_to(CASE).as_posix() for p in (CASE/'java-src').rglob('*.java')}
    need(actual_java==copied_java|{'java-src/MediaOnlyOracle.java'},'only pinned source tree plus new typed input writer')
    for name in copied_java:need((CASE/name).read_bytes()==pinned[name],'unchanged serializer/primitive/scaffold source')
    writer=(CASE/'MediaOnlyOracle.java').read_text('utf-8');need(writer==(CASE/'java-src/MediaOnlyOracle.java').read_text('utf-8'),'compiled own writer copy exact')
    need(writer.count('Files.readAllBytes(')==1 and 'png=Files.readAllBytes(Paths.get(args[1]))' in writer,'source inspection: only external data read is provided PNG, not old BLOB/prefix/tail')
    need('byte[] body=serialized(message)' in writer and 'byte[] blob=serialized(message)' in writer and 'object.serializeToStream(data)' in writer,'whole body/BLOB produced by actual typed native serializer')
    need(inventory(CASE/'native-run-01')==inventory(CASE/'native-run-02') and len(inventory(CASE/'native-run-01'))==90,'all ninety native artifact bytes identical across two Java runs')
    need((CASE/'java-run-01.stdout').read_bytes()==(CASE/'java-run-02.stdout').read_bytes(),'two native metadata streams identical')
    runs=load(CASE/'native-run-receipt.json')['runs'];need(len(runs)==5,'observed five native toolchain/compile/run calls')
    for row in runs:
        need(row['exit_code']==0 and h((CASE/(row['label']+'.stdout')).read_bytes())==row['stdout_sha256'] and h((CASE/(row['label']+'.stderr')).read_bytes())==row['stderr_sha256'],'native exit and actual stream hashes')
        need(load(CASE/(row['label']+'-process.json'))==row,'per-process result equals native receipt')
    native_stdout=[json.loads(line) for line in (CASE/'java-run-01.stdout').read_text('utf-8').splitlines()]
    raw_oracle=(CASE/'oracle.json').read_bytes();need(h(raw_oracle)=='fb1ad97c628493fe6bc385e0f9fdf36deb783343ac615b412966b9171fb93778' and len(raw_oracle)==142959,'current explicit refined metadata pin')
    oracle=json.loads(raw_oracle);positives={c['name']:c for c in oracle['positive_cases']};controls=oracle['mutation_controls']
    need(len(positives)==14 and len(controls)==56 and sum(c['empty_text'] for c in positives.values())==7 and sum(c['expected_text_slots'] for c in positives.values())==7,'fourteen metadata messages, seven exact empty text fields')
    originals={};scalars={}
    for row in native_stdout:
        case=positives[row['name']];need(all(case[k]==v for k,v in row.items()),'native emitted metadata equals canonical positive fields')
        originals[case['name']]=parse_native(case);scalars[case['name']]=case['exact_sql']
        need(case['exact_sql']==dict(mid=case['message_id'],uid=77,date=case['date']),'exact declared SQL/native keys')
        need(not any(marker in case['text'] for marker in ('METADATA_FILENAME_','METADATA_TITLE_','METADATA_PERFORMER_','OPAQUE_INLINE_')),'metadata strings never substitute for message text')
    seen=set();interpretations={'unknown-media-flag':'UNSUPPORTED_RESERVED_FLAG_IN_BOUNDED_PROFILE_NO_GLOBAL_INVALIDITY_CLAIM','unknown-document-constructor':'UNKNOWN_CONSTRUCTOR_TO_PINNED_SCHEMA_NO_FUTURE_SCHEMA_CLAIM','truncated-body':'TRUNCATED_BEFORE_COMPLETE_NATIVE_TL_BODY','sql-dialog-mismatch':'EXACT_NATIVE_BLOB_WITH_CONTRADICTORY_SQL_DIALOG'}
    for control in controls:
        parent,body,offsets=originals[control['parent']];label=control['mutation'];pair=(control['parent'],label);need(pair not in seen,'unique independent control');seen.add(pair)
        expected=bytearray(parent);sql=dict(scalars[control['parent']])
        if label=='unknown-media-flag':struct.pack_into('<I',expected,offsets['media']+4,positives[control['parent']]['media_flags']|0x80000000)
        elif label=='unknown-document-constructor':struct.pack_into('<I',expected,offsets['document'],0x7FFFFFFE)
        elif label=='truncated-body':expected=parent[:len(body)-1]
        elif label=='sql-dialog-mismatch':sql['uid']=-77
        else:raise AssertionError('unexpected mutation')
        expected=bytes(expected);need(base64.b64decode(control['blob_base64'],validate=True)==expected and control['blob_sha256']==h(expected) and control['bytes']==len(expected),'exact one documented mutation and full bytes')
        need(control['exact_sql']==sql and control['native_parent_blob_sha256']==h(parent),'native parent and exact SQL scope')
        need(control['wire_interpretation']==interpretations[label] and control['native_complete_body_verified']==(label=='sql-dialog-mismatch') and 'native_wire_valid' not in control,'precise limited wire/profile semantics')
        need(control['expected_outcome']==('scope_reject' if label=='sql-dialog-mismatch' else 'truncation_reject' if label=='truncated-body' else 'bounded_profile_reject') and control['expected_attributed_native_records']==0 and control['text_fragment_counts']=='UNSPECIFIED','bounded rejection expectations, no fragment counts invented')
    need(len(seen)==56 and all((name,label) in seen for name in positives for label in interpretations),'every parent has all four declared controls')
    initial=(CASE/'metadata-before-01/oracle.json').read_bytes();need(h(initial)=='7e8ddc6c7d245d6455d6ad3e188e39d2906182cbe27a24c272b1b325b39f40d2','initial metadata bytes preserved')
    old_oracle=json.loads(initial);need(old_oracle['positive_cases']==oracle['positive_cases'],'metadata correction leaves native positive facts intact')
    need([(r['blob_base64'],r['exact_sql']) for r in old_oracle['mutation_controls']]==[(r['blob_base64'],r['exact_sql']) for r in controls],'metadata correction leaves every mutated BLOB/SQL key unchanged')
    need(inventory(CASE/'sqlite-run-01')==inventory(CASE/'sqlite-run-02'),'all independent SQLite productions byte-identical')
    cases={c['name']:c for c in [*positives.values(),*controls]};need(len(oracle['sqlite_sources'])==70,'seventy native SQLite fixtures')
    declared_paths=set()
    for row in oracle['sqlite_sources']:
        path=CASE/'sqlite-run-01'/row['path'];raw=path.read_bytes();case=cases[row['case']];need(len(raw)==row['bytes'] and h(raw)==row['sha256'],'exact independently pinned SQLite bytes')
        need(row['path']==case['category']+'/'+case['name']+'/cache4.db','safe exact selected SQLite member')
        declared_paths.add(row['path']);con=sqlite3.connect(path.as_uri()+'?mode=ro&immutable=1',uri=True)
        try:
            need(con.execute('PRAGMA integrity_check').fetchall()==[('ok',)],'read-only independent SQLite integrity')
            native_schema=con.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='messages_v2'").fetchone()[0]
            need(native_schema.strip().rstrip(';')==oracle['sql_schema'].strip().rstrip(';'),'exact native schema')
            values=con.execute('SELECT mid,uid,date,typeof(data),data FROM messages_v2').fetchall();keys=case['exact_sql'];blob=base64.b64decode(case['blob_base64'],validate=True)
            need(values==[(keys['mid'],keys['uid'],keys['date'],'blob',blob)] and h(blob)==row['native_blob_sha256'],'read-only exact SQL/BLOB storage')
        finally:con.close()
    need(declared_paths==set(inventory(CASE/'sqlite-run-01')),'no extra undeclared SQLite file')
    pins=load(CASE/'protected-input-pins-before.json')
    for row in pins['current_sources']:need(h((NEW/row['path']).read_bytes())==row['sha256'],'current frozen release source unchanged')
    need(snapshot()==before,'all reviewed proof/native/SQLite/source bytes unchanged by review')
    (HERE/'review-inputs.json').write_text(json.dumps(dict(files=before),indent=2)+'\n',encoding='utf-8')
    result=dict(schema=1,status='PASS_READ_ONLY_INPUT_REVIEW',checks=checks,canonical_oracle_sha256=h(raw_oracle),native_messages=14,empty_text_cases=7,controls=56,sqlite_sources=70,
                native_java_artifacts=90,full_upstream_sources=10,exact_serializer_entries=len(pred['exact_serializers']),
                producer_and_recovery_rerun=False,device_server_authentication=False,original_attachment_recovery=False,
                scope='Source inspection and independent raw native framing/PNG/SQLite/mutation checks only; not product recovery or future retention acceptance',
                notes=['Two own initial metadata/wrapper corrections disclosed and preserved; no current product change.','No whole old BLOB/prefix/tail is read by native writer source; both complete serializations call pinned methods.','Reserved flags/unknown constructors are bounded profile controls, not global TL invalidity claims.'])
    (HERE/'receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result))

if __name__=='__main__':main()
