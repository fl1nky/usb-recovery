"""Independent native Java and SQLite inputs; never imports recovery code."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import base64
import gzip
import hashlib
import io
import json
import math
import os
import re
import shutil
import sqlite3
import struct
import subprocess
import tarfile
import time
import zipfile
import zlib

HERE = Path(__file__).resolve().parent
MAIN = HERE.parents[2]
OLD = MAIN / '.build/telegram-document-attributes-oracle-20261103/v01'
NEW = MAIN / '.build/worktrees/telegram-document-attributes-20261103'
JDK = Path('C:/Program Files/Eclipse Adoptium/jdk-25.0.3.9-hotspot/bin')
COMMIT = '4de548e79fed27f1a66fbdff84223321838fe925'
OLD_MANIFEST = '73e02a818c974582952ee3b07c3b0c8db37d8d2abb105644bb4a893714711fee'
CURRENT_FREEZE = '3e67677272a83f604917e853fabffc54aceb792eba1726b757807bb21db938d5'
checks = 0


def sha(data): return hashlib.sha256(data).hexdigest()
def check(value, why):
    global checks
    checks += 1
    if not value: raise AssertionError(why)
def dump(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def files(folder):
    return {p.relative_to(folder).as_posix(): dict(bytes=p.stat().st_size, sha256=sha(p.read_bytes())) for p in sorted(folder.rglob('*')) if p.is_file()}
def plain(path):
    check(path.is_file(), 'Existing source: ' + str(path))
    for item in (path, *path.parents):
        check(not item.is_symlink() and not bool(getattr(item.stat(), 'st_file_attributes', 0) & 0x400), 'No reparse source ancestor')
def run(args, label):
    start = time.monotonic()
    process = subprocess.run([str(x) for x in args], cwd=HERE, capture_output=True, timeout=90,
                             creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    (HERE / (label + '.stdout')).write_bytes(process.stdout)
    (HERE / (label + '.stderr')).write_bytes(process.stderr)
    result = dict(label=label, argv=[str(x) for x in args], exit_code=process.returncode,
                  seconds=round(time.monotonic()-start, 4), stdout_sha256=sha(process.stdout), stderr_sha256=sha(process.stderr))
    dump(HERE / (label + '-process.json'), result)
    check(process.returncode == 0, label + ' native process exit')
    return result


class PrimitiveReader:
    """Only independently specified native fixture fields, not a recovery reader."""
    def __init__(self, raw): self.raw, self.at = raw, 0
    def take(self, size):
        check(0 <= size <= len(self.raw)-self.at, 'Primitive framing bound')
        value = self.raw[self.at:self.at+size]; self.at += size; return value
    def u32(self): return struct.unpack('<I', self.take(4))[0]
    def i32(self): return struct.unpack('<i', self.take(4))[0]
    def i64(self): return struct.unpack('<q', self.take(8))[0]
    def f64(self):
        value = struct.unpack('<d', self.take(8))[0]
        check(math.isfinite(value), 'Finite fixture double'); return value
    def data(self):
        n = self.take(1)[0]; header = 1
        if n == 254: n = int.from_bytes(self.take(3), 'little'); header = 4
        check(n != 255 and n <= 1024 * 1024, 'Bounded TL data length')
        start = self.at; value = self.take(n)
        padding = self.take((-(n + header)) % 4)
        check(not any(padding), 'Zero native TL data padding')
        return value, start
    def string(self):
        value, start = self.data(); return value.decode('utf-8', 'strict'), start


def png(raw):
    check(raw[:8] == b'\x89PNG\r\n\x1a\n', 'Independent PNG signature')
    at = 8; kinds = []; content = b''
    while at < len(raw):
        n = int.from_bytes(raw[at:at+4], 'big'); kind = raw[at+4:at+8]; data = raw[at+8:at+8+n]
        check(at+12+n <= len(raw), 'Independent PNG chunk bounds')
        check(zlib.crc32(kind+data) & 0xffffffff == int.from_bytes(raw[at+8+n:at+12+n], 'big'), 'Independent PNG CRC')
        if kind == b'IHDR': check(struct.unpack('>IIBBBBB', data) == (2, 1, 8, 2, 0, 0, 0), 'Known native thumbnail dimensions')
        if kind == b'IDAT': content += data
        kinds.append(kind); at += n+12
    check(kinds == [b'IHDR', b'IDAT', b'IEND'] and at == len(raw), 'Complete native PNG chunks')
    check(zlib.decompress(content) == b'\0\xff\0\0\0\0\xff', 'Known independently declared red/blue pixels')


def primitive_verify(row, body, blob):
    r = PrimitiveReader(body)
    check((r.u32(), r.u32(), r.u32(), r.i32()) == (0x7600B9D3, 0x300, 0, row['message_id']), 'Native current message header')
    check((r.u32(), r.i64(), r.u32(), r.i64(), r.i32()) == (0x59511722, 77, 0x59511722, 909, row['date']), 'Native peers and date')
    text_at = r.at; text, text_data_at = r.string()
    check(text == row['text'] and len(text.encode('utf-8')) == row['text_utf8_bytes'], 'Exact producer text including empty UTF8')
    check(base64.b64encode(text.encode('utf-8')).decode() == row['text_utf8_base64'], 'Empty/nonempty UTF8 bytes explicitly preserved')
    media_at = r.at
    check((r.u32(), r.u32()) == (0x52D8CCD9, row['media_flags']), 'Current native document media and booleans')
    document_at = r.at; constructor = r.u32(); inline = []
    if row['family'] == 'document-empty':
        check((constructor, r.i64()) == (0x36F8C871, 0), 'Explicit native DocumentEmpty zero reference')
    else:
        check(constructor == 0x8FD4C4D8, 'Native Document descriptor')
        check((r.u32(), r.i64(), r.i64()) == (row['document_flags'], int(row['document_id']), 0x1020304050607080), 'Exact descriptor flags and opaque references')
        check(r.data()[0] == bytes([17,35,53]), 'Opaque file reference consumed without lookup')
        check(r.i32() == 1789990000, 'Document date separate from message date')
        check(r.string()[0] == ('audio/ogg' if row['family'] == 'audio' else 'video/mp4'), 'Native MIME is metadata')
        check(r.i64() == 4294967419, 'Declared int64 size is not allocated')
        if row['document_flags'] & 1:
            check((r.u32(), r.i32(), r.u32()) == (0x1CB5C415, 1, 0x021E1AD6), 'Exactly one native cached-size thumbnail')
            check(r.string()[0] == 's' and (r.i32(), r.i32()) == (2, 1), 'Native cached thumbnail type and dimensions')
            content, offset = r.data()
            check(content == (HERE/'native-run-01'/ (row['name']+'.thumbnail')).read_bytes(), 'Native inline thumbnail bytes and framing')
            if row['known_valid_png_thumbnail']: png(content)
            else: check(content == b'OPAQUE_INLINE_THUMB_NOT_IMAGE', 'Opaque bytes are not asserted to be an image')
            inline.append(dict(blob_offset=offset, bytes=len(content), sha256=sha(content), known_valid_png=row['known_valid_png_thumbnail']))
        check(r.i32() == 2, 'Native dc_id is metadata only')
        check(r.u32() == 0x1CB5C415, 'Native attribute vector constructor')
        count = r.i32(); check(count == len(row['attributes']), 'Native attribute vector count')
        for index in range(count):
            start = r.at; kind = r.u32()
            if kind == 0x15590068: check(r.string()[0].startswith('METADATA_FILENAME_NOT_MESSAGE_'), 'Filename is distinct metadata')
            elif kind == 0x43C57C48: check((r.u32(), r.f64(), r.i32(), r.i32()) == (2, 12.5, 1920, 1080), 'Video duration double and streaming bit')
            elif kind == 0x9852F9C6:
                check((r.u32(), r.i32()) == (0x407, 42), 'Audio duration int32 and voice bits')
                check(r.string()[0] == 'METADATA_TITLE_NOT_MESSAGE_第二行', 'Audio title is metadata')
                check(r.string()[0] == 'METADATA_PERFORMER_NOT_MESSAGE_бабушка', 'Audio performer is metadata')
                check(r.data()[0] == bytes([1,3,5,7,9]), 'Waveform bytes are not an audio attachment')
            else: check(kind == 0x11B58939, 'Only exact native Animated no-field attribute')
            check(sha(body[start:r.at]) == row['attributes'][index]['sha256'], 'Whole native attribute byte hash')
    check(r.at == len(body), 'Full native TL body consumed without skipping unknown fields')
    check(blob[:len(body)] == body, 'Native full BLOB shares entire body prefix')
    tail = PrimitiveReader(blob[len(body):]); attach, _ = tail.string()
    check(attach == row['attach_path'] and tail.at == len(tail.raw), 'Exact independently serialized Android tail')
    check((HERE/'native-run-01'/(row['name']+'.media')).read_bytes() == body[media_at:], 'Native whole media component equality')
    check((HERE/'native-run-01'/(row['name']+'.document')).read_bytes() == body[document_at:], 'Native whole document component equality')
    return dict(message_text=text_at, message_text_data=text_data_at, media=media_at, media_flags=media_at+4,
                document=document_at, inline_thumbnails=inline)


def make_sqlite(folder, cases, schema):
    folder.mkdir()
    result = []
    for case in cases:
        path = folder / case['category'] / case['name'] / 'cache4.db'; path.parent.mkdir(parents=True)
        raw = base64.b64decode(case['blob_base64'], validate=True)
        con = sqlite3.connect(path)
        try:
            con.execute('PRAGMA page_size=4096'); con.execute('PRAGMA secure_delete=ON'); con.execute(schema)
            keys = case['exact_sql']
            con.execute('INSERT INTO messages_v2(mid,uid,date,data) VALUES(?,?,?,?)', (keys['mid'], keys['uid'], keys['date'], raw)); con.commit()
            check(con.execute('PRAGMA integrity_check').fetchall() == [('ok',)], 'Native SQLite integrity check')
            found = con.execute('SELECT mid,uid,date,typeof(data),data FROM messages_v2').fetchone()
            check(found == (keys['mid'],keys['uid'],keys['date'],'blob',raw), 'Native SQLite exact SQL/BLOB roundtrip')
        finally: con.close()
        stored = path.read_bytes(); result.append(dict(case=case['name'], path=path.relative_to(folder).as_posix(), bytes=len(stored), sha256=sha(stored), native_blob_sha256=sha(raw)))
    return result


def main():
    check(HERE.is_relative_to(MAIN/'.build/telegram-media-only-oracle-20261103'), 'Owned case folder bound')
    check(not (HERE/'java-src').exists(), 'Preserve any earlier production attempt')
    original_manifest = (OLD/'manifest.json').read_bytes(); check(sha(original_manifest) == OLD_MANIFEST, 'Closed old31 manifest pin')
    prior = json.loads(original_manifest); old_before = {'manifest.json': sha(original_manifest)}
    for row in prior['files']:
        path = OLD/row['path']; plain(path); raw = path.read_bytes()
        check(len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'Closed prior canonical payload pin')
        old_before[row['path']] = sha(raw)
    freeze_path = NEW/'.build/telegram-document-attributes-integration-20261103/frozen-source-02/manifest.json'
    frozen = freeze_path.read_bytes(); check(sha(frozen) == CURRENT_FREEZE, 'Current untouched source freeze02')
    current_rows = json.loads(frozen)['files']
    for row in current_rows: check(sha((NEW/row['path']).read_bytes()) == row['sha256'], 'Current release source unchanged before production')
    dump(HERE/'protected-input-pins-before.json', dict(prior_manifest_sha256=OLD_MANIFEST, prior_files=old_before, current_source_freeze_sha256=CURRENT_FREEZE, current_sources=current_rows))
    with tarfile.open(OLD/'oracle-sources.tar.gz', 'r:gz') as archive:
        members = archive.getmembers(); check(len(members) < 500, 'Bounded prior source archive')
        selected = []
        for item in members:
            name = item.name; parts = PurePosixPath(name).parts
            check(item.isfile() and not item.issym() and not item.islnk() and not name.startswith('/') and '\\' not in name and ':' not in name and '..' not in parts, 'Plain bounded canonical tar member')
            if (name.startswith(('java-src/', 'upstream/', 'official-methods/')) or name in ('LICENSE','source-manifest.json','source-files.json','messages-v2-schema.sql','thumbnail.png')) and name != 'java-src/AttributeOracle.java':
                selected.append((name, archive.extractfile(item).read()))
        check(sum(len(raw) for _,raw in selected) < 16*1024*1024, 'Small complete native-writer source payload')
        for name, raw in selected:
            local = {'source-files.json':'predecessor-source-files.json', 'source-manifest.json':'predecessor-source-manifest.json'}.get(name, name)
            destination = HERE/local; destination.parent.mkdir(parents=True, exist_ok=True); destination.write_bytes(raw)
    old_sources = json.loads((HERE/'predecessor-source-files.json').read_text('utf-8'))
    reference = {row['path']: row for row in old_sources['files']}
    copied = []
    for name, raw in selected:
        if name in reference: check(len(raw) == reference[name]['bytes'] and sha(raw) == reference[name]['sha256'], 'Copied predecessor source-file binding')
        copied.append(dict(path=name, local={'source-files.json':'predecessor-source-files.json', 'source-manifest.json':'predecessor-source-manifest.json'}.get(name,name), bytes=len(raw), sha256=sha(raw)))
    source = json.loads((HERE/'predecessor-source-manifest.json').read_text('utf-8'))
    for row in source['official_sources']:
        raw = (HERE/row['local']).read_bytes(); check(len(raw)==row['bytes'] and sha(raw)==row['sha256'], 'Pinned full upstream primary source')
    check(source['telegram_commit'] == COMMIT, 'Exact pinned Telegram commit')
    shutil.copyfile(HERE/'MediaOnlyOracle.java', HERE/'java-src/MediaOnlyOracle.java')
    png((HERE/'thumbnail.png').read_bytes())
    tools = {'java.exe':'d5f1b9e03e298ebfb04d2326ecc1e2af3e6817f9b4d7f9f151fe856d56975650','javac.exe':'74f283ef1e26b3dfccfb56673d74a8a720d2c142e80881aa0084ce2e0379004e'}
    for name, expected in tools.items(): plain(JDK/name); check(sha((JDK/name).read_bytes()) == expected, 'Existing recorded native JDK executable')
    classes = HERE/'classes'; classes.mkdir()
    runs = [run([JDK/'java.exe','-version'],'java-version'),run([JDK/'javac.exe','-version'],'javac-version')]
    runs.append(run([JDK/'javac.exe','-encoding','UTF-8','-d',classes,*sorted((HERE/'java-src').rglob('*.java'))],'javac'))
    for number in (1,2): runs.append(run([JDK/'java.exe','-Xmx96m','-Dfile.encoding=UTF-8','-cp',classes,'MediaOnlyOracle',HERE/f'native-run-{number:02d}',HERE/'thumbnail.png'],f'java-run-{number:02d}'))
    native_one, native_two = files(HERE/'native-run-01'), files(HERE/'native-run-02')
    check(native_one == native_two, 'All two-run native bytes identical')
    check((HERE/'java-run-01.stdout').read_bytes() == (HERE/'java-run-02.stdout').read_bytes(), 'Two-run native metadata stream identical')
    metadata = [json.loads(line) for line in (HERE/'java-run-01.stdout').read_text('utf-8').splitlines()]
    check(len(metadata) == 14 and sum(row['empty_text'] for row in metadata) == 7, 'Seven exact empty/native paired profiles')
    positives, controls = [], []
    for row in metadata:
        body = (HERE/'native-run-01'/(row['name']+'.body')).read_bytes(); blob = (HERE/'native-run-01'/(row['name']+'.blob')).read_bytes()
        check((len(body),sha(body),len(blob),sha(blob)) == (row['body_bytes'],row['body_sha256'],row['blob_bytes'],row['blob_sha256']), 'Native body and whole BLOB independently bound')
        offsets = primitive_verify(row, body, blob)
        expected = dict(id=row['message_id'], text=row['text'], date=row['date'], from_peer=dict(kind='user',id=77), peer=dict(kind='user',id=909), out=False, layer=232, constructor='0x7600b9d3')
        case = dict(row, category='positive', expected=expected, exact_sql=dict(mid=row['sql_mid'],uid=77,date=row['date']),
                    bytes=len(blob), blob_base64=base64.b64encode(blob).decode(), tl_bytes=len(body), tl_body_sha256=sha(body),
                    native_offsets=offsets, attribution='Native producer fields plus exact SQL fixture keys; no device/server authenticity',
                    expected_native_record_policy=None)
        positives.append(case)
        variants = []
        mutated = bytearray(blob); struct.pack_into('<I',mutated,offsets['media_flags'],row['media_flags']|0x80000000)
        variants.append(('unknown-media-flag',bytes(mutated),False,case['exact_sql']))
        mutated = bytearray(blob); struct.pack_into('<I',mutated,offsets['document'],0x7FFFFFFE)
        variants.append(('unknown-document-constructor',bytes(mutated),False,case['exact_sql']))
        variants.append(('truncated-body',blob[:len(body)-1],False,case['exact_sql']))
        variants.append(('sql-dialog-mismatch',blob,True,dict(case['exact_sql'],uid=-77)))
        for label, raw, wire_valid, keys in variants:
            controls.append(dict(name=row['name']+'--'+label, category='controls', parent=row['name'], native_parent_blob_sha256=sha(blob),
                bytes=len(raw), blob_base64=base64.b64encode(raw).decode(), blob_sha256=sha(raw), native_parent_tl_bytes=len(body),
                available_body_prefix_bytes=min(len(raw),len(body)), available_body_prefix_sha256=sha(raw[:len(body)]),
                exact_sql=dict(keys), expected_outcome='scope_reject' if wire_valid else 'wire_reject',
                native_wire_valid=wire_valid, expected_attributed_native_records=0, text_fragment_counts='UNSPECIFIED', mutation=label))
    check(len(positives) == 14 and len(controls) == 56, 'Complete small native/control corpus')
    schema = (HERE/'messages-v2-schema.sql').read_text('utf-8-sig').strip()
    all_cases = positives + controls
    sqlite_one = make_sqlite(HERE/'sqlite-run-01', all_cases, schema)
    sqlite_two = make_sqlite(HERE/'sqlite-run-02', all_cases, schema)
    check(sqlite_one == sqlite_two and files(HERE/'sqlite-run-01') == files(HERE/'sqlite-run-02'), 'All two-run native SQLite bytes identical')
    oracle = dict(schema=1, status='INPUT_ONLY_MEDIA_ONLY_NATIVE_METADATA_PROOF', telegram_commit=COMMIT,
        source_predecessor_manifest_sha256=OLD_MANIFEST, native_cases=14, empty_text_cases=7, nonempty_paired_cases=7,
        observed_native_metadata_messages=14, expected_text_slots=7, future_product_retention_policy='UNSPECIFIED; zero text slots does not mean no native message metadata',
        sql_schema=schema, positive_cases=positives, mutation_controls=controls, sqlite_sources=sqlite_one,
        boundaries=dict(product_reader_run=False, recovery_acceptance=False, original_attachment_recovery=False, device_server_authentication=False, benchmark20_changed=False))
    dump(HERE/'oracle.json',oracle)
    with (HERE/'oracle.json.gz').open('xb') as file:
        with gzip.GzipFile(fileobj=file,mode='wb',filename='',mtime=0,compresslevel=9) as output:output.write((HERE/'oracle.json').read_bytes())
    with zipfile.ZipFile(HERE/'native-sqlite-cases.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for row in sqlite_one:
            info=zipfile.ZipInfo(row['path'],(2020,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100444<<16
            archive.writestr(info,(HERE/'sqlite-run-01'/row['path']).read_bytes())
    for name, expected in old_before.items(): check(sha((OLD/name).read_bytes())==expected,'Closed predecessor bytes unchanged after production')
    for row in current_rows: check(sha((NEW/row['path']).read_bytes())==row['sha256'],'Current release source unchanged after production')
    dump(HERE/'source-provenance.json',dict(telegram_commit=COMMIT,upstream_and_predecessor_files=copied,old_manifest_sha256=OLD_MANIFEST,
         own_java='MediaOnlyOracle.java: typed fixture values and metadata only',scaffolding='Unchanged generated predecessor Java scaffold; all serializers/primitives exactly inherited from pinned full source archive'))
    dump(HERE/'native-run-receipt.json',dict(status='NATIVE_INPUT_PRODUCTION_COMPLETE_NOT_RECOVERY_ACCEPTANCE',runs=runs,native_java_runs=2,
         native_artifacts=len(native_one),native_sqlite_runs=2,sqlite_sources=len(sqlite_one),java_source_files=len(list((HERE/'java-src').rglob('*.java')))))
    dump(HERE/'verification.json',dict(status='PASS_INPUT_ONLY',checks=checks,native_cases=14,empty_text_cases=7,nonempty_cases=7,controls=56,sqlite_sources=70,
         native_runs_identical=True,sqlite_runs_identical=True,source_and_current_release_unchanged=True,
         raw_oracle_bytes=(HERE/'oracle.json').stat().st_size,raw_oracle_sha256=sha((HERE/'oracle.json').read_bytes()),
         no_recovery_parser_or_helper_imported=True,no_product_or_real_device_run=True))
    print(json.dumps(dict(status='native-inputs-ready',checks=checks,cases=14,controls=56,sqlite_sources=70)))


if __name__ == '__main__':
    try: main()
    except BaseException as error:
        failure = HERE/'production-failure.json'
        if not failure.exists(): dump(failure,dict(status='FAIL_INPUT_PRODUCER',type=type(error).__name__,error=str(error),checks=checks))
        raise
