"""Correct only unclosed control labels; preserve initial bytes and raw evidence."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil

HERE = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
inventory = lambda folder: {p.relative_to(folder).as_posix(): sha(p.read_bytes()) for p in sorted(folder.rglob('*')) if p.is_file()}
protected = {name: inventory(HERE/name) for name in ('native-run-01','native-run-02','sqlite-run-01','sqlite-run-02','java-src','classes')}
saved = HERE/'metadata-before-01'; saved.mkdir(exist_ok=False)
names = ('build_oracle.py','oracle.json','oracle.json.gz','verification.json')
before = []
for name in names:
    raw = (HERE/name).read_bytes(); shutil.copyfile(HERE/name,saved/name)
    before.append(dict(path=name,bytes=len(raw),sha256=sha(raw)))
(saved/'manifest.json').write_text(json.dumps(dict(scope='Initial unclosed producer metadata: global wire-valid wording was too broad for unsupported flags/constructors; no product failure',files=before),indent=2)+'\n',encoding='utf-8')
original = (HERE/'oracle.json').read_bytes(); oracle = json.loads(original)
for row in oracle['mutation_controls']:
    old = row.pop('native_wire_valid')
    label = row['mutation']
    row['native_complete_body_verified'] = old
    row['wire_interpretation'] = {
        'unknown-media-flag':'UNSUPPORTED_RESERVED_FLAG_IN_BOUNDED_PROFILE_NO_GLOBAL_INVALIDITY_CLAIM',
        'unknown-document-constructor':'UNKNOWN_CONSTRUCTOR_TO_PINNED_SCHEMA_NO_FUTURE_SCHEMA_CLAIM',
        'truncated-body':'TRUNCATED_BEFORE_COMPLETE_NATIVE_TL_BODY',
        'sql-dialog-mismatch':'EXACT_NATIVE_BLOB_WITH_CONTRADICTORY_SQL_DIALOG',
    }[label]
    row['expected_outcome'] = ('scope_reject' if label=='sql-dialog-mismatch' else
                               'truncation_reject' if label=='truncated-body' else 'bounded_profile_reject')
    assert old == (label=='sql-dialog-mismatch')
current = (json.dumps(oracle,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
(HERE/'oracle.json').write_bytes(current)
with (HERE/'oracle.json.gz').open('wb') as file:
    with gzip.GzipFile(fileobj=file,mode='wb',filename='',mtime=0,compresslevel=9) as stream: stream.write(current)
source = (HERE/'build_oracle.py').read_text('utf-8')
old = "native_wire_valid=wire_valid, expected_attributed_native_records=0, text_fragment_counts='UNSPECIFIED', mutation=label))"
new = "native_complete_body_verified=wire_valid, expected_attributed_native_records=0, text_fragment_counts='UNSPECIFIED', mutation=label,\n                wire_interpretation={'unknown-media-flag':'UNSUPPORTED_RESERVED_FLAG_IN_BOUNDED_PROFILE_NO_GLOBAL_INVALIDITY_CLAIM',\n                    'unknown-document-constructor':'UNKNOWN_CONSTRUCTOR_TO_PINNED_SCHEMA_NO_FUTURE_SCHEMA_CLAIM',\n                    'truncated-body':'TRUNCATED_BEFORE_COMPLETE_NATIVE_TL_BODY',\n                    'sql-dialog-mismatch':'EXACT_NATIVE_BLOB_WITH_CONTRADICTORY_SQL_DIALOG'}[label]))"
assert source.count(old)==1
source = source.replace(old,new).replace("expected_outcome='scope_reject' if wire_valid else 'wire_reject',", "expected_outcome='scope_reject' if wire_valid else 'truncation_reject' if label=='truncated-body' else 'bounded_profile_reject',")
compile(source,'build_oracle.py','exec')
(HERE/'build_oracle.py').write_text(source,encoding='utf-8',newline='\n')
verification = json.loads((HERE/'verification.json').read_text('utf-8'))
verification['raw_oracle_bytes'] = len(current); verification['raw_oracle_sha256'] = sha(current)
verification['initial_raw_oracle_sha256'] = sha(original)
verification['metadata_classification_revision'] = 'Precise bounded-profile/unknown-constructor/truncated-wire/SQL-scope labels; all native/SQLite bytes unchanged'
(HERE/'verification.json').write_text(json.dumps(verification,indent=2)+'\n',encoding='utf-8')
for name, expected in protected.items(): assert inventory(HERE/name)==expected
receipt = dict(status='UNFINISHED_INPUT_METADATA_REFINED_NO_PRODUCT_CHANGE',initial_oracle_sha256=sha(original),current_oracle_sha256=sha(current),
               current_oracle_bytes=len(current),native_sqlite_java_class_bytes_unchanged=True,
               positive_cases_unchanged=oracle['positive_cases']==json.loads(original)['positive_cases'],
               raw_controls_unchanged=[(c['blob_sha256'],c['exact_sql']) for c in oracle['mutation_controls']]==[(c['blob_sha256'],c['exact_sql']) for c in json.loads(original)['mutation_controls']],
               reason='Unknown reserved bits and future constructors are not asserted globally invalid TL; exact truncation and SQL conflict remain separate',
               stdout_wrapper_correction='Initial shell redirected own producer stdout one folder above v01; known newly created log moved into v01 with no overwrite; producer native exit0 unaffected')
(HERE/'metadata-refinement-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
