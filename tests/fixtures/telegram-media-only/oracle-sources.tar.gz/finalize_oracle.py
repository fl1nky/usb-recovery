"""Package and physically freeze only independent input-production evidence."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import shutil
import tarfile
import zipfile

HERE = Path(__file__).resolve().parent
MAIN = HERE.parents[2]
OLD = MAIN/'.build/telegram-document-attributes-oracle-20261103/v01'
NEW = MAIN/'.build/worktrees/telegram-document-attributes-20261103'
COMMIT = '4de548e79fed27f1a66fbdff84223321838fe925'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def dump(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as file:
        file.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


def row(path):
    raw=path.read_bytes();return dict(path=path.relative_to(HERE).as_posix(),bytes=len(raw),sha256=sha(raw))


def main():
    assert not (HERE/'manifest.json').exists() and not (HERE/'frozen-01').exists()
    verification=json.loads((HERE/'verification.json').read_text('utf-8'))
    assert (verification['status'],verification['native_cases'],verification['empty_text_cases'],verification['controls'],verification['sqlite_sources'])==('PASS_INPUT_ONLY',14,7,56,70)
    raw=(HERE/'oracle.json').read_bytes();oracle=json.loads(raw)
    assert sha(raw)==verification['raw_oracle_sha256']
    peer_path=HERE/'independent-review-01/receipt.json'
    assert sha(peer_path.read_bytes())=='341ece46952fef65e323f65de86e55262db28d346899cfca170bc1d574209870'
    peer=json.loads(peer_path.read_text('utf-8'))
    assert peer['status']=='PASS_READ_ONLY_INPUT_REVIEW' and peer['checks']==1892 and peer['canonical_oracle_sha256']==sha(raw)
    with gzip.open(HERE/'oracle.json.gz','rb') as stream:assert stream.read()==raw
    assert len(oracle['positive_cases'])==14 and sum(r['text_utf8_bytes']==0 for r in oracle['positive_cases'])==7
    assert sum(r['expected_text_slots'] for r in oracle['positive_cases'])==7
    assert all(r['expected_native_record_policy'] is None and not r['original_attachment_bytes_present'] for r in oracle['positive_cases'])
    assert all('native_wire_valid' not in r for r in oracle['mutation_controls'])
    with zipfile.ZipFile(HERE/'native-sqlite-cases.zip') as archive:
        assert archive.testzip() is None
        members={r['path']:r for r in oracle['sqlite_sources']}
        assert len(members)==70 and set(archive.namelist())==set(members)
        for name,expected in members.items():
            assert not name.startswith('/') and '\\' not in name and ':' not in name and '..' not in PurePosixPath(name).parts
            payload=archive.read(name);assert len(payload)==expected['bytes'] and sha(payload)==expected['sha256']
    pins=json.loads((HERE/'protected-input-pins-before.json').read_text('utf-8'))
    for name,expected in pins['prior_files'].items():assert sha((OLD/name).read_bytes())==expected
    for source in pins['current_sources']:assert sha((NEW/source['path']).read_bytes())==source['sha256']
    readme='''# Telegram media-only messages: independent inputs

This is an input oracle, **not a recovery result**. It does not modify or run the
current application, helper or parser. There are no phone, server-authentication,
paid-tool or original-attachment recovery claims.

Fourteen exact native Android BLOBs cover seven document profiles, each with an
empty message and a nonempty paired caption: plain reference, Video, Audio/voice,
Animated, valid cached PNG, opaque cached bytes and DocumentEmpty. The seven empty
strings contain exactly zero UTF-8 bytes. All14 native messages have observed
producer metadata and consistent SQLite keys; only7 have nonempty text slots.
The future product's record-retention policy is deliberately unspecified. Zero
text slots must not be confused with proof that no message metadata exists.

Filename, MIME, title, performer, waveform and Android attachPath remain separate
metadata. A relative `NEVER_OPEN` attachPath is serialized as data, never opened.
The known70-byte cached PNG is2x1 with red and blue pixels; native byte ranges,
PNG chunks/CRCs and decompressed pixels are independently checked. The opaque
thumbnail is valid TL byte framing but is not asserted to be an image. Neither
thumbnail supplies the original document/video/audio bytes. No network lookup is
performed for document IDs, access hashes or file references.

The56 controls separately cover unsupported reserved media flags, a constructor
unknown to the pinned schema, truncation before a complete TL body, and exact
native BLOBs paired with a contradictory SQL dialog. Unsupported flags are
bounded-profile negatives; they are not a declaration that every such bit pattern
is globally invalid TL. Weak-fragment counts are unspecified. Source-only strict
attribution expectations are not measured product outcomes.

Evidence → finding → path:

| Evidence | Finding | Path |
|---|---|---|
| Two pinned native Java runs | All90 emitted artifacts and metadata streams match | `native-run-receipt.json`, `native-run-01/` |
| Independent primitive framing | Exact fields, empty strings, complete body and Android tail | `build_oracle.py`, `verification.json` |
| Two native SQLite productions | All70 DB byte streams match and pass integrity/row checks | `native-sqlite-cases.zip`, `oracle.json.gz` |
| Separate review | Source methods, metadata, controls and native bytes reviewed | `independent-review-01/` |

The exact serializers, original SerializedData/Vector primitives and complete
primary sources are pinned to Telegram Android commit
`4de548e79fed27f1a66fbdff84223321838fe925`. GPL license and complete native replay
source are in `oracle-sources.tar.gz`. Unused Android/platform scaffolding only
supplies declared fields and stubs; every executed TL/body/tail serializer comes
from the pinned source. No old native BLOB prefix or tail is copied to manufacture
equality.

For native replay, extract the source archive into a fresh folder and run this
PowerShell from that extracted folder with the recorded JDK25 installed:

```powershell
$jdk = 'C:/Program Files/Eclipse Adoptium/jdk-25.0.3.9-hotspot/bin'
if ((Test-Path ./replay-classes) -or (Test-Path ./replay-native)) { throw 'Preserve earlier replay outputs.' }
$javaFiles = @(Get-ChildItem ./java-src -Recurse -File -Filter '*.java' | Sort-Object FullName | Select-Object -ExpandProperty FullName)
& (Join-Path $jdk 'javac.exe') -encoding UTF-8 -d ./replay-classes @javaFiles
if ($LASTEXITCODE -ne 0) { throw 'Native producer compile failed.' }
& (Join-Path $jdk 'java.exe') -Xmx96m '-Dfile.encoding=UTF-8' -cp ./replay-classes MediaOnlyOracle ./replay-native (Join-Path $PWD 'thumbnail.png')
if ($LASTEXITCODE -ne 0) { throw 'Native producer failed.' }
```

Compare the new outputs with `native-run-01`. The generated Java source tree is
self-contained. The Python scaffolding-construction script retains predecessor
paths for provenance; that builder is not needed for native Java replay.

Before closure, control classification wording was refined without changing any
Java/native/SQLite bytes; initial metadata and producer bytes are preserved in
`metadata-before-01`, with an explicit refinement receipt. One shell stdout-path
typo was corrected by moving its newly created log into this case folder; native
producer exit0 was unaffected. Neither event was a product failure.

The old21/42 and31/171 inputs and current release source remain unchanged. This
corpus is separate from the20-image comparison and does not change its denominator.
'''
    (HERE/'README.md').write_text(readme,encoding='utf-8',newline='\n')
    native_files=[row(p) for p in sorted((HERE/'native-run-01').rglob('*')) if p.is_file()]
    dump(HERE/'native-artifacts.json',dict(schema=1,files=native_files))
    tools=[]
    for name in ('java.exe','javac.exe'):
        path=Path('C:/Program Files/Eclipse Adoptium/jdk-25.0.3.9-hotspot/bin')/name
        tools.append(dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path.read_bytes())))
    dump(HERE/'toolchain.json',dict(native_java=tools,python='3.12.14 existing developer environment',sqlite_version=__import__('sqlite3').sqlite_version,
        scope='Existing native developer toolchain only; no runtime installation or tool binaries distributed'))
    selected=[]
    for folder in ('java-src','upstream','official-methods','native-run-01','metadata-before-01','independent-review-01'):
        selected.extend(p for p in sorted((HERE/folder).rglob('*')) if p.is_file())
    required=('MediaOnlyOracle.java','build_oracle.py','refine_control_metadata.py','finalize_oracle.py','source-provenance.json',
              'predecessor-source-files.json','predecessor-source-manifest.json','messages-v2-schema.sql','thumbnail.png','LICENSE','README.md',
              'native-artifacts.json','toolchain.json','native-run-receipt.json','verification.json','metadata-refinement-receipt.json',
              'protected-input-pins-before.json','production.log','metadata-refinement.log','wrapper-correction.json')
    selected.extend(HERE/name for name in required)
    selected.extend(p for p in sorted(HERE.glob('*-process.json')))
    selected.extend(p for p in sorted(HERE.glob('*.stdout')))
    selected.extend(p for p in sorted(HERE.glob('*.stderr')))
    selected=sorted(set(selected));assert all(p.is_file() for p in selected)
    dump(HERE/'media-source-files.json',dict(schema=1,scope='Complete self-contained native writer, primary sources and input evidence; no recovery implementation',files=[row(p) for p in selected]))
    selected.append(HERE/'media-source-files.json')
    buffer=io.BytesIO()
    with tarfile.open(fileobj=buffer,mode='w',format=tarfile.PAX_FORMAT) as archive:
        for path in sorted(selected):
            payload=path.read_bytes();info=tarfile.TarInfo(path.relative_to(HERE).as_posix());info.size=len(payload);info.mode=0o644
            info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;archive.addfile(info,io.BytesIO(payload))
    with (HERE/'oracle-sources.tar.gz').open('xb') as file:
        with gzip.GzipFile(fileobj=file,mode='wb',filename='',mtime=0,compresslevel=9) as stream:stream.write(buffer.getvalue())
    canonical=('oracle.json.gz','native-sqlite-cases.zip','oracle-sources.tar.gz','LICENSE','README.md')
    manifest=dict(schema=1,status='INPUT_ONLY_NATIVE_MEDIA_METADATA_NOT_RECOVERY_ACCEPTANCE',telegram_commit=COMMIT,
        source_predecessor_manifest_sha256=pins['prior_manifest_sha256'],native_cases=14,empty_text_cases=7,nonempty_paired_cases=7,
        observed_native_metadata_messages=14,nonempty_text_slots=7,mutation_controls=56,native_sqlite_sources=70,native_java_runs=2,native_sqlite_runs=2,
        independent_producer_checks=verification['checks'],independent_review_checks=peer['checks'],
        independent_review_receipt_sha256=sha(peer_path.read_bytes()),uncompressed_json_bytes=len(raw),uncompressed_json_sha256=sha(raw),
        files=[row(HERE/name) for name in canonical],scope='Independent fixture production only; retention policy and all product results remain unmeasured')
    dump(HERE/'manifest.json',manifest)
    frozen=HERE/'frozen-01';frozen.mkdir()
    full=[p for p in sorted(HERE.rglob('*')) if p.is_file() and 'frozen-01' not in p.relative_to(HERE).parts]
    frozen_rows=[]
    for path in full:
        target=frozen/'files'/path.relative_to(HERE);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target)
        assert target.read_bytes()==path.read_bytes();frozen_rows.append(row(path))
    dump(frozen/'manifest.json',dict(schema=1,scope='Physical complete input-producer handoff; no mutable predecessor/current source',files=frozen_rows))
    receipt=dict(schema=1,status='SOURCE_CLOSED_INPUT_ONLY',closed_utc=datetime.now(timezone.utc).isoformat(),folder=str(HERE),
        manifest_sha256=sha((HERE/'manifest.json').read_bytes()),raw_oracle_sha256=sha(raw),
        oracle_gzip_sha256=sha((HERE/'oracle.json.gz').read_bytes()),sqlite_zip_sha256=sha((HERE/'native-sqlite-cases.zip').read_bytes()),
        source_archive_sha256=sha((HERE/'oracle-sources.tar.gz').read_bytes()),freeze_manifest_sha256=sha((frozen/'manifest.json').read_bytes()),
        frozen_files=len(frozen_rows),native_cases=14,empty_text_cases=7,nonempty_paired_cases=7,controls=56,sqlite_sources=70,
        native_java_runs=2,identical_native_artifacts=90,native_sqlite_runs=2,independent_producer_checks=verification['checks'],
        independent_review_checks=peer['checks'],independent_review_receipt_sha256=sha(peer_path.read_bytes()),
        current_release_source_unchanged=True,old_corpora_unchanged=True,product_parser_helper_run=False,retention_policy='NOT_SPECIFIED',
        source_only_not_recovery_acceptance=True,device_server_authentication_claim=False,paid_benchmark_modified=False)
    dump(HERE/'handoff-receipt.json',receipt)
    print(json.dumps(receipt))


if __name__=='__main__':main()
