import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.io.PrintStream;
import java.security.MessageDigest;
import java.util.*;
import org.telegram.tgnet.*;
import org.telegram.messenger.ApplicationLoader;

// Own typed values only. TL and Android-tail writers are exact pinned upstream.
public final class MediaOnlyOracle {
    static Path output;
    static byte[] png;
    static int count;
    static final class TraceData extends SerializedData {
        final List<Object> strings = new ArrayList<>();
        public void writeString(String value) {
            int at=length();super.writeString(value);
            strings.add(map("offset",at,"encoded_bytes",length()-at,"utf8_base64",b64(value.getBytes(StandardCharsets.UTF_8))));
        }
    }
    static Map<String,Object> map(Object... pairs){Map<String,Object> r=new LinkedHashMap<>();for(int i=0;i<pairs.length;i+=2)r.put((String)pairs[i],pairs[i+1]);return r;}
    static String b64(byte[] value){return Base64.getEncoder().encodeToString(value);}
    static String sha(byte[] value)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value));}
    static String quote(String value){StringBuilder s=new StringBuilder("\"");for(int i=0;i<value.length();i++){char c=value.charAt(i);if(c=='"'||c=='\\')s.append('\\').append(c);else if(c<32)s.append(String.format(Locale.ROOT,"\\u%04x",(int)c));else s.append(c);}return s.append('"').toString();}
    static String json(Object value){if(value==null)return "null";if(value instanceof String)return quote((String)value);if(value instanceof Number||value instanceof Boolean)return value.toString();List<String> p=new ArrayList<>();if(value instanceof Map<?,?>){for(Map.Entry<?,?> e:((Map<?,?>)value).entrySet())p.add(quote((String)e.getKey())+":"+json(e.getValue()));return "{"+String.join(",",p)+"}";}if(value instanceof Iterable<?>){for(Object e:(Iterable<?>)value)p.add(json(e));return "["+String.join(",",p)+"]";}throw new AssertionError("Unsupported own metadata");}
    static void save(String name,byte[] value)throws Exception{Files.write(output.resolve(name),value,StandardOpenOption.CREATE_NEW);}
    static byte[] serialized(TLObject object){SerializedData data=new SerializedData();object.serializeToStream(data);return data.toByteArray();}
    static TLRPC.TL_peerUser peer(long id){TLRPC.TL_peerUser p=new TLRPC.TL_peerUser();p.user_id=id;return p;}
    static TLRPC.TL_documentAttributeFilename filename(String family){TLRPC.TL_documentAttributeFilename a=new TLRPC.TL_documentAttributeFilename();a.file_name="METADATA_FILENAME_NOT_MESSAGE_пирожки_"+family+(family.equals("audio")?".ogg":".mp4");return a;}
    static void emit(String family,int index,boolean empty)throws Exception{
        String name=(empty?"empty-":"paired-")+family;
        TLRPC.Document document;
        if(family.equals("document-empty")){TLRPC.TL_documentEmpty d=new TLRPC.TL_documentEmpty();d.id=0;document=d;}
        else{
            TLRPC.TL_document d=new TLRPC.TL_document();d.id=7000000000L+index;d.access_hash=0x1020304050607080L;
            d.file_reference=new byte[]{17,35,53};d.date=1789990000;d.mime_type=family.equals("audio")?"audio/ogg":"video/mp4";
            d.size=4294967419L;d.dc_id=2;
            if(!family.equals("plain"))d.attributes.add(filename(family));
            if(family.equals("video")){TLRPC.TL_documentAttributeVideo a=new TLRPC.TL_documentAttributeVideo();a.supports_streaming=true;a.duration=12.5;a.w=1920;a.h=1080;d.attributes.add(a);}
            if(family.equals("audio")){TLRPC.TL_documentAttributeAudio a=new TLRPC.TL_documentAttributeAudio();a.flags=7;a.voice=true;a.duration=42;a.title="METADATA_TITLE_NOT_MESSAGE_第二行";a.performer="METADATA_PERFORMER_NOT_MESSAGE_бабушка";a.waveform=new byte[]{1,3,5,7,9};d.attributes.add(a);}
            if(family.equals("animated"))d.attributes.add(new TLRPC.TL_documentAttributeAnimated());
            if(family.startsWith("cached-")){d.flags=1;TLRPC.TL_photoCachedSize p=new TLRPC.TL_photoCachedSize();p.type="s";p.w=2;p.h=1;p.bytes=family.equals("cached-png")?png:"OPAQUE_INLINE_THUMB_NOT_IMAGE".getBytes(StandardCharsets.UTF_8);d.thumbs.add(p);}
            document=d;
        }
        TLRPC.TL_messageMediaDocument media=new TLRPC.TL_messageMediaDocument();media.flags=1;media.document=document;media.video=family.equals("video");media.voice=family.equals("audio");
        TLRPC.TL_message message=new TLRPC.TL_message();message.flags=256|512;message.id=4000+count;message.date=1790005000+count;
        message.from_id=peer(77);message.peer_id=peer(909);message.out=false;message.message=empty?"":"Paired "+family+" caption 🥧\n第二行";
        message.media=media;message.attachPath="../../NEVER_OPEN_MEDIA_ORACLE_"+name+".bin";
        ApplicationLoader.testEnvironment=true;byte[] body=serialized(message);
        TraceData traced=new TraceData();message.serializeToStream(traced);if(!Arrays.equals(body,traced.toByteArray()))throw new AssertionError("Trace changed native writer bytes");
        ApplicationLoader.testEnvironment=false;byte[] blob=serialized(message);
        if(blob.length<=body.length||!Arrays.equals(body,Arrays.copyOf(blob,body.length)))throw new AssertionError("Native body/tail mismatch");
        save(name+".body",body);save(name+".blob",blob);save(name+".media",serialized(media));save(name+".document",serialized(document));
        List<Object> attributes=new ArrayList<>();for(int i=0;i<document.attributes.size();i++){TLRPC.DocumentAttribute a=document.attributes.get(i);byte[] raw=serialized(a);save(name+".attribute-"+i,raw);attributes.add(map("class",a.getClass().getSimpleName(),"bytes",raw.length,"sha256",sha(raw)));}
        if(!document.thumbs.isEmpty())save(name+".thumbnail",((TLRPC.TL_photoCachedSize)document.thumbs.get(0)).bytes);
        Map<String,Object> record=map("name",name,"family",family,"empty_text",empty,"text",message.message,"text_utf8_base64",b64(message.message.getBytes(StandardCharsets.UTF_8)),"text_utf8_bytes",message.message.getBytes(StandardCharsets.UTF_8).length,
            "expected_text_slots",empty?0:1,"message_id",message.id,"date",message.date,"from_user",77,"peer_user",909,"out",false,"sql_mid",message.id,"sql_uid",77,
            "document_kind",family.equals("document-empty")?"empty":"descriptor","document_id",Long.toString(document.id),"document_flags",document.flags,"media_flags",media.flags,
            "attributes",attributes,"has_cached_inline_bytes",!document.thumbs.isEmpty(),"known_valid_png_thumbnail",family.equals("cached-png"),"original_attachment_bytes_present",false,
            "attach_path",message.attachPath,"string_writes",traced.strings,"body_bytes",body.length,"blob_bytes",blob.length,"body_sha256",sha(body),"blob_sha256",sha(blob),
            "native_message_observed",true,"future_product_retention_policy",null,"device_server_authentication_claim",false);
        save(name+".json",(json(record)+"\n").getBytes(StandardCharsets.UTF_8));System.out.println(json(record));count++;
    }
    public static void main(String[] args)throws Exception{
        if(args.length!=2)throw new AssertionError("Fresh owned output and PNG paths required");
        System.setOut(new PrintStream(System.out,true,StandardCharsets.UTF_8));output=Paths.get(args[0]);Files.createDirectory(output);png=Files.readAllBytes(Paths.get(args[1]));
        String[] families={"plain","video","audio","animated","cached-png","cached-opaque","document-empty"};
        for(int i=0;i<families.length;i++){emit(families[i],i,true);emit(families[i],i,false);}if(count!=14)throw new AssertionError("Incomplete own native case set");
    }
}
