import java.nio.file.*;
import java.nio.*;
import java.nio.charset.*;
import java.util.*;
import org.telegram.tgnet.*;
import org.telegram.messenger.ApplicationLoader;

/** Independent bounded primitive decoding, followed by original native writers. */
public class CompatibilityOracle {
 static final int MEDIA=0x52d8ccd9, DOCUMENT=0x8fd4c4d8, EMPTY=0x36f8c871;
 static final int KNOWN_BOOLEAN_MASK=(1<<3)|(1<<4)|(1<<6)|(1<<7)|(1<<8);
 static class Reader {
  final byte[] bytes; int at=0;
  Reader(byte[] b) { bytes=b; }
  void need(int n) { if(n<0 || n>bytes.length-at) throw new AssertionError("Truncated primitive at "+at); }
  int i32() { need(4);int v=ByteBuffer.wrap(bytes,at,4).order(ByteOrder.LITTLE_ENDIAN).getInt();at+=4;return v; }
  long i64() { need(8);long v=ByteBuffer.wrap(bytes,at,8).order(ByteOrder.LITTLE_ENDIAN).getLong();at+=8;return v; }
  void equal(int value) { if(i32()!=value)throw new AssertionError("Unexpected constructor/field"); }
  byte[] tlBytes() {
   need(1);int first=bytes[at++]&255, length=first, header=1;
   if(first==254){need(3);length=(bytes[at]&255)|((bytes[at+1]&255)<<8)|((bytes[at+2]&255)<<16);at+=3;header=4;if(length<254)throw new AssertionError("Noncanonical long length");}
   else if(first>254)throw new AssertionError("Invalid TL string marker");
   need(length);byte[] result=Arrays.copyOfRange(bytes,at,at+length);at+=length;
   int padding=(-(header+length))&3;need(padding);
   for(int i=0;i<padding;i++)if(bytes[at++]!=0)throw new AssertionError("Nonzero TL padding");
   return result;
  }
  String string() throws CharacterCodingException { return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(tlBytes())).toString(); }
 }
 static TLRPC.TL_peerUser peer(Reader r) { r.equal(0x59511722);TLRPC.TL_peerUser p=new TLRPC.TL_peerUser();p.user_id=r.i64();return p; }
 static byte[] serialize(TLObject object) { SerializedData s=new SerializedData();object.serializeToStream(s);return s.toByteArray(); }
 static void same(byte[] expected,byte[] actual,String scope) { if(!Arrays.equals(expected,actual))throw new AssertionError("Native byte mismatch: "+scope); }
 static void emit(Path inputs,Path output,String name,int bodyBoundary)throws Exception {
  byte[] original=Files.readAllBytes(inputs.resolve(name+".blob"));
  Reader r=new Reader(original);r.equal(0x7600b9d3);
  TLRPC.TL_message message=new TLRPC.TL_message();
  int messageFlags=r.i32();if(messageFlags!=768 && messageFlags!=770)throw new AssertionError("Outer flags outside bounded source profile");
  message.flags=768;message.out=(messageFlags&2)!=0;
  if(r.i32()!=0)throw new AssertionError("Unexpected flags2");
  message.id=r.i32();message.from_id=peer(r);message.peer_id=peer(r);message.date=r.i32();message.message=r.string();
  int mediaStart=r.at;r.equal(MEDIA);int mediaFlags=r.i32();
  if((mediaFlags&~(1|KNOWN_BOOLEAN_MASK))!=0 || (mediaFlags&1)==0)throw new AssertionError("Media flags outside explicit boolean proof");
  TLRPC.TL_messageMediaDocument media=new TLRPC.TL_messageMediaDocument();
  // Only presence is supplied as a raw flag: the original native serializer
  // must recreate each boolean bit from its typed value below.
  media.flags=1;
  media.nopremium=(mediaFlags&(1<<3))!=0;media.spoiler=(mediaFlags&(1<<4))!=0;
  media.video=(mediaFlags&(1<<6))!=0;media.round=(mediaFlags&(1<<7))!=0;media.voice=(mediaFlags&(1<<8))!=0;
  int documentStart=r.at, ctor=r.i32();
  if(ctor==DOCUMENT) {
   TLRPC.TL_document d=new TLRPC.TL_document();
   if(r.i32()!=0)throw new AssertionError("Document flags outside bounded profile");
   d.flags=0;d.id=r.i64();d.access_hash=r.i64();d.file_reference=r.tlBytes();d.date=r.i32();d.mime_type=r.string();d.size=r.i64();d.dc_id=r.i32();
   r.equal(0x1cb5c415);int count=r.i32();if(count<0||count>1)throw new AssertionError("Strict filename count boundary");
   for(int i=0;i<count;i++){r.equal(0x15590068);TLRPC.TL_documentAttributeFilename a=new TLRPC.TL_documentAttributeFilename();a.file_name=r.string();d.attributes.add(a);}
   media.document=d;
  } else if(ctor==EMPTY) { TLRPC.TL_documentEmpty d=new TLRPC.TL_documentEmpty();d.id=r.i64();media.document=d; }
  else throw new AssertionError("Unsupported source document constructor");
  if(r.at!=bodyBoundary)throw new AssertionError("Declared body boundary disagrees with independently decoded fields");
  message.attachPath=r.string();if(r.at!=original.length)throw new AssertionError("Trailing source bytes");
  message.media=media;
  byte[] document=serialize(media.document), serializedMedia=serialize(media);
  same(Arrays.copyOfRange(original,documentStart,bodyBoundary),document,"whole document");
  same(Arrays.copyOfRange(original,mediaStart,bodyBoundary),serializedMedia,"whole media");
  ApplicationLoader.testEnvironment=true;byte[] body=serialize(message);
  ApplicationLoader.testEnvironment=false;byte[] full=serialize(message);
  same(Arrays.copyOf(original,bodyBoundary),body,"whole TL_message body");
  same(original,full,"whole TL_message including native Android attachPath");
  Files.write(output.resolve(name+".document"),document);Files.write(output.resolve(name+".media"),serializedMedia);
  Files.write(output.resolve(name+".body"),body);Files.write(output.resolve(name+".blob"),full);
  System.out.println(String.join("\t",name,Integer.toString(mediaFlags),Boolean.toString(media.nopremium),Boolean.toString(media.spoiler),Boolean.toString(media.video),Boolean.toString(media.round),Boolean.toString(media.voice),Integer.toString(mediaStart),Integer.toString(documentStart),Integer.toString(bodyBoundary),Integer.toString(full.length)));
 }
 public static void main(String[] args)throws Exception {
  Path inputs=Paths.get(args[0]),output=Paths.get(args[1]);Files.createDirectory(output);
  List<String> lines=Files.readAllLines(inputs.resolve("cases.tsv"),StandardCharsets.UTF_8);
  for(String line:lines){String[] fields=line.split("\t");if(fields.length!=2||!fields[0].matches("[a-z0-9-]+"))throw new AssertionError("Unsafe case manifest");emit(inputs,output,fields[0],Integer.parseInt(fields[1]));}
  if(lines.size()!=6)throw new AssertionError("Expected exact baseline plus five controls");
 }
}
