"""Independent INPUT proof only; never import a recovery parser or helper."""
from pathlib import Path
from datetime import datetime, timezone
import base64
import gzip
import hashlib
import io
import json
import re
import shutil
import struct
import subprocess
import tarfile
import time

HERE=Path(__file__).resolve().parent
MAIN=HERE.parents[2]
OLD=MAIN/'.build/telegram-document-descriptor-oracle-20261103/v01'
ATTRS=MAIN/'.build/telegram-document-attributes-oracle-20261103/v01'
FIXTURES=MAIN/'.build/worktrees/telegram-document-descriptor-20261103/tests/fixtures'
JDK=Path('C:/Program Files/Eclipse Adoptium/jdk-25.0.3.9-hotspot')
COMMIT='4de548e79fed27f1a66fbdff84223321838fe925'
BITS={3:'nopremium',4:'spoiler',6:'video',7:'round',8:'voice'}
MANIFEST='8b2d3c7b6fe1f259607ef18987bcd51625412aad9a59c747f72980b212f712f7'
CHECKS=[]

def sha(raw):return hashlib.sha256(raw).hexdigest()
def dump(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as out:out.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def check(value,label):
    if not value:raise AssertionError(label)
    CHECKS.append(label)
def inventory(folder):return {p.relative_to(folder).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(folder.rglob('*')) if p.is_file()}
def run(args,label):
    start=time.monotonic();p=subprocess.run([str(a) for a in args],cwd=HERE,capture_output=True,timeout=90,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    (HERE/(label+'.stdout')).write_bytes(p.stdout);(HERE/(label+'.stderr')).write_bytes(p.stderr)
    check(p.returncode==0,label+': native exit0; '+p.stderr.decode('utf8','replace')[:500])
    return dict(label=label,argv=[str(a) for a in args],exit_code=p.returncode,seconds=round(time.monotonic()-start,4),stdout_sha256=sha(p.stdout),stderr_sha256=sha(p.stderr))

def main():
    check(HERE==MAIN/'.build/telegram-document-attributes-compatibility-20261103/v01','owned exact output folder')
    check(not(HERE/'inputs').exists(),'fresh folder; no old evidence overwritten')
    for path in (HERE,*HERE.parents):check(not path.is_symlink(),'no symlink '+str(path))
    source_pins={}
    for name in ('telegram-document-descriptor','telegram-document-empty'):
        folder=FIXTURES/name;manifest=json.loads((folder/'manifest.json').read_text('utf-8-sig'))
        check(manifest['telegram_commit']==COMMIT,name+' commit')
        for item in manifest['files']:
            raw=(folder/item['path']).read_bytes();check(len(raw)==item['bytes'] and sha(raw)==item['sha256'],name+' input '+item['path'])
        compressed=(folder/'oracle.json.gz').read_bytes();raw=gzip.decompress(compressed)
        if 'uncompressed_json_sha256' in manifest:check(sha(raw)==manifest['uncompressed_json_sha256'],name+' oracle raw SHA')
        check(len(raw)==manifest['uncompressed_json_bytes'],name+' oracle raw length')
        source_pins[name]=dict(manifest_sha256=sha((folder/'manifest.json').read_bytes()),files=manifest['files'],oracle_raw_bytes=len(raw),oracle_raw_sha256=sha(raw))
        target=HERE/'old-fixture-pins'/name;target.mkdir(parents=True)
        shutil.copyfile(folder/'manifest.json',target/'manifest.json');shutil.copyfile(folder/'oracle.json.gz',target/'oracle.json.gz')
    check(source_pins['telegram-document-descriptor']['manifest_sha256']==MANIFEST,'exact frozen old21/42 manifest')
    oracle=json.loads(gzip.decompress((FIXTURES/'telegram-document-descriptor/oracle.json.gz').read_bytes()))
    positives=oracle['positive_cases'];controls=oracle['mutation_controls']
    check(len(positives)==21 and len(controls)==42,'old denominator21/42 unchanged')
    inputs=HERE/'inputs';inputs.mkdir();parent=next(x for x in positives if x['name']=='descriptor-filename')
    parent_raw=base64.b64decode(parent['blob_base64']);media_at=parent['native_offsets']['media_constructor'];flags_at=parent['native_offsets']['media_flags']
    selected=[parent]+[next(x for x in controls if x['name']=='reject-media-flags-bit'+str(bit)) for bit in BITS]
    tsv=[];cases=[]
    for row in selected:
        name=row['name'];blob=base64.b64decode(row['blob_base64']);body=blob[:row['tl_bytes']]
        check(len(blob)==row['bytes'] and sha(blob)==row['blob_sha256'] and sha(body)==row['tl_body_sha256'],name+' raw golden pins')
        (inputs/(name+'.blob')).write_bytes(blob);(inputs/(name+'.body')).write_bytes(body);tsv.append(name+'\t'+str(row['tl_bytes']))
        is_control=name!=parent['name'];bit=int(name.rsplit('bit',1)[1]) if is_control else None
        value=1|(1<<bit) if is_control else 1
        expected=bytearray(parent_raw);struct.pack_into('<I',expected,flags_at,value)
        check(bytes(expected)==blob,name+' exact parent byte mutation only')
        check(row['exact_sql']==dict(mid=41,uid=77,date=1790000000),name+' pinned SQL identifiers')
        cases.append(dict(name=name,old_classification='scope_reject_control' if is_control else 'native_positive',
            old_golden_expected_native_parts=0 if is_control else 1,proposed_classification='explicit_compatibility_upgrade' if is_control else 'unchanged_baseline',
            native_boolean=BITS.get(bit),bit=bit,flags=value,parent=parent['name'],media_constructor='0x52d8ccd9',document_constructor='0x8fd4c4d8',
            exact_sql=row['exact_sql'],expected_message=parent['expected'],blob_bytes=len(blob),tl_bytes=len(body),blob_sha256=sha(blob),tl_body_sha256=sha(body),
            old_metadata=row,raw_blob_file='inputs/'+name+'.blob',raw_body_file='inputs/'+name+'.body'))
    (inputs/'cases.tsv').write_text('\n'.join(tsv)+'\n',encoding='utf8',newline='\n')
    duplicate=next(x for x in controls if x['name']=='reject-duplicate-filename-attribute')
    duplicate_raw=base64.b64decode(duplicate['blob_base64']);check(sha(duplicate_raw)==duplicate['blob_sha256'],'duplicate filename raw pin')
    (inputs/'reject-duplicate-filename-attribute.blob').write_bytes(duplicate_raw)
    dump(HERE/'duplicate-filename-policy.json',dict(status='STRICT_UNSUPPORTED_NO_UPGRADE',name=duplicate['name'],blob_sha256=duplicate['blob_sha256'],
        tl_body_sha256=duplicate['tl_body_sha256'],bytes=duplicate['bytes'],tl_bytes=duplicate['tl_bytes'],exact_sql=duplicate['exact_sql'],
        desired_native_parts=0,reason='Duplicate filename is a separate semantic/profile constraint; this boolean compatibility proof does not change it.',old_metadata=duplicate))
    # All legacy Empty oracle cases use a different media constructor. The old
    # runtime-generated malformed flag controls remain scoped to layer74.
    empty=json.loads(gzip.decompress((FIXTURES/'telegram-document-empty/oracle.json.gz').read_bytes()))
    empty_cases=empty['cases'];constructors=sorted({x['media_constructor'] for x in empty_cases})
    check(len(empty_cases)==167,'legacy Empty frozen167 count')
    check(constructors==['0x7c4414d3','0xb5223b0f'],'legacy Empty plus paired photo constructors remain separate')
    check(sum(x['media_constructor']=='0x7c4414d3' for x in empty_cases)==166,'166 legacy document plus one photo witness')
    check(not any(x.get('name','') in {y['name'] for y in selected[1:]} for x in empty_cases),'no same-name boolean controls in legacy Empty oracle')
    old_test=FIXTURES.parent/'TelegramDocumentEmptyTests.py';test_raw=old_test.read_bytes();(HERE/'old-fixture-pins/TelegramDocumentEmptyTests.py').write_bytes(test_raw)
    text=test_raw.decode('utf8');check('for flags in (8, 3 | 256, 3 | (1 << 31), 0xffffffff):' in text and "original = self.cases['layer118-flags3']['blob']" in text,'old Empty malformed flags source branch')
    dump(HERE/'empty-legacy-scope.json',dict(status='NO_RECLASSIFICATION',manifest_sha256=source_pins['telegram-document-empty']['manifest_sha256'],
        cases=167,legacy_document_cases=166,paired_photo_cases=1,media_constructors=constructors,method='TL_messageMediaDocument_layer74',test_source_sha256=sha(test_raw),
        test_method='test_unknown_media_flags_and_nested_documents_fail_closed',test_flag_values=[8,259,2147483651,4294967295],
        distinction='These old tests mutate legacy media0x7c4414d3, not current media0x52d8ccd9. Current boolean names do not justify widening the legacy profile.',
        descriptor_oracle_current_empty_cases=[{k:x[k] for k in ('name','media_constructor','media_flags','blob_sha256','tl_body_sha256','exact_sql')} for x in positives if x['name'].startswith('current-empty-')],
        limits='No new boolean-bearing Empty input is present in either old oracle; no broad Empty flag support is claimed.'))
    # Copy and independently pin complete official sources, original low-level
    # Java writers and exact original serializer methods. Never import scripts.
    old_source=json.loads((OLD/'source-manifest.json').read_text('utf-8-sig'));upstream_rows=[]
    for item in old_source['upstream_sources']:
        raw=(ATTRS/item['local']).read_bytes();check(sha(raw)==item['sha256'] and len(raw)==item['bytes'],'full official source '+item['path'])
        dest=HERE/item['local'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);upstream_rows.append(item)
    sources=HERE/'java-src';shutil.copytree(OLD/'java-src',sources,ignore=shutil.ignore_patterns('DescriptorOracle.java','TLRPC.java'))
    for item in old_source['unchanged_java']:check(sha((sources/item['path']).read_bytes())==item['sha256'],'unchanged original Java '+item['path'])
    original=(HERE/'upstream/TMessagesProj/src/main/java/org/telegram/tgnet/TLRPC.java').read_text('utf-8-sig')
    template=(OLD/'TLRPC.template.java').read_text('utf-8-sig');methods=[];method_dir=HERE/'official-methods';method_dir.mkdir()
    for name in ('TL_message','TL_messageMediaDocument','TL_messageMediaDocument_layer74','TL_document','TL_documentEmpty','TL_documentAttributeFilename','TL_peerUser','Message.writeAttachPath'):
        method=(OLD/'official-methods'/(name+'.java')).read_text('utf-8-sig').strip()
        check(method in original,'exact primary-source method '+name)
        check('@'+name+'@' in template,'template method slot '+name);template=template.replace('@'+name+'@',method)
        (method_dir/(name+'.java')).write_text(method+'\n',encoding='utf8',newline='\n');methods.append(dict(name=name,sha256=sha(method.encode()),exact_primary_text=True))
    check(not re.search(r'@[A-Za-z_]',template),'no unexpanded Java template')
    (sources/'org/telegram/tgnet/TLRPC.java').write_text(template,encoding='utf8',newline='\n');shutil.copyfile(HERE/'CompatibilityOracle.java',sources/'CompatibilityOracle.java')
    shutil.copyfile(HERE/'upstream/LICENSE',HERE/'LICENSE')
    dump(HERE/'source-provenance.json',dict(telegram_commit=COMMIT,upstream_sources=upstream_rows,unchanged_java=old_source['unchanged_java'],exact_serializer_methods=methods,
        own_scaffolding='Field declarations, platform stubs, bounded independent primitive Reader; no recovery code. Full native message output is reserialized, no prefix/tail copy substitution.',
        original_fixture_pins=source_pins))
    for name,pin in [('java.exe','d5f1b9e03e298ebfb04d2326ecc1e2af3e6817f9b4d7f9f151fe856d56975650'),('javac.exe','74f283ef1e26b3dfccfb56673d74a8a720d2c142e80881aa0084ce2e0379004e')]:
        check(sha((JDK/'bin'/name).read_bytes())==pin,'existing JDK '+name)
    classes=HERE/'classes';classes.mkdir();runs=[run([JDK/'bin/java.exe','-version'],'java-version'),run([JDK/'bin/javac.exe','-version'],'javac-version')]
    runs.append(run([JDK/'bin/javac.exe','-encoding','UTF-8','-d',classes]+sorted(sources.rglob('*.java')),'javac'))
    for n in (1,2):runs.append(run([JDK/'bin/java.exe','-Dfile.encoding=UTF-8','-cp',classes,'CompatibilityOracle',inputs,HERE/f'native-run-{n:02d}'],f'java-run-{n:02d}'))
    check(inventory(HERE/'native-run-01')==inventory(HERE/'native-run-02'),'two native runs identical24 artifacts')
    check((HERE/'java-run-01.stdout').read_bytes()==(HERE/'java-run-02.stdout').read_bytes(),'two native metadata streams identical')
    native_rows=[]
    for line in (HERE/'java-run-01.stdout').read_text('utf8').splitlines():
        name,flags,nopremium,spoiler,video,round_,voice,media_start,doc_start,boundary,size=line.split('\t')
        item=next(x for x in cases if x['name']==name);original_blob=(inputs/(name+'.blob')).read_bytes();b=int(boundary);m=int(media_start);d=int(doc_start)
        check(int(flags)==item['flags'] and b==item['tl_bytes'] and int(size)==item['blob_bytes'],name+' native metadata')
        expected_slices=dict(blob=original_blob,body=original_blob[:b],media=original_blob[m:b],document=original_blob[d:b])
        outputs={}
        for extension,expected in expected_slices.items():
            actual=(HERE/'native-run-01'/(name+'.'+extension)).read_bytes();check(actual==expected,name+' native exact '+extension)
            outputs[extension]=dict(bytes=len(actual),sha256=sha(actual))
        native_rows.append(dict(name=name,scope='WHOLE_BLOB_NATIVE_EXACT',native_boolean_values=dict(zip(BITS.values(),[x=='true' for x in (nopremium,spoiler,video,round_,voice)])),
            media_start=m,document_start=d,body_boundary=b,outputs=outputs))
    dump(HERE/'compatibility-contract.json',dict(schema=1,status='INPUT_ONLY_NATIVE_WIRE_PROOF_NOT_PRODUCT_ACCEPTANCE',telegram_commit=COMMIT,
        old_fixture_manifest_sha256=MANIFEST,old_fixture_case_counts=dict(positive=21,controls=42),cases=cases,native_results=native_rows,
        policy=dict(upgrade_control_names=[x['name'] for x in cases if x['bit'] is not None],upgrade_count=5,
            future_expected_native_parts_for_these_exact_SQL_inputs=1,reason='Exact official serializer recreates full old control BLOB, including Android tail, from typed booleans.',
            old_golden_bytes_and_old_results='UNCHANGED; old helper43 zero-result baselines remain historical zero, not rerun or reclassified as successful.',
            other_old_controls='NO_POLICY_CHANGE; do not broaden by constructor or textual similarity.',duplicate_filename='STRICT_UNSUPPORTED_NO_UPGRADE',legacy_empty_flags='NO_RECLASSIFICATION'),
        runs=runs,raw_native_outputs=inventory(HERE/'native-run-01'),boundaries=dict(product_helper_parser='NOT_RUN',phone_profiles_network_GUI='NOT_RUN',paid20_benchmark='UNCHANGED',native_app_device_server_auth='NOT_CLAIMED')))
    dump(HERE/'verification.json',dict(status='PASS_INPUT_ONLY',checks=len(CHECKS),check_labels=CHECKS,native_runs=2,identical_native_artifacts=24,whole_blob_proofs=6,upgrade_controls=5))
    print(json.dumps(dict(status='PASS_INPUT_ONLY_NATIVE_WHOLE_BLOB_EXACT',whole_blob_proofs=6,compatibility_upgrades=5,checks=len(CHECKS)),ensure_ascii=False))

if __name__=='__main__':main()
