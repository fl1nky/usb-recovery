"""Package independent native proof; no product/helper/recovery calls."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import tarfile

HERE=Path(__file__).resolve().parent
def sha(raw):return hashlib.sha256(raw).hexdigest()
def dump(path,value):
    with path.open('x',encoding='utf8',newline='\n') as out:out.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def pin(path):
    raw=path.read_bytes();return dict(path=path.relative_to(HERE).as_posix(),bytes=len(raw),sha256=sha(raw))

def main():
    assert HERE.name=='v01' and HERE.parent.name=='telegram-document-attributes-compatibility-20261103'
    assert not(HERE/'manifest.json').exists(),'Do not overwrite a closed proof'
    original=json.loads((HERE/'compatibility-contract.json').read_text('utf8'))
    verification=json.loads((HERE/'verification.json').read_text('utf8'))
    assert verification['status']=='PASS_INPUT_ONLY' and verification['whole_blob_proofs']==6
    # Public receipt contains no installation paths or commands tied to the
    # producer workstation. Actual raw invocation receipt remains local.
    runs=[]
    for row in original['runs']:
        assert row['exit_code']==0
        runs.append({key:row[key] for key in ('label','exit_code','stdout_sha256','stderr_sha256')})
    toolchain=dict(java_version=(HERE/'java-version.stderr').read_text('utf8'),javac_version=(HERE/'javac-version.stdout').read_text('utf8'),
        java_sha256='d5f1b9e03e298ebfb04d2326ecc1e2af3e6817f9b4d7f9f151fe856d56975650',
        javac_sha256='74f283ef1e26b3dfccfb56673d74a8a720d2c142e80881aa0084ce2e0379004e',installed_by_producer=False)
    receipt=dict(schema=1,status='PASS_INPUT_ONLY_NATIVE_WHOLE_BLOB_EXACT',telegram_commit=original['telegram_commit'],
        runs=runs,toolchain=toolchain,native_runs=2,whole_blob_proofs=6,compatibility_upgrades=5,identical_native_artifacts=24,
        independent_checks=verification['checks'],native_outputs=original['raw_native_outputs'],reader_helper_product_devices_network='NOT_RUN')
    dump(HERE/'native-run-receipt.json',receipt)
    payload=dict(original);payload['runs']=runs;payload['toolchain']=toolchain
    payload['native_run_receipt_sha256']=sha((HERE/'native-run-receipt.json').read_bytes())
    payload['producer_verification_sha256']=sha((HERE/'verification.json').read_bytes())
    payload['scope_notes']='Exact five-case supplemental compatibility upgrade, not a mutation of old fixture labels, source bytes or prior helper43 results.'
    raw=(json.dumps(payload,ensure_ascii=False,indent=2)+'\n').encode('utf8')
    (HERE/'compatibility.json').write_bytes(raw)
    with (HERE/'compatibility.json.gz').open('xb') as out:
        with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0,compresslevel=9) as gz:gz.write(raw)
    selected=[]
    dirs=('java-src','upstream','official-methods','inputs','old-fixture-pins','native-run-01','native-run-02')
    for directory in dirs:selected.extend(p for p in (HERE/directory).rglob('*') if p.is_file())
    names=('CompatibilityOracle.java','build_compatibility.py','finalize_compatibility.py','README.md','LICENSE','source-provenance.json',
        'compatibility.json','compatibility.json.gz','native-run-receipt.json','verification.json','duplicate-filename-policy.json','empty-legacy-scope.json',
        'java-version.stdout','java-version.stderr','javac-version.stdout','javac-version.stderr','javac.stdout','javac.stderr',
        'java-run-01.stdout','java-run-01.stderr','java-run-02.stdout','java-run-02.stderr')
    selected.extend(HERE/name for name in names)
    selected=sorted(set(selected));assert all(not p.is_symlink() for p in selected)
    source_manifest=[pin(p) for p in selected];dump(HERE/'archive-source-manifest.json',dict(schema=1,files=source_manifest))
    selected.append(HERE/'archive-source-manifest.json')
    with (HERE/'oracle-sources.tar.gz').open('xb') as out:
        with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0,compresslevel=9) as gz:
            with tarfile.open(mode='w',fileobj=gz,format=tarfile.USTAR_FORMAT) as tar:
                for path in sorted(selected):
                    name=path.relative_to(HERE).as_posix();data=path.read_bytes()
                    info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';info.mode=0o644
                    tar.addfile(info,io.BytesIO(data))
    with tarfile.open(HERE/'oracle-sources.tar.gz','r:gz') as tar:
        members=tar.getmembers();assert len(members)==len(selected)
        for item in members:
            assert item.isfile() and not Path(item.name).is_absolute() and '..' not in Path(item.name).parts
            assert tar.extractfile(item).read()==(HERE/item.name).read_bytes()
    files=[pin(HERE/name) for name in ('compatibility.json.gz','oracle-sources.tar.gz','LICENSE','README.md')]
    manifest=dict(schema=1,telegram_commit=original['telegram_commit'],status='INPUT_ONLY_NATIVE_WIRE_COMPATIBILITY_PROOF',
        source_fixture='telegram-document-descriptor',source_fixture_manifest_sha256=original['old_fixture_manifest_sha256'],
        old_positive_cases=21,old_controls=42,native_whole_blob_proofs=6,explicit_compatibility_upgrades=5,
        compatibility_case_names=original['policy']['upgrade_control_names'],uncompressed_json_bytes=len(raw),uncompressed_json_sha256=sha(raw),
        native_run_receipt_sha256=sha((HERE/'native-run-receipt.json').read_bytes()),files=files,
        no_change_to_old_fixture=True,duplicate_filename_policy='STRICT_UNSUPPORTED',legacy_empty_policy='NO_RECLASSIFICATION',
        recovery_parser_imported=False,product_recovery_run=False,native_device_server_auth_claimed=False,paid20_benchmark_changed=False)
    dump(HERE/'manifest.json',manifest)
    frozen=HERE/'frozen-01';frozen.mkdir();owned=[p for p in sorted(HERE.rglob('*')) if p.is_file() and not p.is_relative_to(frozen)]
    frozen_rows=[]
    for path in owned:
        info=pin(path);target=frozen/'files'/info['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target)
        assert target.read_bytes()==path.read_bytes();frozen_rows.append(info)
    dump(frozen/'manifest.json',dict(schema=1,status='FROZEN_INPUT_ONLY_BYTES',files=frozen_rows))
    handoff=dict(schema=1,status='SOURCE_CLOSED_INPUT_ONLY',folder=str(HERE),manifest_sha256=sha((HERE/'manifest.json').read_bytes()),
        payload_raw_sha256=sha(raw),payload_gzip_sha256=sha((HERE/'compatibility.json.gz').read_bytes()),
        source_archive_sha256=sha((HERE/'oracle-sources.tar.gz').read_bytes()),native_receipt_sha256=sha((HERE/'native-run-receipt.json').read_bytes()),
        freeze_manifest_sha256=sha((frozen/'manifest.json').read_bytes()),frozen_files=len(frozen_rows),
        whole_blob_proofs=6,explicit_compatibility_upgrades=5,native_runs=2,identical_native_artifacts=24,independent_checks=verification['checks'],
        boundaries=original['boundaries'],next_step='Independent review of canonical bundle; root may add explicit exact-five current-profile policy without changing old goldens.')
    dump(HERE/'handoff-receipt.json',handoff)
    print(json.dumps(handoff,ensure_ascii=False))

if __name__=='__main__':main()
